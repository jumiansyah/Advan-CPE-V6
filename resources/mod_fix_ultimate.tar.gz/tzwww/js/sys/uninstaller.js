new Vue({
    el: '#child_container',
    data: {
        securityQuestion: "Loading...",
        securityAnswer: "",
        isUninstalling: false,
        progressMessage: "",
        resultMessage: "",
        resultType: ""
    },
    mounted: function() {
        this.loadSecurityQuestion();
    },
    methods: {
        loadSecurityQuestion: function() {
            var self = this;
            fetch('/cgi-bin/custom.cgi?action=get_security_question')
                .then(function(response) {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(function(data) {
                    self.securityQuestion = data.question || "Siapa Bapak Republik?";
                })
                .catch(function(error) {
                    console.error('Error loading security question:', error);
                    self.securityQuestion = "Siapa Bapak Republik?";
                });
        },

        startUninstall: function() {
            if (!this.securityAnswer.trim()) {
                this.$message.error('Silakan jawab pertanyaan keamanan terlebih dahulu');
                return;
            }

            var self = this;
            this.isUninstalling = true;
            this.progressMessage = "Memverifikasi jawaban keamanan...";
            this.resultMessage = "";

            // Step 1: Verify security answer
            fetch('/cgi-bin/custom.cgi?action=verify_security', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'answer=' + encodeURIComponent(this.securityAnswer)
            })
            .then(function(response) {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(function(data) {
                if (data.status === 'success') {
                    self.executeUninstall();
                } else {
                    self.isUninstalling = false;
                    self.resultType = 'error';
                    self.resultMessage = '❌ Jawaban keamanan salah. Uninstall dibatalkan.';
                    self.progressMessage = "";
                }
            })
            .catch(function(error) {
                console.error('Error verifying security:', error);
                self.isUninstalling = false;
                self.resultType = 'error';
                self.resultMessage = '❌ Terjadi kesalahan saat verifikasi. Silakan coba lagi.';
                self.progressMessage = "";
            });
        },

        executeUninstall: function() {
            var self = this;
            this.progressMessage = "Menjalankan script uninstaller...";

            // Step 2: Execute uninstaller script
            fetch('/cgi-bin/custom.cgi?action=execute_uninstall', {
                method: 'POST'
            })
            .then(function(response) {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(function(data) {
                self.isUninstalling = false;
                self.progressMessage = "";
                
                if (data.status === 'success') {
                    self.resultType = 'success';
                    self.resultMessage = '✅ Uninstall berhasil! Sistem akan restart dalam 10 detik...';
                    
                    // Auto redirect/restart after 10 seconds
                    setTimeout(function() {
                        window.location.href = '/';
                    }, 10000);
                } else {
                    self.resultType = 'error';
                    self.resultMessage = '❌ Uninstall gagal: ' + (data.message || 'Unknown error');
                }
            })
            .catch(function(error) {
                console.error('Error executing uninstall:', error);
                self.isUninstalling = false;
                self.resultType = 'error';
                self.resultMessage = '❌ Terjadi kesalahan saat uninstall. Silakan coba lagi.';
                self.progressMessage = "";
            });
        }
    }
});
$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            adbFlag:false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            disabled: false,
            adbSwitch: TAB.sys.adbSwitch,
            save: DOC.btn.save
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ADB_SWITCH
                    },
                    success: function (data) {
                        vm.adbFlag = data.adbSwitch == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json={};
                fyAlertMsgLoading();
                json.adbSwitch = this.adbFlag ? "1" : "0";
                json.cmd = RequestCmd.ADB_SWITCH;
                json.method = JSONMethod.POST;
               Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if(data.success == true){
                            fyAlertMsgSuccess();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted:function(){
             this.getData();
        }
    })
});
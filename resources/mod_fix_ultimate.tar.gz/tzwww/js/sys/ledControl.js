$(document).ready(function() {
    var fm = ["childFormId", "child_container"];
    Page.createForm(fm);

    var vm = new Vue({
        el: "#child_container",
        data: {
            leds: {
                wifi: true,
                data: true,
                sig: true,
                all: true
            },
            isToggling: false,
            isRestoring: false
        },
        methods: {
            handleToggle: function(target) {
                var self = this;
                var currentState = self.leds[target];
                var nextState = !currentState;
                var stateStr = nextState ? "on" : "off";

                self.isToggling = true;
                
                fetch("cgi-bin/custom.cgi?action=led_control&target=" + target + "&state=" + stateStr)
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        if (data.success) {
                            self.leds[target] = nextState;
                            // Jika USER mengaktifkan ALL, set semua individu ke true
                            if (target === 'all') {
                                self.leds.wifi = nextState;
                                self.leds.data = nextState;
                                self.leds.sig = nextState;
                            }
                            // Jika ada individu diaktifkan, tapi ALL off, biarkan saja
                            // Tapi jika semua individu dimatikan, ALL harus off
                            if (!self.leds.wifi && !self.leds.data && !self.leds.sig) {
                                self.leds.all = false;
                            }
                            
                            Page.tips(data.message, "success");
                        } else {
                            Page.tips(data.message || "Gagal mengatur LED", "error");
                        }
                    })
                    .catch(function(err) {
                        Page.tips("Koneksi gagal", "error");
                    })
                    .finally(function() {
                        self.isToggling = false;
                    });
            },
            restoreFactory: function() {
                var self = this;
                self.isRestoring = true;

                fetch("cgi-bin/custom.cgi?action=led_control&state=restore")
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        if (data.success) {
                            // Reset state di UI ke Default (AKTIF)
                            self.leds.wifi = true;
                            self.leds.data = true;
                            self.leds.sig = true;
                            self.leds.all = true;
                            Page.tips(data.message, "success");
                        } else {
                            Page.tips(data.message || "Gagal mereset LED", "error");
                        }
                    })
                    .catch(function(err) {
                        Page.tips("Koneksi gagal", "error");
                    })
                    .finally(function() {
                        self.isRestoring = false;
                    });
            }
        }
    });
});

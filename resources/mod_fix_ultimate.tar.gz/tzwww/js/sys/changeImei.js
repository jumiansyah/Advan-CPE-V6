$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);

    function callCgi(params, callback) {
        $.ajax({
            url: '/cgi-bin/custom.cgi',
            type: 'POST',
            data: params,
            dataType: 'json',
            timeout: 15000,
            success: function (data) {
                callback(data);
            },
            error: function (xhr, status, err) {
                callback({ success: false, msg: 'Request error: ' + (err || status) });
            }
        });
    }

    var vm = new Vue({
        el: "#child_container",
        data: {
            currentImei: '-',
            newImei: '',
            imeiError: '',
            statusMsg: '-'
        },
        watch: {
            newImei: function (val) {
                if (!val) {
                    this.imeiError = '';
                    return;
                }
                if (!/^\d+$/.test(val)) {
                    this.imeiError = 'Hanya angka';
                } else if (val.length !== 15) {
                    this.imeiError = 'Harus 15 digit (' + val.length + '/15)';
                } else {
                    this.imeiError = '';
                }
            }
        },
        methods: {
            readImei: function () {
                var self = this;
                self.statusMsg = 'Reading IMEI...';
                callCgi('action=read_imei', function (data) {
                    if (data.success && data.imei) {
                        self.currentImei = data.imei;
                        self.statusMsg = 'OK';
                    } else {
                        self.statusMsg = data.msg || 'Cannot read IMEI';
                    }
                });
            },
            applyImei: function () {
                if (this.imeiError || !this.newImei) return;
                var self = this;
                var imei = this.newImei;

                if (!confirm('Change IMEI to ' + imei + '?\nNote: Modem mungkin perlu reboot manual.')) return;

                self.statusMsg = 'Changing IMEI...';
                callCgi('action=set_imei&imei=' + imei, function (data) {
                    if (data.success) {
                        self.statusMsg = data.msg;
                        self.currentImei = data.imei || imei;
                        self.newImei = '';
                    } else {
                        self.statusMsg = 'Error: ' + data.msg;
                    }
                });
            }
        },
        mounted: function () {
            this.readImei();
        }
    });
});

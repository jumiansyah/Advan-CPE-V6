$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            telnetValue: false,
            telnetValue2: false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            disabled: false,
            save: DOC.btn.save
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SYS_SERVICE_SET
                    },
                    success: function (data) {
                        vm.telnetValue = data.telnet == "1" ? true : false;
                        vm.telnetValue2 = data.telnet_orca == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.telnet = this.telnetValue ? "1" : "0";
                json.telnet_orca = this.telnetValue2 ? "1" : "0";
                json.cmd = RequestCmd.SYS_SERVICE_SET;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })

});
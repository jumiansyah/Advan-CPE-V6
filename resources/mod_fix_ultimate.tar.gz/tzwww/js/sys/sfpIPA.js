$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            switchValue: TAB.sys.sfpIpaSwitch,
            option: [
                { name: TAB.sys.sfpIpaClose, value: "0" },
                { name: TAB.sys.sfpOpen, value: "1" },
                { name: TAB.sys.ipaOpen, value: "2" },
            ],
            sfpIpaSwitch: "0",
            save: DOC.btn.save
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SFP_IPA_SETTING
                    },
                    success: function (data) {
                        vm.sfpIpaSwitch = data.sfpIpaSwitch ? data.sfpIpaSwitch : "0";
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.sfpIpaSwitch = this.sfpIpaSwitch;
                json.cmd = RequestCmd.SFP_IPA_SETTING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })
});
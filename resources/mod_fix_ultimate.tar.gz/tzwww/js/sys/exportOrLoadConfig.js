$(document).ready(function() {
    var fm1 = ["form1", "child_container", "child_template"];
    Page.createForm(fm1);
    $('#form1').attr({
        "enctype": "multipart/form-data",
        "method": "post"
    });
    var vm = new Vue({
        el:"#child_container",
        data:{
            configUpdate:MENU.sys.configUpdate,
            selectUpdateFile:DOC.sys.selectUpdateFile,
            colon:DOC.colon,
            browse:DOC.btn.browse,
            upload:DOC.btn.upload ,
            update:DOC.btn.update,
            theUpdateFileName:"",
            isZip:false,
            exportCfg:DOC.sys.exportCfg,
            btnExportCfg:DOC.btn.exportCfg,
            exportDelegateShow:false,
            loadCfg:DOC.btn.loadCfg,
            selectCfgFile:DOC.sys.selectCfgFile,
            exportDelegateText:DOC.link.clickMeDownload,
            exportUrl:""
        },
        methods:{
            btnUploadClick:function(){
                var $form = $('#form1');
        var url = String.format("{0}?cmd={1}&method=POST&sessionId={2}&language={3}", Url.DEFAULT_CGI,
                RequestCmd.SYS_UPDATE, sessionStorage['sessionId'], Page.language);

        var datas = null, returnDatas = null, configFile = null;
        $form.ajaxSubmit({
            url: url,
            type: 'POST',
            beforeSubmit: function() {
                if ($('#fp').val() == "") {
                    AlertUtil.alertMsg(CHECK.required.cfgFile);
                    return false;
                }
                configFile = $('#fp').val();

                if (/[\\\/]/.test(configFile)) {
                    var matchs = configFile.match(/(.*)?[\\\/](.*)/);
                    configFile = matchs[2];
                }

                if (!confirm(PROMPT.confirm.loadCfg + configFile)) {
                    return false;
                }
                SysUtil.showProgress(ProgressTime.UPLOAD_FILE, PROMPT.status.loadingCfg,
                    function() {
                        return datas != null;
                    },
                    function() {
                       if (datas.success) {
                           AlertUtil.alertMsg(PROMPT.saving.loadCfg);
                       } else {
                           SysUtil.processMsg(datas.message);
                       }
                       closeBox();
                    }
                );

                return true;
            },
            success: function(data, statusText) {
                try {
                    returnDatas = SysUtil.parseJSON(data);
                    if (!returnDatas.success) {
                        datas = returnDatas;
                    } else {
                        Page.postJSON({
                            json: { cmd: RequestCmd.CONFIG_LOADER, configFile: configFile},
                            success: function(data) {
                                datas = data;
                            },
                            fail: function(data) {
                                datas = data;
                            }
                        });
                    }
                } catch(ex) {
                   datas = { success: false, message: PROMPT.status.parseJsonFail };
                }
            },
            error: function(responseText, statusText) {
                datas = { success: false, message: responseText };
            }
        });
            },
            btnExportConfigClick:function(){
                Page.postJSON({
                json: { cmd: RequestCmd.CONFIG_EXPORT },
                success: function(data) {
                    var url = '/cfg_export_config_file.conf';
                        vm.exportUrl = url;
                        vm.exportDelegateShow = true;
                    }
                });
            }
        }
    })

});

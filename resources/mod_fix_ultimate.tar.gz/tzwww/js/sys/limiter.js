$(document).ready(function() {
    var fm = ["childFormId", "child_container"];
    Page.createForm(fm);

    var vm = new Vue({
        el: "#child_container",
        data: {
            devices: [],
            rules: [],
            blocked: [],
            pintar: [],
            quotas: [],
            trafficData: [],
            globalSpeed: "",
            localSpeed: "",
            autostart: "off",
            scanning: false,
            monitoring: false,
            monitorInterval: null,
            monitorRefreshRate: 3000,
            newPintarDevice: "",
            newPintarStart: "21:00",
            newPintarEnd: "05:00",
            newPintarDays: "Mon,Tue,Wed,Thu,Fri,Sat,Sun",
            newPintarCategory: "ALL",
            categories: [],
            newQuotaDevice: "",
            newQuotaAmount: "1000",
            newQuotaAction: "BLOCK",
            newQuotaPenalty: "128",
            newQuotaDays: "30",
            showDetails: false,  // Global expand/collapse
            showConnectedDevices: false,
            showActiveRules: false,
            showBlockedDevices: false,
            showJadwalPintar: false,
            showPaketData: false,
            showLiveMonitor: false
        },
        mounted: function() {
            var self = this;
            this.scanDevices();
            this.loadStatus();
            this.loadCategories();
            this.loadQuotas();
            // Pause monitor when tab hidden
            document.addEventListener('visibilitychange', function() {
                if (document.hidden && self.monitoring) {
                    self.stopMonitor();
                }
            });
        },
        methods: {
            scanDevices: function() {
                var self = this;
                self.scanning = true;
                $.getJSON("cgi-bin/custom.cgi?action=limiter_scan", function(data) {
                    if (data && data.devices) {
                        data.devices.forEach(function(d) { d._speed = d.speed || ""; });
                        self.devices = data.devices;
                    }
                    self.scanning = false;
                }).fail(function() { self.scanning = false; });
            },

            loadStatus: function() {
                var self = this;
                $.getJSON("cgi-bin/custom.cgi?action=limiter_status", function(data) {
                    if (data) {
                        self.rules = data.rules || [];
                        self.blocked = data.blocked || [];
                        self.pintar = data.pintar || [];
                        self.globalSpeed = data.global || "";
                        self.localSpeed = data.local || "";
                        self.autostart = data.autostart || "off";
                    }
                });
            },

            loadCategories: function() {
                var self = this;
                $.getJSON("cgi-bin/custom.cgi?action=limiter_kategori_list", function(data) {
                    if (data && data.categories) {
                        self.categories = data.categories;
                    }
                });
            },

            loadQuotas: function() {
                var self = this;
                $.getJSON("cgi-bin/custom.cgi?action=limiter_quota_list", function(data) {
                    if (data && data.quotas) {
                        self.quotas = data.quotas;
                    }
                });
            },

            rowStyle: function(status) {
                if (status === "blocked") return "background:rgba(255,68,68,0.08);";
                if (status === "limited") return "background:rgba(243,254,124,0.08);";
                if (status === "scheduled") return "background:rgba(0,236,189,0.08);";
                return "";
            },

            setSpeed: function(d) {
                var speed = d._speed;
                if (!speed || parseFloat(speed) <= 0) {
                    AlertUtil.alertMsg("Masukkan speed limit (Mbps)");
                    return;
                }
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_set", mac: d.mac, ip: d.ip, speed: speed, name: d.name
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.scanDevices();
                    self.loadStatus();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal menerapkan"); });
            },

            blockDevice: function(d) {
                if (!confirm("Blokir " + d.name + " (" + d.ip + ")?")) return;
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_block", mac: d.mac, ip: d.ip, name: d.name
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.scanDevices();
                    self.loadStatus();
                }, "json");
            },

            unblockDevice: function(d) {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_unblock", mac: d.mac
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.scanDevices();
                    self.loadStatus();
                }, "json");
            },

            deleteRule: function(mac, type) {
                if (!confirm("Hapus rule untuk " + mac + "?")) return;
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_delete", mac: mac, type: type || 'speed'
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.scanDevices();
                    self.loadStatus();
                }, "json");
            },

            setGlobal: function() {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_global", speed: self.globalSpeed
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                }, "json");
            },

            clearGlobal: function() {
                var self = this;
                self.globalSpeed = "";
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_global", speed: ""
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                }, "json");
            },

            setLocal: function() {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_local", speed: self.localSpeed
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                }, "json");
            },

            clearLocal: function() {
                var self = this;
                self.localSpeed = "";
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_local", speed: ""
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                }, "json");
            },

            toggleAutostart: function(act) {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_autostart", act: act
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.autostart = act;
                }, "json");
            },

            reloadRules: function() {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_load"
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.scanDevices();
                    self.loadStatus();
                }, "json");
            },

            addPintar: function() {
                var self = this;
                if (!self.newPintarDevice) {
                    AlertUtil.alertMsg("Pilih device terlebih dahulu");
                    return;
                }
                if (!self.newPintarStart || !self.newPintarEnd) {
                    AlertUtil.alertMsg("Jam mulai dan selesai harus diisi");
                    return;
                }

                var device = self.devices.find(function(d) { return d.mac === self.newPintarDevice; });
                if (!device) {
                    AlertUtil.alertMsg("Device tidak ditemukan");
                    return;
                }

                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_pintar_add",
                    mac: device.mac,
                    ip: device.ip,
                    name: device.name,
                    start: self.newPintarStart,
                    end: self.newPintarEnd,
                    days: self.newPintarDays,
                    category: self.newPintarCategory
                }, function(data) {
                    AlertUtil.alertMsg(data.message);
                    self.newPintarDevice = "";
                    self.newPintarStart = "21:00";
                    self.newPintarEnd = "05:00";
                    self.newPintarCategory = "ALL";
                    self.scanDevices();
                    self.loadStatus();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal menambahkan jadwal"); });
            },

            resetLimiter: function() {
                var self = this;
                if (!confirm("⚠️ PERINGATAN!\n\nIni akan menghapus SEMUA data limiter:\n- Semua speed rules\n- Semua device yang diblokir\n- Semua jadwal pintar\n- Semua settingan global/local\n\nLanjutkan?")) {
                    return;
                }
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_reset"
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Limiter direset. Semua data dihapus.");
                    self.globalSpeed = "";
                    self.localSpeed = "";
                    self.scanDevices();
                    self.loadStatus();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal mereset limiter"); });
            },

            turnOffLimiter: function() {
                var self = this;
                if (!confirm("Matikan semua limit aktif?\n\nData tidak akan dihapus, hanya rules dinonaktifkan sementara.")) {
                    return;
                }
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_off"
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Limiter dimatikan.");
                    self.scanDevices();
                    self.loadStatus();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal mematikan limiter"); });
            },

            backupDatabase: function() {
                var self = this;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_backup"
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Backup berhasil!");
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal melakukan backup"); });
            },

            restoreDatabase: function() {
                var self = this;
                if (!confirm("⚠️ RESTORE DATABASE\n\nIni akan menimpa semua data limiter saat ini dengan data dari backup.\n\nLanjutkan?")) {
                    return;
                }
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_restore"
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Restore berhasil!");
                    self.scanDevices();
                    self.loadStatus();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal melakukan restore"); });
            },

            addQuota: function() {
                var self = this;
                if (!self.newQuotaDevice) {
                    AlertUtil.alertMsg("Pilih device terlebih dahulu");
                    return;
                }
                if (!self.newQuotaAmount || self.newQuotaAmount <= 0) {
                    AlertUtil.alertMsg("Quota harus lebih dari 0 MB");
                    return;
                }
                
                var device = self.devices.find(function(d) { return d.mac === self.newQuotaDevice; });
                if (!device) {
                    AlertUtil.alertMsg("Device tidak ditemukan");
                    return;
                }
                
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_quota_add",
                    mac: device.mac,
                    ip: device.ip,
                    name: device.name,
                    quota: self.newQuotaAmount,
                    quota_action: self.newQuotaAction,
                    penalty: self.newQuotaPenalty,
                    days: self.newQuotaDays
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Quota ditambahkan!");
                    self.loadQuotas();
                    self.newQuotaDevice = "";
                    self.newQuotaAmount = "1000";
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal menambahkan quota"); });
            },

            deleteQuota: function(quota) {
                var self = this;
                if (!confirm("Hapus quota untuk device ini?")) return;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_quota_delete",
                    mac: quota.mac
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Quota dihapus");
                    self.loadQuotas();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal menghapus quota"); });
            },

            resetQuotaUsage: function() {
                var self = this;
                if (!confirm("Reset usage semua quota ke 0?\n\nHanya counter yang di-reset, quota limit tetap sama.")) return;
                $.post("cgi-bin/custom.cgi", {
                    action: "limiter_quota_reset"
                }, function(data) {
                    AlertUtil.alertMsg(data.message || "Quota usage di-reset");
                    self.loadQuotas();
                }, "json").fail(function() { AlertUtil.alertMsg("Gagal reset quota"); });
            },

            // Live Traffic Monitor
            startMonitor: function() {
                var self = this;
                if (self.monitoring) return;
                self.monitoring = true;
                self.updateTraffic();
                self.monitorInterval = setInterval(function() {
                    self.updateTraffic();
                }, self.monitorRefreshRate);
            },

            stopMonitor: function() {
                var self = this;
                self.monitoring = false;
                if (self.monitorInterval) {
                    clearInterval(self.monitorInterval);
                    self.monitorInterval = null;
                }
                // Clear residual data ketika stop
                self.trafficData = [];
            },

            updateTraffic: function() {
                var self = this;
                $.getJSON("cgi-bin/custom.cgi?action=limiter_monitor", function(data) {
                    if (data && data.traffic) {
                        self.trafficData = data.traffic;
                    }
                });
            },

            formatSpeed: function(kbps) {
                if (!kbps || kbps < 1) return "0 Kbps";
                if (kbps >= 1024) return (kbps / 1024).toFixed(1) + " Mbps";
                return kbps + " Kbps";
            },

            formatBytes: function(bytes) {
                if (!bytes || bytes < 1) return "0 B";
                if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + " GB";
                if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + " MB";
                if (bytes >= 1024) return (bytes / 1024).toFixed(2) + " KB";
                return bytes + " B";
            },

            toggleDetails: function() {
                this.showDetails = !this.showDetails;
                // Toggle all individual sections when global toggle is used
                this.showConnectedDevices = this.showDetails;
                this.showActiveRules = this.showDetails;
                this.showBlockedDevices = this.showDetails;
                this.showJadwalPintar = this.showDetails;
                this.showPaketData = this.showDetails;
                this.showLiveMonitor = this.showDetails;
            },
            toggleConnectedDevices: function() {
                this.showConnectedDevices = !this.showConnectedDevices;
            },
            toggleActiveRules: function() {
                this.showActiveRules = !this.showActiveRules;
            },
            toggleBlockedDevices: function() {
                this.showBlockedDevices = !this.showBlockedDevices;
            },
            toggleJadwalPintar: function() {
                this.showJadwalPintar = !this.showJadwalPintar;
            },
            togglePaketData: function() {
                this.showPaketData = !this.showPaketData;
            },
            toggleLiveMonitor: function() {
                this.showLiveMonitor = !this.showLiveMonitor;
            }
        }
    });
});

$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);

    function callCgi(params, callback) {
        $.ajax({
            url: '/cgi-bin/custom.cgi',
            type: 'POST',
            data: params,
            dataType: 'json',
            success: function (data) {
                callback(data);
            },
            error: function (xhr, status, err) {
                callback({ success: false, msg: 'Request error: ' + (err || status) });
            }
        });
    }

    var vm = new Vue({
        el: "#child_container",
        data: {
            ttlValue: 64,
            statusMsg: '-'
        },
        methods: {
            readTtl: function () {
                var self = this;
                self.statusMsg = 'Reading...';
                callCgi('action=read_ttl', function (data) {
                    if (data.success && data.ttl && data.ttl !== '0') {
                        self.ttlValue = parseInt(data.ttl);
                        self.statusMsg = 'Current TTL: ' + data.ttl;
                    } else {
                        self.statusMsg = data.msg || 'No TTL rule active';
                    }
                });
            },
            applyTtl: function () {
                var val = parseInt(this.ttlValue);
                if (isNaN(val) || val < 1 || val > 255) {
                    AlertUtil.alertMsg('TTL harus antara 1 dan 255');
                    return;
                }
                var self = this;
                self.statusMsg = 'Applying TTL=' + val + '...';
                callCgi('action=set_ttl&value=' + val, function (data) {
                    if (data.success) {
                        self.statusMsg = 'OK! ' + data.msg;
                    } else {
                        self.statusMsg = 'Error: ' + data.msg;
                    }
                });
            },
            resetTtl: function () {
                var self = this;
                if (!confirm('Reset semua TTL rules dan hapus startup?\nTTL tidak akan di-set saat boot.')) return;
                self.statusMsg = 'Resetting...';
                callCgi('action=reset_ttl', function (data) {
                    if (data.success) {
                        self.ttlValue = 64;
                        self.statusMsg = data.msg;
                    } else {
                        self.statusMsg = 'Error: ' + data.msg;
                    }
                });
            }
        },
        mounted: function () {
            this.readTtl();
        }
    });
});

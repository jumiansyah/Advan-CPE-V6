$(document).ready(function () {
    var rules = {
        timeInterval:{required: true, digits: true, range: [1, 10080] }
    }, messages = {
        timeInterval: { required: CHECK.required.time },
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            switchValue: TAB.sys.commlogTime,
            timeInterval: "",
            save: DOC.btn.save,
            min: DOC.unit.min
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.COMMLOG_BACKUP_TIME
                    },
                    success: function (data) {
                        vm.timeInterval = data.backup_time;
                    }

                });
            },
            setData: function () {
                if (!CheckUtil.checkRange(this.timeInterval,1,10080) || !CheckUtil.checkNumber(this.timeInterval)) {
                    AlertUtil.alertMsg(CHECK.range.commlogRange);
                    return false;
                }
                var json = {};
                fyAlertMsgLoading();
                json.backup_time = this.timeInterval;
                json.cmd = RequestCmd.COMMLOG_BACKUP_TIME;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.sendInfo === "0" ) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })
});
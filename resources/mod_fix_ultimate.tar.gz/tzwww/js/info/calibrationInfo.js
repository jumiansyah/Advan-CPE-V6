/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-06-07 14:40:09
 * @,@LastEditTime: ,: 2021-06-08 09:01:20
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\info\calibrationInfo.js
 */
$(document).ready(function () {

    var vm = new Vue({
        el: "#detail_container",
        data: {
            contentInfo: "",
            active: "first",
            ListInfo: []
        },
        methods: {
            getLTE: function () {
                this.active = "first";
                this.ListInfo = [];
                this.contentInfo = "";
                Page.postJSON({
                    returnHtml: true,
                    json: {
                        cmd: RequestCmd.LTE_CALIBRATION
                    },
                    success: function (data) {
                        if(data){
                            vm.contentInfo = data.replace(/\n/g, "<br />");
                        } else {
                            vm.contentInfo = PROMPT.tips.infoList;
                        }
                    }
                });
            },
            getNR: function(){
                this.active = "second";
                this.ListInfo = [];
                this.contentInfo = "";
                Page.postJSON({
                    returnHtml: true,
                    json: {
                        cmd: RequestCmd.NR_CALIBRATION
                    },
                    success: function (data) {
                        if(data){
                            vm.contentInfo = data.replace(/\n/g, "<br />");
                        } else {
                            vm.contentInfo = PROMPT.tips.infoList;
                        }
                    }
                });
            },
            getENDC: function(){
                this.active = "third";
                this.ListInfo = [];
                this.contentInfo = "";
                Page.postJSON({
                    returnHtml: true,
                    json: {
                        cmd: RequestCmd.GET_ENDC_INFO
                    },
                    success: function (data) {
                        if(data){
                            vm.contentInfo = data.replace(/\n/g, "<br />");
                        } else {
                            vm.contentInfo = PROMPT.tips.infoList;
                        }
                    }
                });
            },
            getMOUNT: function(){
                this.active = "fourth";
                this.ListInfo = [];
                this.contentInfo = "";
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.GET_MOUNT_INFO
                    },
                    success: function (data) {
                        if ( Array.isArray(data.mount_info) ) {
                            vm.ListInfo = data.mount_info;
                        } else {
                            vm.contentInfo = PROMPT.tips.infoList;
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getLTE();
        }
    })
});
var loading = "-"
var runStatusName = [DOC.lbl.runtime, DOC.lbl.loadAvg, DOC.lbl.memoryTotal, DOC.lbl.memoryFree, DOC.lbl.memoryCache];
var deviceName = [DOC.device.model, DOC.device.softwarVersion, DOC.device.hardwareVersion, DOC.device.configVersion, DOC.device.buildTime, DOC.device.gitBranch, DOC.device.gitCommit, "SN", DOC.device.realVersion, DOC.info.simStatus,DOC.device.idu_git_branch, DOC.device.idu_git_sha];
var lteInfoName = [DOC.device.modemVersion, DOC.device.modsoftversion, DOC.device.modhardwareversion, "IMEI", "IMSI", "ICCID", "SN"];
var runStatusValues = new Array(12);
var deviceValues = new Array(17);
var lteInfoValues = new Array(7);

// === PRIVACY MASKING SYSTEM ===
var _sensitiveData = {}; // Key: "TYPE_INDEX", Value: Original Data
var _sensitiveVisible = {}; // Key: "TYPE_INDEX", Value: Boolean

function maskValue(val) {
    if (!val || val === '-' || val === loading) return val;
    var s = String(val);
    if (s.length < 4) return '••••';
    // Tampilkan 2 angka depan dan 2 belakang, sisanya sensor (untuk IMEI/SN/IMSI)
    if (s.length > 8) {
        return s.substring(0, 2) + "***********" + s.substring(s.length - 2);
    }
    // Untuk yang pendek seperti SN singkat atau PCI
    return s.substring(0, 2) + s.substring(2).replace(/[0-9a-fA-F]/g, '•');
}

function toggleSensitive(type, index) {
    var key = type + "_" + index;
    _sensitiveVisible[key] = !_sensitiveVisible[key];
    
    var original = _sensitiveData[key];
    var displayed = _sensitiveVisible[key] ? original : maskValue(original);
    
    if (type === 'device') {
        vm_deviceInfo.$set(deviceValues, index, displayed);
    } else if (type === 'lte') {
        vm_deviceInfo.$set(lteInfoValues, index, displayed);
    }
    
    setTimeout(function() { injectShowButtons(); }, 50);
}

function injectShowButtons() {
    var allTd = document.querySelectorAll('#deviceInfo td');
    if (!allTd.length) return;

    allTd.forEach(function(td) {
        var prevTd = td.previousElementSibling;
        if (!prevTd) return;
        var label = prevTd.textContent.trim().replace(/[:：\s]*$/, '');

        // Mapping Label ke Type_Index
        var maps = [
            { type: 'lte', index: 3, label: 'IMEI' },
            { type: 'lte', index: 4, label: 'IMSI' },
            { type: 'lte', index: 5, label: 'ICCID' },
            { type: 'lte', index: 6, label: 'SN' },
            { type: 'device', index: 7, label: 'SN' }
        ];

        maps.forEach(function(m) {
            if (label === m.label) {
                // Pastikan kita tidak tertukar antara SN di Device dan SN di LTE
                // Kita bisa cek section header (LTE Info vs Device Info) tapi biasanya SN di LTE diproses di tabel LTE
                // Trik: check if label exists in the correct array
                
                var key = m.type + "_" + m.index;
                if (!_sensitiveData[key]) return;

                var oldBtn = td.querySelector('.priv-toggle');
                if (oldBtn) oldBtn.remove();
                
                var isVisible = !!_sensitiveVisible[key];
                var btn = document.createElement('span');
                btn.className = 'priv-toggle';
                btn.style.cssText = 'cursor:pointer; font-size:10px; margin-left:6px; color:#17a2b8; border:1px solid #17a2b8; padding:1px 5px; border-radius:3px; font-family:sans-serif; vertical-align:middle; user-select:none; display:inline-block;';
                btn.textContent = isVisible ? '🔓 HIDE' : '🔒 SHOW';
                btn.onclick = function(e) { e.stopPropagation(); toggleSensitive(m.type, m.index); };
                td.appendChild(btn);
            }
        });
    });
}

var vm_deviceInfo = new Vue({
    el: "#deviceInfo",
    data: {
        runStatus: DOC.title.run,
        device: DOC.title.device,
        lteInfo: DOC.title.lte,
        runStatusValues: runStatusValues,
        deviceValues: deviceValues,
        lteInfoValues: lteInfoValues,
        runStatusName: runStatusName,
        deviceName: deviceName,
        lteInfoName: lteInfoName,
        lteInfoNameTable: true
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEVICE_INFO
                },
                success: function (data) {
                    vm_deviceInfo.$set(runStatusValues, 0, ConvertUtil.parseUptime2(data.uptime) || loading);
                    vm_deviceInfo.$set(runStatusValues, 1, data.cpuload || loading);
                    var memory = data.memory;

                    var memoryArr = memory.split(",");
                    vm_deviceInfo.$set(runStatusValues, 2, memoryArr[0] || loading);
                    vm_deviceInfo.$set(runStatusValues, 3, memoryArr[1] || loading);
                    vm_deviceInfo.$set(runStatusValues, 4, memoryArr[2] || loading);
                    if(!!data.temp_list && data.temp_list[0])
                    {
                        if(Page.level == "1")
                    {
                        vm_deviceInfo.$set(runStatusValues, 8, parseInt(data.temp_list[0]["nrcp-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 7, parseInt(data.temp_list[0]["soc-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 9, parseInt(data.temp_list[0]["ank0-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 10,parseInt(data.temp_list[0]["ank1-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 11,parseInt(data.temp_list[0]["cluster0-thmzone"])/1000+"℃" || loading);

                    }
                       vm_deviceInfo.$set(runStatusValues, 5, parseInt(data.temp_list[0]["apcpu0-thmzone"])/1000+"℃" || loading);
                       vm_deviceInfo.$set(runStatusValues, 6, parseInt(data.temp_list[0]["apcpu1-thmzone"])/1000+"℃" || loading);

                   }else
                   {
                      if(Page.level == "1")
                    {
                        vm_deviceInfo.$set(runStatusValues, 8,loading);
                        vm_deviceInfo.$set(runStatusValues, 7,loading);
                        vm_deviceInfo.$set(runStatusValues, 9,loading);
                        vm_deviceInfo.$set(runStatusValues, 10,loading);
                        vm_deviceInfo.$set(runStatusValues, 11,loading);

                    }
                       vm_deviceInfo.$set(runStatusValues, 5,loading);
                       vm_deviceInfo.$set(runStatusValues, 6,loading);
                   }
                    
                    vm_deviceInfo.$set(deviceValues, 0, data.board_type || loading);
                    vm_deviceInfo.$set(deviceValues, 1, data.fake_version || loading);
                    vm_deviceInfo.$set(deviceValues, 2, data.hwversion || loading);

                    // SENSITIVE: Device SN
                    var device_sn = data.device_sn || loading;
                    _sensitiveData["device_7"] = device_sn;
                    if (!_sensitiveVisible["device_7"]) {
                        vm_deviceInfo.$set(deviceValues, 7, maskValue(device_sn));
                    } else {
                        vm_deviceInfo.$set(deviceValues, 7, device_sn);
                    }

                    if (Page.level != "3") {
                        vm_deviceInfo.$set(deviceValues, 3, data.config_version || loading);
                    }
                    if (Page.level == "1") {    
                        vm_deviceInfo.$set(deviceValues, 4, data.build_date || loading);
                        vm_deviceInfo.$set(deviceValues, 5, data.git_branch || loading);
                        vm_deviceInfo.$set(deviceValues, 6, data.git_sha || loading);
                        vm_deviceInfo.$set(deviceValues, 8, data.real_fwversion || loading);
                        vm_deviceInfo.$set(deviceValues, 9, data.sim_slot || loading);
                        vm_deviceInfo.$set(deviceValues, 10, data.idu_git_branch || loading);
                        vm_deviceInfo.$set(deviceValues, 11, data.idu_git_sha || loading);
                    }

                    vm_deviceInfo.$set(lteInfoValues, 0, data.module_type || loading);
                    vm_deviceInfo.$set(lteInfoValues, 1, data.module_softver || loading);
                    vm_deviceInfo.$set(lteInfoValues, 2, data.module_hardver || loading);

                    // SENSITIVE: LTE Info (IMEI, IMSI, ICCID, SN)
                    var sensLte = {
                        3: data.module_imei || loading,
                        4: data.IMSI || loading,
                        5: data.ICCID || loading,
                        6: data.module_sn || loading
                    };

                    for (var idx in sensLte) {
                        var key = "lte_" + idx;
                        var val = sensLte[idx];
                        _sensitiveData[key] = val;
                        if (!_sensitiveVisible[key]) {
                            vm_deviceInfo.$set(lteInfoValues, idx, maskValue(val));
                        } else {
                            vm_deviceInfo.$set(lteInfoValues, idx, val);
                        }
                    }

                    // Inject Show/Hide buttons after render
                    Vue.nextTick(function() { injectShowButtons(); });
                }
            })
        },
        runStatusNameShow: function (index) {
            if (Page.level != "1" && (index == "7" || index == "8" || index == "9" || index == "10" || index == "11")) {
                return false;
            } else {
                return true;
            }
        },
        deviceArrShow: function (index) {
            if (Page.level != "1" && (index == "4" || index == "5" || index == "6" || index == "8" || index == "9" || index == "10" || index == "11" || index == "12" || index == "13" || index == "14" || index == "15" || index == "16")
                ||  ((index == "3")&& Page.level == "3")) {
                return false;
            } else {
                return true;
            }
        },
        lteInfoNameShow: function (index) {
            if (Page.level == "1") {
                return true;
            } else {
                if (index == "3" || index == "4" || index == "5") {
                    return true;
                } else {
                    return false;
                }
            }
        }
    },
    mounted: function () {
        this.getData();
        this.lteInfoNameTable = Page.level;
        Page.timer = setInterval(function () {
            vm_deviceInfo.getData();
        }, 3000);
    }
});

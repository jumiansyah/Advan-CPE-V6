/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-06-08 16:26:13
 * @,@LastEditTime: ,: 2021-06-08 20:25:22
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\info\wifi24g_index.js
 */
$(document).ready(function () {
    
    var tabs = TAB.advance;
    var id = "WIFI24G_INFO";
    var items = [];

    items.push({ title: "2.4G", url: 'html/info/wifi24g_info.html' });
    if(Page.pageHideCheck(6))
        items.push({ title: "2.4G_1", url: 'html/info/wifi24g1_info.html' });
    if(Page.pageHideCheck(7))    
        items.push({ title: "2.4G_2", url: 'html/info/wifi24g2_info.html' });
    if(Page.pageHideCheck(8))
        items.push({ title: "2.4G_3", url: 'html/info/wifi24g3_info.html' });
    // if(Page.pageHideCheck(9)) 
    //     items.push({ title: "2.4G_4", url: 'html/info/wifi24g4_info.html' });
    
   
    items.push({ title: wirelessconfightml.tab_menu.connectedList, url: 'html/info/wirelessConnected.html' });
        

    secondMenuClick(items,id);
});


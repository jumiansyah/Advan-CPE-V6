$(document).ready(function () {
    var text = wirelessconfightml.prompt;
    function cleanText(v) {
        if (v === undefined || v === null) {
            return "";
        }
        var s = String(v);
        s = s.replace(/[\x00-\x1F\x7F]/g, "");
        s = s.replace(/[^\x20-\x7E]/g, "");
        s = s.replace(/^\s+|\s+$/g, "");
        return s;
    }
    function pickFirst(item, keys) {
        for (var i = 0; i < keys.length; i++) {
            var val = item[keys[i]];
            if (val !== undefined && val !== null && String(val) !== "") {
                return val;
            }
        }
        return "";
    }
    function cleanMac(v) {
        var raw = cleanText(v);
        var direct = raw.match(/([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}/);
        if (direct && direct[0]) {
            return direct[0].toLowerCase().replace(/-/g, ":");
        }
        var hex = raw.replace(/[^0-9a-fA-F]/g, "");
        if (hex.length >= 12) {
            hex = hex.slice(hex.length - 12).toLowerCase();
            return hex.replace(/(..)(?=.)/g, "$1:");
        }
        return raw.replace(/[^0-9a-fA-F:\-]/g, "").toLowerCase().replace(/-/g, ":");
    }
    function cleanIp(v) {
        var raw = cleanText(v);
        var m = raw.match(/((\d{1,3}\.){3}\d{1,3})|(([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4})/);
        if (m && m[0]) {
            return m[0];
        }
        return raw;
    }
    function macKey(v) {
        var m = cleanText(v).match(/([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}/);
        return m && m[0] ? m[0].toLowerCase().replace(/-/g, ":") : "";
    }
    function isMacLikeText(v) {
        var s = cleanText(v).toLowerCase();
        if (!s) {
            return false;
        }
        if (/^([0-9a-f]{2}:){5}[0-9a-f]{2}$/.test(s)) {
            return true;
        }
        var compact = s.replace(/[^0-9a-f]/g, "");
        if (compact.length >= 8 && compact.length <= 12 && /[:\-]/.test(s)) {
            return true;
        }
        return false;
    }
    function usableHost(v) {
        var h = cleanText(v).toLowerCase();
        if (!h) return "";
        if (h === "*" || h === "-" || h === "unknown" || h === "(none)" || h === "null") {
            return "";
        }
        return cleanText(v);
    }
    function hostFromIp(ip) {
        var m = cleanIp(ip).match(/(\d{1,3})$/);
        return m && m[1] ? ("Client-" + m[1]) : "";
    }
    function macOctets(v) {
        var s = cleanText(v).toLowerCase().replace(/[^0-9a-f:]/g, "");
        if (!s) {
            return [];
        }
        var parts = s.split(":");
        var out = [];
        for (var i = 0; i < parts.length; i++) {
            if (/^[0-9a-f]{1,2}$/.test(parts[i])) {
                out.push(parts[i]);
            }
        }
        return out;
    }
    function findByTailOctets(srcMac, list, macField) {
        var src = macOctets(srcMac);
        if (src.length < 4) {
            return null;
        }
        var tail = src.slice(src.length - 4).join(":");
        var hit = null;
        for (var i = 0; i < list.length; i++) {
            var c = macOctets((list[i] && list[i][macField]) || "");
            if (c.length < 4) {
                continue;
            }
            var cTail = c.slice(c.length - 4).join(":");
            if (cTail === tail) {
                if (hit) {
                    return null;
                }
                hit = list[i];
            }
        }
        return hit;
    }
    function mergeWithArp(rows, arpClients) {
        if (!arpClients || !arpClients.length) {
            return rows;
        }
        var byIp = {};
        var byMac = {};
        var arpList = [];
        for (var i = 0; i < arpClients.length; i++) {
            var a = arpClients[i] || {};
            var aip = cleanIp(a.ip);
            var amac = cleanMac(a.mac);
            var ahost = cleanText(a.host);
            var ak = macKey(amac);
            var item = { ip: aip, mac: amac, host: ahost };
            arpList.push(item);
            if (aip) {
                byIp[aip] = item;
            }
            if (ak) {
                byMac[ak] = item;
            }
        }
        function findRefByMacLoose(srcMac) {
            var mk = macKey(srcMac);
            if (mk && byMac[mk]) {
                return byMac[mk];
            }
            var tailHit = findByTailOctets(srcMac, arpList, "mac");
            if (tailHit) {
                return tailHit;
            }
            var reduced = cleanText(srcMac).toLowerCase().replace(/[^0-9a-f:]/g, "");
            if (!reduced) {
                return null;
            }
            var reducedHex = reduced.replace(/:/g, "");
            var hit = null;
            for (var z = 0; z < arpList.length; z++) {
                var c = arpList[z] && arpList[z].mac ? arpList[z].mac.toLowerCase() : "";
                var cHex = c.replace(/:/g, "");
                var matched = false;
                if (c && c.indexOf(reduced) >= 0) {
                    matched = true;
                } else if (reducedHex.length >= 6 && cHex && cHex.endsWith(reducedHex)) {
                    matched = true;
                }
                if (matched) {
                    if (hit) {
                        return null;
                    }
                    hit = arpList[z];
                }
            }
            return hit;
        }
        var merged = [];
        for (var j = 0; j < rows.length; j++) {
            var r = rows[j] || {};
            var rip = cleanIp(r.ip);
            var rmac = cleanMac(r.mac);
            var rhost = usableHost(r.user);
            if (isMacLikeText(rhost)) {
                rhost = "";
            }
            var ref = null;
            if (rip && byIp[rip]) {
                ref = byIp[rip];
            } else {
                ref = findRefByMacLoose(rmac);
            }
            if (ref) {
                if (ref.mac) {
                    rmac = ref.mac;
                }
                if (!rip && ref.ip) {
                    rip = ref.ip;
                }
                if ((!rhost || rhost === "Unknown") && usableHost(ref.host)) {
                    rhost = usableHost(ref.host);
                }
            }
            if (!rhost) {
                rhost = hostFromIp(rip);
            }
            if (!rhost) {
                var tail = (rmac || "").replace(/:/g, "").slice(-4);
                rhost = "Device" + (tail ? "-" + tail : "");
            }
            merged.push({
                user: rhost,
                mac: rmac,
                ip: rip,
                ssid: r.ssid || "",
                rssi: r.rssi || ""
            });
        }
        return merged;
    }
    function mergeWithDhcp(rows, dhcpRows) {
        if (!dhcpRows || !dhcpRows.length) {
            return rows;
        }
        var byIp = {};
        var byMac = {};
        var list = [];
        for (var i = 0; i < dhcpRows.length; i++) {
            var d = dhcpRows[i] || {};
            var dip = cleanIp(pickFirst(d, ["ip", "ipaddr", "ipAddress", "client_ip"]));
            var dmac = cleanMac(pickFirst(d, ["mac", "macaddr", "macAddress", "client_mac"]));
            var dhost = usableHost(pickFirst(d, ["host", "hostname", "name", "user", "client_name"]));
            if (isMacLikeText(dhost)) {
                dhost = "";
            }
            var dk = macKey(dmac);
            var item = { ip: dip, mac: dmac, host: dhost };
            list.push(item);
            if (dip) {
                byIp[dip] = item;
            }
            if (dk) {
                byMac[dk] = item;
            }
        }
        function findRefByMac(srcMac) {
            var mk = macKey(srcMac);
            if (mk && byMac[mk]) {
                return byMac[mk];
            }
            var tailHit = findByTailOctets(srcMac, list, "mac");
            if (tailHit) {
                return tailHit;
            }
            var reduced = cleanText(srcMac).toLowerCase().replace(/[^0-9a-f:]/g, "");
            if (!reduced) {
                return null;
            }
            var reducedHex = reduced.replace(/:/g, "");
            var hit = null;
            for (var z = 0; z < list.length; z++) {
                var c = list[z] && list[z].mac ? list[z].mac.toLowerCase() : "";
                var cHex = c.replace(/:/g, "");
                var matched = false;
                if (c && c.indexOf(reduced) >= 0) {
                    matched = true;
                } else if (reducedHex.length >= 6 && cHex && cHex.endsWith(reducedHex)) {
                    matched = true;
                }
                if (matched) {
                    if (hit) {
                        return null;
                    }
                    hit = list[z];
                }
            }
            return hit;
        }
        var merged = [];
        for (var j = 0; j < rows.length; j++) {
            var r = rows[j] || {};
            var rip = cleanIp(r.ip);
            var rmac = cleanMac(r.mac);
            var rhost = usableHost(r.user);
            if (isMacLikeText(rhost)) {
                rhost = "";
            }
            var ref = null;
            if (rip && byIp[rip]) {
                ref = byIp[rip];
            } else {
                ref = findRefByMac(rmac);
            }
            if (ref) {
                if (ref.mac) {
                    rmac = ref.mac;
                }
                if (!rip && ref.ip) {
                    rip = ref.ip;
                }
                if ((!rhost || rhost === "Unknown") && usableHost(ref.host)) {
                    rhost = usableHost(ref.host);
                }
            }
            if (!rhost) {
                rhost = hostFromIp(rip);
            }
            if (!rhost) {
                var tail = (rmac || "").replace(/:/g, "").slice(-4);
                rhost = "Device" + (tail ? "-" + tail : "");
            }
            merged.push({
                user: rhost,
                mac: rmac,
                ip: rip,
                ssid: r.ssid || "",
                rssi: r.rssi || ""
            });
        }
        return merged;
    }
    function normalizeRows(rows) {
        var list = [];
        if (!rows || !rows.length) {
            return list;
        }
        for (var i = 0; i < rows.length; i++) {
            var item = rows[i] || {};
            var hostRaw = pickFirst(item, ["user", "host", "hostname", "name", "device", "devName"]);
            var macRaw = pickFirst(item, ["mac", "macaddr", "macAddress", "addr", "sta_mac"]);
            var ipRaw = pickFirst(item, ["ip", "ipaddr", "ipAddress", "sta_ip"]);
            var ssidRaw = pickFirst(item, ["ssid", "wifi", "wifissid"]);
            var rssiRaw = pickFirst(item, ["rssi", "signal", "dbm"]);
            var host = usableHost(hostRaw);
            var mac = cleanMac(macRaw || hostRaw);
            var ip = cleanIp(ipRaw);
            if (isMacLikeText(host)) {
                host = "";
            }
            list.push({
                user: host,
                mac: mac,
                ip: ip,
                ssid: cleanText(ssidRaw),
                rssi: cleanText(rssiRaw)
            });
        }
        return list;
    }
    var vm = new Vue({
        el: "#macInfoContainer",
        data: {
            macInfo: wirelessconfightml.macInfoContainer.macInfos,
            tableTitle: [text.no, DOC.net.host, "MAC", DOC.net.ip, "SSID",DOC.lte.signalLeveldBm],
            usrInfos: '',
            macInfos: '',
            firstRequest: true,
            tableContent: []
        },
        methods: {
            applyArp: function (wifiRows) {
                $.ajax({
                    url: "/cgi-bin/extra.cgi?action=arp_clients",
                    type: "GET",
                    dataType: "json",
                    cache: false,
                    timeout: 1500,
                    success: function (resp) {
                        var clients = resp && resp.clients ? resp.clients : [];
                        vm.tableContent = mergeWithArp(wifiRows, clients);
                    },
                    error: function () {
                        vm.tableContent = wifiRows;
                    }
                });
            },
            getData:function(){
                 Page.postJSON({
                        json: { cmd: RequestCmd.WIFI5G_LIST_INFO,method:JSONMethod.GET},
                        success: function (datas) {
                          var wifiRows = normalizeRows(datas.wlan5g_wifi_info);
                          Page.postJSON({
                              json: { cmd: RequestCmd.DHCPCLIENT_INFO, method: JSONMethod.GET },
                              success: function (dhcpDatas) {
                                  var merged = mergeWithDhcp(wifiRows, dhcpDatas.dhcp_list_info);
                                  vm.applyArp(merged);
                              },
                              error: function () {
                                  vm.applyArp(wifiRows);
                              }
                          });

                        }
                });
            }
        },
        mounted:function(){
            this.getData();
             Page.timer = setInterval(function(){
                vm.getData();
        },3000);
        }
    });
});

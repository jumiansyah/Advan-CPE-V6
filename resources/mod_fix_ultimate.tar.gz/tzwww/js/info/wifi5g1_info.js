var loading = "-";
var wifi_names = [DOC.wlan.currentMode, DOC.wlan.wifi, DOC.wlan.ssidBroadcast, DOC.wlan.ssid, DOC.wlan.channel, wirelessconfightml.form1.bandWidth, wirelessconfightml.form1.wepMode];
var wifi24G_values = new Array(7);
var wifi5G_values = new Array(7);
var form1 = wirelessconfightml.form1;
var vm_wifi = new Vue({
    el: "#wifi_content",
    data: {
        title_wlan1: DOC.title.wlan2g,
        title_wlan2: DOC.title.wlan5g,
        wifi_names: wifi_names,
        wifi24G_values: wifi24G_values,
        wifi5G_values: wifi5G_values,
        text: "",
        authenticationOption: [{
                value: "none",
                name: form1.openSys
            },
            {
                value: "psk",
                name: form1.wpa_psk
            },
            {
                value: "psk2",
                name: form1.wpa2_psk
            },
            {
                value: "mixed",
                name: form1.wpa_wpa2_psk
            }
        ],
        value: [{
                title: wifiInfohtml.helper.title3,
                item: wifiInfohtml.helper.item3
            },
            {
                title: wifiInfohtml.helper.title6,
                item: wifiInfohtml.helper.item6
            },
            {
                title: wifiInfohtml.helper.title4,
                item: wifiInfohtml.helper.item4
            },
            {
                title: wifiInfohtml.helper.title7,
                item: wifiInfohtml.helper.item7
            }
        ]
    },
    methods: {
        getWlanMode: function (mode) {
            var secMode = "";
            switch (mode) {
                case "7":
                    secMode = "11a only";
                    break;
                case "8":
                    secMode = "11n only";
                    break;
                case "9":
                    secMode = "11ac only";
                    break;
                case "10":
                    secMode = "11a/n";
                    break;
                case "11":
                    secMode = "11n/ac";
                    break;
                case "12":
                    secMode = "11a/ac";
                    break;
                case "13":
                    secMode = "11a/n/ac";
                    break;
            }
            return secMode;
        },
        getWepMode: function (mode) {
            var secMode = "";
            switch (mode) {
                case "0":
                    secMode = form1.openSys;
                    break;
                case "1":
                    secMode = "WPA-PSK";
                    break;
                case "2":
                    secMode = "WPA2-PSK";
                    break;
                case "3":
                    secMode = "WPA/WPA2-PSK";
                    break;
                case "4":
                    secMode = "WPA3-PSK";
                    break;
                case "5":
                    secMode = "WPA2/WPA3-PSK";
                    break;
                case "6":
                    secMode = "WEP";
                    break;
            }
            return secMode;
        },
        getBandWidth: function (mode) {
            var secMode = "";
            switch (mode) {
                case "0":
                    secMode = "20MHz";
                    break;
                case "1":
                    secMode = "40MHz";
                    break;
                case "3":
                    secMode = "80MHz";
                    break;
            }
            return secMode;
        },
        getData24G: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.WIRELESS5G_CONFIG,
                    methods: JSONMethod.GET,
                    wifi_advance: 1,
                    subcmd: 1
                },
                success: function (data) {
                    vm_wifi.$set(wifi24G_values, 0, vm_wifi.getWlanMode(data.wifiWorkMode) || loading);
                    vm_wifi.$set(wifi24G_values, 1, data.wifiOpen == "1" ? DOC.status.enable : DOC.status.disable);
                    vm_wifi.$set(wifi24G_values, 2, data.broadcast == "1" ? DOC.status.enable : DOC.status.disable);
                    vm_wifi.$set(wifi24G_values, 3, Base64.decode(data.ssid) || loading);
                    vm_wifi.$set(wifi24G_values, 4, data.channel == '0' ? 'Auto' : data.channel || loading);
                    vm_wifi.$set(wifi24G_values, 5, vm_wifi.getBandWidth(data.bandWidth) || loading);
                    vm_wifi.$set(wifi24G_values, 6, vm_wifi.getWepMode(data.authenticationType) || loading);
                }
            })

        }
    },
    mounted: function () {
        this.getData24G();
        Page.timer = setInterval(function () {
            vm_wifi.getData24G();
        }, 3000);
    }
});
/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-06-08 16:26:13
 * @,@LastEditTime: ,: 2021-06-08 20:25:54
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\info\wifi5g_index.js
 */
$(document).ready(function () {
    
    var tabs = TAB.advance;
    var id = "WIFI5G_INFO";
    var items = [];

    items.push({ title: "5G", url: 'html/info/wifi5g_info.html' });
    if(Page.pageHideCheck(10))
        items.push({ title: "5G_1", url: 'html/info/wifi5g1_info.html' });
    if(Page.pageHideCheck(11))    
        items.push({ title: "5G_2", url: 'html/info/wifi5g2_info.html' });
    if(Page.pageHideCheck(12))
        items.push({ title: "5G_3", url: 'html/info/wifi5g3_info.html' });
    // if(Page.pageHideCheck(13))
    //     items.push({ title: "5G_4", url: 'html/info/wifi5g4_info.html' });
    
    items.push({ title: wirelessconfightml.tab_menu.connectedList, url: 'html/info/wireless5gConnected.html' }); 

    secondMenuClick(items,id);
});


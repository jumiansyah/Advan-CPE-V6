$(document).ready(function() {
	Page.render('#sms_info', '#sms_template');

    var statusReport = false;
    // 获取是否索取短信回执
    Page.postJSON({
        json: {
            cmd: RequestCmd.GET_SMS_STATUS_REPORT,
            method: JSONMethod.POST
        },
        success: function(data) {
            if(data.statusReport == "1"){
            	statusReport = true;
            } else {
            	statusReport = false;
            }
            $('#statusReport').prop("checked", statusReport);
        }
    });

    $('#sms_title').html(Page.menuItem.title);
    var $phoneNo = $('#phoneNo'),
        $content = $('#content');

    var rules = {
        phoneNo: { required: true},
        content: { reallength: 1800 }
    };
    var messages = {
        phoneNo: { required: CHECK.required.phoneNo },
        content: { reallength: CHECK.max.smsLength }
    };

    var $lblSendSms = $('#lblSendSms');
    var $btnSave = $('#btnSave'), $btnSaveDraft = $('#btnSaveDraft');
    $btnSave.click(function() {
        if(!Page.connectStatus){
            AlertUtil.alertMsg(PROMPT.status.noNetwork);
            return;
        }
        $phoneNo.removeClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }

        var newStatusReport = $('#statusReport').prop("checked");
        if (newStatusReport != statusReport) {
            statusReport = newStatusReport;

        	Page.postJSON({
                json: {
                    cmd: RequestCmd.SET_SMS_STATUS_REPORT,
                    method: JSONMethod.POST,
                    statusReport: statusReport ? "1" : "0"
                },
                success: function(data) {
                    saveSms(SmsType.SEND);
                }
            });
        } else {
            saveSms(SmsType.SEND);
        }
    });

    $btnSaveDraft.click(function() {
        $phoneNo.addClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }
        saveSms(SmsType.DRAFT);
    });

    function saveSms(smsType) {
        var content = $content.val();

        if (smsType == SmsType.SEND) {
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.sendEmptySms)){
                    return;
                }
            }
            $lblSendSms.show();
        } else{
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.saveDraft)){
                    return;
                }
            }
        }

        $btnSave.disable();
        $btnSaveDraft.disable();

        // Gunakan custom.cgi (bukan http.cgi) untuk menghindari AT port conflict
        var endpoint = (smsType == SmsType.SEND) ? "cgi-bin/custom.cgi?action=send_sms" : "cgi-bin/custom.cgi?action=save_draft";

        $.ajax({
            url: endpoint,
            type: 'POST',
            data: { phoneNo: $phoneNo.val().trim(), content: content },
            dataType: 'json',
            timeout: 30000,
            success: function(data) {
                AlertUtil.alertMsg(data.message);
                // Clear form setelah berhasil
                $phoneNo.val('');
                $content.val('');
                $btnSave.enable();
                $btnSaveDraft.enable();
                $lblSendSms.hide();
            },
            error: function(xhr) {
                var msg = "Gagal: ";
                try { msg += JSON.parse(xhr.responseText).message; } catch(e) { msg += xhr.status + " " + (xhr.responseText || "").substring(0,100); }
                AlertUtil.alertMsg(msg);
                $btnSave.enable();
                $btnSaveDraft.enable();
                $lblSendSms.hide();
            }
        });
    }

    Page.setStripeTable();

    // Pre-fill dari Reply (sessionStorage diisi oleh smsInfo.js)
    var replyPhone = sessionStorage.getItem('sms_reply_phone');
    var replyContent = sessionStorage.getItem('sms_reply_content');
    if (replyPhone) {
        $phoneNo.val(replyPhone);
        sessionStorage.removeItem('sms_reply_phone');
    }
    if (replyContent) {
        $content.val(replyContent);
        sessionStorage.removeItem('sms_reply_content');
    }

    $phoneNo.keypress(function(e){
        if(e.keyCode == 13){
            return false;
        }
    });

    if (replyPhone) {
        // Kalau reply, fokus ke konten
        if(!$.browser.msie){
            $content.focus();
        } else {
            setTimeout(function(){ $content.focus(); }, 1000);
        }
    } else {
        if(!$.browser.msie){
            $phoneNo.focus();
        } else {
            setTimeout(function(){ $phoneNo.focus(); }, 1000);
        }
    }
});
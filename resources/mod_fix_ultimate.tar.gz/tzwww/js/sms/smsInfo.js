$(document).ready(function () {
    Page.render('#sms_pager', '#smsPager_template');
    $('#sms_title').html(Page.menuItem.title);

    var item_count = 10;
    Page.statusReport = false;
    // 获取是否索取短信回执
    Page.postJSON({
        json: {
            cmd: RequestCmd.GET_SMS_STATUS_REPORT,
            method: JSONMethod.POST
        },
        success: function (data) {
            if (data.statusReport == "1") {
                Page.statusReport = true;
            } else {
                Page.statusReport = false;
            }
        }
    });

    var pageIndex = 0,
        pageSize = 10,
        $box = $('#edit_box'),
        $mask = $('#mask'),
        $pagers = $('a[id^=pager]'),
        $lblPager = $('#lblPager');

    function filterSms(smses, smsType) {
        if (!smses || !smses.datas) {
            return smses;
        }

        var retval = [], datas = smses.datas, len = datas.length, i, item;
        for (i = 0; i < len; i++) {
            item = datas[i];
            if (smsType == SmsType.RECEIVE) {
                if (item.status == "0" || item.status == "1") {
                    retval.push(item);
                }
            } else if (smsType == SmsType.SEND) {
                if (item.status == "3") {
                    item.status = "1";
                    retval.push(item);
                }
            } else {
                if (item.status == "2") {
                    //item.status = "1";
                    retval.push(item);
                }
            }
        }

        smses.datas = retval;

        return smses;
    }

    function getSmsList() {
        $.getJSON("cgi-bin/custom.cgi?action=read_sms", function (data) {
            if (!data) { data = { datas: [] }; }
            if (!data.datas) { data.datas = []; }
            data = filterSms(data, Page.menuItem.smsType);
            createTable(data);
        }).fail(function () {
            createTable({ datas: [] });
        });
    }

    function createTable(data) {
        var datas = data.datas;
        var recordCount = datas.length;
        var pageCount = parseInt((recordCount - 1) / pageSize, 10) + 1;
        pageIndex = Math.min(Math.max(0, pageIndex), pageCount - 1);

        var pagerHtml = String.format(DOC.pager.total, recordCount);
        if (recordCount > 0) {
            pagerHtml = String.format(DOC.pager.currentPage, pagerHtml, pageIndex + 1, pageCount);
        }
        $lblPager.html(pagerHtml);

        if (recordCount == 0 || pageCount == 1) {
            $pagers.hide();
        } else {
            if (pageIndex == 0) {
                $pagers.eq(0).hide();
                $pagers.eq(1).hide();
                $pagers.eq(2).show();
                $pagers.eq(3).show();
            } else if (pageIndex == pageCount - 1) {
                $pagers.eq(0).show();
                $pagers.eq(1).show();
                $pagers.eq(2).hide();
                $pagers.eq(3).hide();
            } else {
                $pagers.show();
            }
        }

        var temp;
        for (var i = 0; i < recordCount; i++) {
            for (var j = i + 1; j < recordCount; j++) {
                if (datas[i].datetime < datas[j].datetime) {
                    temp = datas[i];
                    datas[i] = datas[j];
                    datas[j] = temp;
                }
            }
        }

        var items = [];
        var beginIndex = pageIndex * pageSize, endIndex = Math.min(beginIndex + pageSize, recordCount);
        for (var i = beginIndex; i < endIndex; i++) {
            items.push(datas[i]);
        }

        SmsUtil.createTable({
            id: '#sms_info',
            smsType: Page.menuItem.smsType,
            datas: items,
            pageIndex: pageIndex,
            pageSize: pageSize,
            edit: function (id, phoneNo, content) {
                // Simpan data reply ke sessionStorage agar smsNew.js bisa pre-fill
                if (phoneNo) sessionStorage.setItem('sms_reply_phone', phoneNo);
                if (content) sessionStorage.setItem('sms_reply_content', content);
                // Redirect ke halaman New SMS
                Page.menuItem = MenuItem.SMS_NEW;
                Page.$iframe.load(MenuItem.SMS_NEW.url);
                window.location.hash = "#SMS_NEW#0";
                Page.setHash(window.location.hash);
            },
            del: function (smsId, smsIndex) {
                if (!confirm(PROMPT.confirm.deleteSms)) return;

                $.getJSON("cgi-bin/custom.cgi?action=delete_sms&smsId=" + smsId, function (data) {
                    getSmsList();
                });
            }
        });
    }

    $('#btnAdd').click(function () {
        // Redirect ke halaman New SMS (bukan inline edit yang blank)
        Page.menuItem = MenuItem.SMS_NEW;
        Page.$iframe.load(MenuItem.SMS_NEW.url);
        window.location.hash = "#SMS_NEW#0";
        Page.setHash(window.location.hash);
    });

    function editSms(id, phoneNo, content) {
        var $mask = $('#mask'),
            $box = $('#edit_box');

        // Build edit form HTML inline (bypass http.cgi yang rusak)
        var editTitle = (id == "-1" && phoneNo) ? DOC.sms.reply : DOC.menu.sms.add;
        var html = '<div class="detail">' +
            '<div id="edit_title">' + editTitle + '</div>' +
            '<div id="edit_close"><input id="btnCloseSms" type="button" value="' + DOC.btn.close + '" /></div>' +
            '<div style="clear:both;"></div>' +
            '</div>' +
            '<form id="form1">' +
            '<table class="detail" cellspacing="0">' +
            '<tr><th>' + DOC.sms.receiver + '</th><td>' +
            '<input type="hidden" id="smsId" name="smsId" value="-1" />' +
            '<input type="text" id="phoneNo" name="phoneNo" class="normal" maxlength="20" />' +
            '<input type="checkbox" id="statusReport" name="statusReport" />' + DOC.sms.statusReport +
            '<label id="lblSendSms" class="msg" style="display: none;">' + PROMPT.status.sendingSms + '</label>' +
            '</td></tr>' +
            '<tr><th>' + DOC.sms.content + '</th>' +
            '<td><textarea id="content" name="content" cols="80" rows="8"></textarea></td></tr>' +
            '<tr><th>&nbsp;</th><td>' +
            '<input type="button" id="btnSave" value="' + DOC.btn.send + '"/>' +
            '<input type="button" id="btnSaveDraft" value="' + DOC.btn.saveDraft + '"/>' +
            '</td></tr></table></form>';

        $mask.show();
        $box.show();
        $box.html(html);
        $box.css({
            width: 800,
            height: 300
        });
        SysUtil.setBoxStyle($box);

        Page.setStripeTable('#edit_box table');
        var $phoneNo = $('#phoneNo'),
            $content = $('#content');

        // Close button handler
        $('#btnCloseSms').click(function () {
            $box.hide();
            $mask.hide();
        });

        $('#statusReport').prop("checked", Page.statusReport);

        if (id == "-1" && phoneNo) {
            if (!$.browser.msie) {
                $content.focus();
            } else {
                setTimeout(function () {
                    $content.focus();
                }, 1000);
            }
        } else {
            if (!$.browser.msie) {
                $('#edit_box input[type=text]:first').focus();
            } else {
                setTimeout(function () {
                    $('#edit_box input[type=text]:first').focus();
                }, 1000);
            }
        }
        $('#smsId').val(id);
        $phoneNo.val(phoneNo || "");
        $content.val(content || "");

        var rules = {
            phoneNo: { required: true },
            content: { reallength: 1800 }
        };
        var messages = {
            phoneNo: { required: CHECK.required.phoneNo },
            content: { reallength: CHECK.max.smsLength }
        };

        var $lblSendSms = $('#lblSendSms');
        var $btnSave = $('#btnSave'), $btnSaveDraft = $('#btnSaveDraft');
        $btnSave.click(function () {
            if (!Page.connectStatus) {
                AlertUtil.alertMsg(PROMPT.status.noNetwork);
                return;
            }
            $phoneNo.removeClass("ignore");
            if (!CheckUtil.checkForm($('#form1'), rules, messages)) {
                return false;
            }

            var newStatusReport = $('#statusReport').prop("checked");
            if (newStatusReport != Page.statusReport) {
                Page.statusReport = newStatusReport;

                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SET_SMS_STATUS_REPORT,
                        method: JSONMethod.POST,
                        statusReport: Page.statusReport ? "1" : "0"
                    },
                    success: function (data) {
                        saveSms(SmsType.SEND);
                    }
                });
            } else {
                saveSms(SmsType.SEND);
            }
        });

        $btnSaveDraft.click(function () {
            $phoneNo.addClass("ignore");
            if (!CheckUtil.checkForm($('#form1'), rules, messages)) {
                return false;
            }
            saveSms(SmsType.DRAFT);
        });

        $phoneNo.keypress(function (e) {
            if (e.keyCode == 13) {
                return false;
            }
        });

        function saveSms(smsType) {
            var content = $content.val();

            if (smsType == SmsType.SEND) {
                if (!content) {
                    if (!AlertUtil.confirm(PROMPT.confirm.sendEmptySms)) {
                        return;
                    }
                }
                $lblSendSms.show();
            } else {
                if (!content) {
                    if (!AlertUtil.confirm(PROMPT.confirm.saveDraft)) {
                        return;
                    }
                }
            }
            $btnSave.disable();
            $btnSaveDraft.disable();

            var endpoint = (smsType == SmsType.SEND) ? "cgi-bin/custom.cgi?action=send_sms" : "cgi-bin/custom.cgi?action=save_draft";

            $.ajax({
                url: endpoint,
                type: 'POST',
                data: { phoneNo: $phoneNo.val().trim(), content: content },
                dataType: 'json',
                timeout: 30000,
                success: function (data) {
                    AlertUtil.alertMsg(data.message);
                    getSmsList();
                    $btnSave.enable();
                    $btnSaveDraft.enable();
                    $lblSendSms.hide();
                },
                error: function(xhr) {
                    var msg = "Gagal: ";
                    try { msg += JSON.parse(xhr.responseText).message; } catch(e) { msg += xhr.status + " " + (xhr.responseText || "").substring(0,100); }
                    AlertUtil.alertMsg(msg);
                    getSmsList();
                    $btnSave.enable();
                    $btnSaveDraft.enable();
                    $lblSendSms.hide();
                }
            });
        }
    }

    $pagers.click(function () {
        var index = $pagers.index(this);
        switch (index) {
            case 0:
                pageIndex = 0;
                break;
            case 1:
                pageIndex--;
                break;
            case 2:
                pageIndex++;
                break;
            case 3:
                pageIndex = 999999;
                break;
        }
        getSmsList();
    });

    $('#btnDelete').click(function () {
        var ids = [], smdIndexes = [];
        $('input[id^=chkSms]').each(function () {
            if ($(this).prop("checked")) {
                var id = this.id.slice(6);
                ids.push($('#hddSmsId' + id).val());
                smdIndexes.push($('#hddSmsIndex' + id).val());
            }
        });
        var length = ids.length;
        if (length == 0) {
            AlertUtil.alertMsg(PROMPT.status.chooseSms);
            return;
        }

        if (!confirm(PROMPT.confirm.deleteSms)) return;

        var ids_index = 0, last_ids_index = 0, count = 0,
            step_max = parseInt(100 / length, 10),
            step = parseInt(10 / length, 10);

        delSingleSms();
        SysUtil.showProgress_2(PROMPT.status.deletingSms, checkDelSmsStatus, processComplete);

        var stopped = false;
        function checkDelSmsStatus() {
            if (stopped) return 100;

            if (last_ids_index < ids_index) {
                count = 0;
                last_ids_index = ids_index;
            }

            if (count < (step_max - step)) {
                count += step;
            }

            var ret = parseInt((100 * ids_index) / length, 10) + count;
            if (ret > 100) {
                ret = 100;
            }

            return ret;
        }

        function delSingleSms() {
            $.getJSON("cgi-bin/custom.cgi?action=delete_sms&smsId=" + ids[ids_index], function (data) {
                ids_index++;
                if (ids_index < length) {
                    if (Page.menuItem.smsType != SmsType.RECEIVE) {
                        // 非收件箱的短信删除时延时
                        setTimeout(delSingleSms, 200);
                    } else {
                        delSingleSms();
                    }
                }
            }).fail(function () {
                stopped = true;
                AlertUtil.alertMsg("Gagal menghapus pesan");
            });
        }
    });

    function processComplete() {
        $('#mask').hide();
        $('#progress_box').hide();
        getSmsList();
    }

    $('#btnDeleteAll').click(function () {
        if (!confirm(PROMPT.confirm.deleteAllSms)) return;

        var ids_index = 0;
        loop();

        var stopped = false;
        function loop() {
            if (stopped) {
                ids_index = 100;
                return;
            }

            if (ids_index < 99) {
                ids_index++;
            }
            if (Page.menuItem.smsType != SmsType.RECEIVE) {
                setTimeout(loop, 50);
            } else {
                setTimeout(loop, 20 * item_count);
            }
        }

        $.getJSON("cgi-bin/custom.cgi?action=delete_sms&clear=1", function (data) {
            setTimeout(function () {
                ids_index = 100;
            }, 500);
        }).fail(function () {
            stopped = true;
            AlertUtil.alertMsg("Gagal mengosongkan direktori");
        });

        SysUtil.showProgress_2(PROMPT.status.deletingSms, checkDelAllSmsStatus, processComplete);

        function checkDelAllSmsStatus() {
            return ids_index;
        }
    });

    getSmsList();
});

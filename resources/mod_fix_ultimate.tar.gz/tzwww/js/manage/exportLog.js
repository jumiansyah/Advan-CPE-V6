$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            exportCfg: DOC.sys.exportLog,
            exportDelegateShow: false,
            exportDelegateText: DOC.link.clickMeDownload,
            exportUrl: "",
            colon: DOC.colon,
        },
        methods: {
            btnExportConfigClick: function () {
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.EXPORT_LOG
                    },
                    success: function (data) {
                        fyAlertDestory();
                        vm.exportUrl = '/logs_backup.tar.gz.encode';
                        vm.exportDelegateShow = true;
                    }
                });
            }
        }
    })

});
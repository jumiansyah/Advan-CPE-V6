$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    var rules = {
        vpn_url: { required: true, url_filter_check: true }, //url: true
        vpn_mtu: { digits: true, range: [1000, 1460] },
        presharedKey: {required: true }
    }, messages = {
        vpn_url: { required: CHECK.required.remoteServer, url_filter_check: CHECK.tip.urlOrIp },
        vpn_mtu: { digits: CHECK.format.digits, range: CHECK.range.l2tpMtuRange },
        presharedKey: {required: wirelessconfightml.prompt.noEmpty }
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            help: [DOC.vpn.l2tpHelpTitle,DOC.vpn.l2tpHelpText],
            vpn_switch: false,
            vpn_url: "",
            username: "",
            passwd: "",
            vpn_mtu: "",
            lnsCheckup: "",
            IPSec: '',
            presharedKey: '',
            vpn_status: "",
            vpn_local_ip: "",
            vpn_peer_ip: "",
            vpn_ipsec_status: '',
            vpn_mode: "",
            vpn_nat: "",
            vpn_defualt: "",
            mppe: "",
            vpnModeList: [{
                name:"L2TP",
                value: "0"
            },{
                name:"PPTP",
                value: "1"
            }],
            loading:false,
            showIPSec: Page.pageHideCheck(55)
        },
        methods: {
            getData: function () {
                var json = { cmd: RequestCmd.VPN_CONFIG };
                if(!!this.vpn_mode){
                    json.subcmd = this.vpn_mode;
                    this.loading = true;
                }
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(!vm.loading){
                            vm.vpn_switch = data.vpn_switch == "1" ? true : false;
                            vm.vpn_mode = data.vpn_mode;
                            vm.vpn_nat = data.vpn_nat == "1" ? true : false;
                        }
                        vm.vpn_url = data.vpn_url;
                        vm.username = data.username;
                        vm.passwd = data.passwd;
                        vm.vpn_mtu = data.vpn_mtu;
                        vm.lnsCheckup = data.lnsCheckup == "1" ? true : false;
                        vm.IPSec = data.IPSec == "1" ? true : false;
                        vm.presharedKey = data.presharedKey;
                        vm.vpn_defualt = data.vpn_defualt == "1" ? true : false;
                        vm.vpn_status = data.vpn_status == "1" ? '<span>'+DOC.status.connected+'</span>':'<span style="color:red">'+DOC.status.disconnected+'</span>';
                        if(!!data.vpn_local_ip && data.vpn_local_ip !="0"){
                            vm.vpn_local_ip = '<span>'+data.vpn_local_ip+'</span>';
                        } else {
                            vm.vpn_local_ip = '<span style="color:red">'+DOC.vpn.l2tpIPFail+'</span>';
                        }
                        if(!!data.vpn_peer_ip && data.vpn_peer_ip !="0"){
                            vm.vpn_peer_ip = '<span>'+data.vpn_peer_ip+'</span>';
                        } else {
                            vm.vpn_peer_ip = '<span style="color:red">'+DOC.vpn.l2tpIPFail+'</span>';
                        }
                        if(!!data.vpn_ipsec_status && data.vpn_ipsec_status !="0"){
                            vm.vpn_ipsec_status = '<span>'+DOC.status.connected+'</span>';
                        } else {
                            vm.vpn_ipsec_status = '<span style="color:red">'+DOC.status.disconnected+'</span>';
                        }
                        vm.loading = false;
                    }
                });
            },
            changeMode: function(){
                this.getData();
            },
            clickBtnSave: function () {
                var json = {};
                if ($(".fy-alert-shadow").length > 0) {
                    return false;
                }
                if (!this.vpn_switch) {
                    json.vpn_switch = "0";
                } else {
                    if(this.vpn_mode == "1"){
                        rules.vpn_mtu.range = [576, 1460];
                        json.subcmd = "1";
                    } else {
                        json.subcmd = "0";
                        json.lnsCheckup = this.lnsCheckup ? "1" : "0";
                        json.IPSec = this.IPSec ? "1" : "0";
                        if(this.IPSec){
                            json.presharedKey = this.presharedKey;
                        }
                    }
                    var $form = $("#childForm");
                    if (!CheckUtil.checkForm($form, rules, messages)) {
                        return;
                    }
                    json.vpn_defualt = vm.vpn_defualt ? "1" : "0";
                    json.vpn_switch = "1";
                    json.vpn_mode = this.vpn_mode;
                    json.vpn_nat = this.vpn_nat ? "1" : "0";
                    json.vpn_url = vm.vpn_url;
                    json.username = vm.username;
                    json.passwd = vm.passwd;
                    json.vpn_mtu = vm.vpn_mtu;
                }
                json.cmd = RequestCmd.VPN_CONFIG;
                json.method = JSONMethod.POST;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.flag === "0") {
                            fyAlertMsgFail();
                        } else {
                            setTimeout(function(){
                                fyAlertMsgSuccess();
                                vm.getData();
                            },1500)
                        }
                    }
                });
            }
        },
        mounted: function () {
            Page.createForm2(fm);
            this.getData()
        }
    });
});
$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    var rules = {
        ruleName: { required: true },
        mtu:{required: true, digits: true, range: [1, 1500]},
        localIp: { required: true, ip: true },
        localSubnetIp: { required: true, ip: true },
        localMask: { required: true, subnetmask_check: true },
        peerIp: { required: true, ip: true },
        peerSubnetIp: { required: true, ip: true },
        peerMask: { required: true, subnetmask_check: true },
        ikeLifeTime:{required: true, digits: true, range: [0, 24]},
        lifeTime:{required: true, digits: true, range: [0, 24]},
        ikeDpddelay:{required: true, digits: true, range: [10, 999]},
        ikeDpdtimeout:{required: true, digits: true, range: [30, 1000]},
    }, messages = {
        ruleName: { required: CHECK.required.noEmpty},
        mtu: { required: CHECK.required.noEmpty, digits: CHECK.format.digits, range: CHECK.range.common+'1~1500'},
        localIp: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 },
        localSubnetIp: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 },
        localMask: { required: CHECK.required.netmask, subnetmask_check: CHECK.required.netmaskCheck },
        peerIp: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 },
        peerSubnetIp: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 },
        peerMask: { required: CHECK.required.netmask, subnetmask_check: CHECK.required.netmaskCheck },
        ikeLifeTime: { required: CHECK.required.noEmpty, digits: CHECK.format.digits, range: CHECK.range.common+'0~24'},
        lifeTime: { required: CHECK.required.noEmpty, digits: CHECK.format.digits, range: CHECK.range.common+'0~24'},
        ikeDpddelay: { required: CHECK.required.noEmpty, digits: CHECK.format.digits, range: CHECK.range.common+'10~999'},
        ikeDpdtimeout: { required: CHECK.required.noEmpty, digits: CHECK.format.digits, range: CHECK.range.common+'30~1000'},
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            ipsecSwitch: false,//开关
            ruleName: '',   //规则名称
            connectType: 'tunnel', //连接模式
            mtu: '', //MTU
            localIp: '', //本地网关
            localSubnetIp: '', //本地子网
            localMask: '', //本地子网掩码
            peerIp: '', //对端网关
            peerSubnetIp: '', //对端子网
            peerMask: '', //对端子网掩码
            ikeEncrypt: 'des', //加密算法
            ikeDic: 'md5', //认证算法
            preshare: '', //预共享密钥
            ikeGroup: 'modp768', //DH Group
            ikeLifeTime: '', //IKE SA生存周期
            ikeDpdSwitch: false, //失效对端检测
            ikeDpddelay: '', //DPD延时时间
            ikeDpdtimeout: '',//DPD超时时间
            lifeTime: '', //IPSec SA 生存周期
            encrypt: 'des',//IPSEC 加密算法
            dic: 'md5',//完整性算法
            group: 'none',//PFS KEY Group
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: { 
                        cmd: RequestCmd.IPSEC_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.ipsecSwitch = data.ipsecSwitch == "1" ? true : false;
                        vm.ruleName = data.ruleName;
                        vm.connectType = data.connectType;
                        vm.mtu = data.mtu;
                        vm.localIp = data.localIp;
                        vm.localSubnetIp = data.localSubnetIp;
                        vm.localMask = data.localMask;
                        vm.peerIp = data.peerIp;
                        vm.peerSubnetIp = data.peerSubnetIp;
                        vm.peerMask = data.peerMask;
                        vm.ikeEncrypt = data.ikeEncrypt;
                        vm.ikeDic = data.ikeDic;
                        vm.preshare = data.preshare;
                        vm.ikeGroup = data.ikeGroup;
                        vm.ikeLifeTime = data.ikeLifeTime;
                        vm.ikeDpdSwitch = data.ikeDpdSwitch == "1" ? true : false;
                        vm.ikeDpddelay = data.ikeDpddelay;
                        vm.ikeDpdtimeout = data.ikeDpdtimeout;
                        vm.lifeTime = data.lifeTime;
                        vm.encrypt = data.encrypt;
                        vm.dic = data.dic;
                        vm.group = data.group;
                    }
                })
            },
            clickBtnSave: function () {
                if ($(".fy-alert-shadow").length > 0) {
                    return false;
                }
                var json = {};
                if (!this.ipsecSwitch) {
                    json.ipsecSwitch = "0";
                } else {
                    var $form = $("#childForm");
                    if (!CheckUtil.checkForm($form, rules, messages)) {
                        return;
                    }
                    json.ipsecSwitch = "1";
                    json.ruleName = this.ruleName;
                    json.connectType = this.connectType;
                    json.mtu = this.mtu;
                    json.localIp = this.localIp;
                    json.localSubnetIp = this.localSubnetIp;
                    json.localMask = this.localMask;
                    json.peerIp = this.peerIp;
                    json.peerSubnetIp = this.peerSubnetIp;
                    json.peerMask = this.peerMask;
                    json.ikeEncrypt = this.ikeEncrypt;
                    json.ikeDic = this.ikeDic;
                    json.preshare = this.preshare;
                    json.ikeGroup = this.ikeGroup;
                    json.ikeLifeTime = this.ikeLifeTime;
                    json.ikeDpdSwitch = this.ikeDpdSwitch ? "1" : "0";
                    json.ikeDpddelay = this.ikeDpddelay;
                    json.ikeDpdtimeout = this.ikeDpdtimeout;
                    json.lifeTime = this.lifeTime;
                    json.encrypt = this.encrypt;
                    json.dic = this.dic;
                    json.group = this.group;
                }
                json.cmd = RequestCmd.IPSEC_CONFIG;
                json.subcmd = 0;
                json.method = JSONMethod.POST;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.flag == "1") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
            Page.createForm2(fm);
        }
    });
});
$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    var rules = {
        tunnel:{required: true},
        url: { required: true, url_filter_check: true },
        peerIpValue: { required: true, ip: true },
        greIpValue: { required: true, ip: true }
    }, messages = {
        tunnel: { required: CHECK.required.tunnelName },
        url: { required: CHECK.required.remoteServer, url_filter_check: CHECK.tip.urlOrIp },
        peerIpValue: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 },
        greIpValue: { required: networkconfightml.prompt.ipCheckMsg1, ip: networkconfightml.prompt.ipCheckMsg3 }
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            greSwitchVPN: DOC.vpn.greSwitch,
            serverAddress: DOC.vpn.greAddress,
            greTunnel: DOC.vpn.greTunnel,
            peerIp: DOC.vpn.peerIp,
            greIP: DOC.vpn.greIp,
            btn_save: DOC.btn.save,
            greSwitch: false,
            url: "",
            tunnel: "",
            peerIpValue: "",
            greIpValue: ""
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: { cmd: RequestCmd.GRE_SETTING },
                    success: function (data) {
                        vm.greSwitch = data.greSwitch == "1" ? true : false;
                        vm.url = data.url;
                        vm.tunnel = data.tunnel;
                        vm.peerIpValue = data.peerIpValue;
                        vm.greIpValue = data.greIpValue;
                    }
                })
            },
            clickBtnSave: function () {
                var json = {};
                if ($(".fy-alert-shadow").length > 0) {
                    return false;
                }
                if (!this.greSwitch) {
                    json.greSwitch = "0";
                } else {
                    var $form = $("#childForm");
                    if (!CheckUtil.checkForm($form, rules, messages)) {
                        return;
                    }
                    json.greSwitch = "1";
                    json.url = this.url;
                    json.tunnel = this.tunnel;
                    json.peerIpValue = this.peerIpValue;
                    json.greIpValue = this.greIpValue;
                }
                json.cmd = RequestCmd.GRE_SETTING;
                json.method = JSONMethod.POST;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.flag == "1") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
            Page.createForm2(fm);
        }
    });
});
$(document).ready(function () {
    var fm1 = ["form1", "child_container", "form1Id"];
    Page.createForm(fm1);
    Page.setStripeTable();
    var vm = new Vue({
        el: "#child_container",
        data: {
            Switch: DOC.sys.remotePacketsCaptureSwitch,
            portBinding: DOC.sys.remotePacketsCapturePortBinding,
            colon: DOC.colon,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            save: DOC.btn.save,
            switchValue: false,
            portBindingValue: '',
            btnDis: false
        },
        methods: {
            getDate: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.REMOTE_PACKET_CAPTURE
                    },
                    success: function (datas) {
                        vm.switchValue = datas.rpcapd_enable == "1" ? true : false;
                        vm.portBindingValue = datas.rpcapd_port;
                    }
                });
            },
            btnSave: function () {
                vm.btnDis = true;
                var json = new Object();
                json.rpcapd_enable = vm.switchValue ? "1" : "0";
                json.rpcapd_port = vm.portBindingValue;
                if (json.rpcapd_enable == "1") {
                    if (vm.portBindingValue == "") {
                        AlertUtil.alertMsg(CHECK.required.port);
                        vm.btnDis = false;
                        return false;
                    }
                    var checkInfo = CheckUtil.checkPort(vm.portBindingValue)
                    if (!checkInfo.isValid) {
                        AlertUtil.alertMsg(CHECK.format.port);
                        vm.btnDis = false;
                        return false;
                    }
                    json.rpcapd_port = checkInfo.port;
                }
                fyAlertMsgLoading();
                json.cmd = RequestCmd.REMOTE_PACKET_CAPTURE;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (!!data.saveFail) {
                            fyAlertMsgFail();
                        } else {
                            fyAlertMsgSuccess();
                        };
                        vm.btnDis = false;
                    }
                });
            }

        }
    });
    vm.getDate();
});
$(document).ready(function() {
	var tabs = TAB.tools;
	var items = [];
	var id = "NETWORK_TOOLS";
	items.push({title: tabs.ping, url: 'html/tools/ping.html'});
	items.push({title: tabs.tcpdump, url: 'html/tools/tcpdump.html'});
	items.push({title: tabs.trace, url: 'html/tools/tracepath.html'});
	if(Page.pageHideCheck(43)){
		items.push({title: TAB.sys.remotePacketsCapture, url: 'html/tools/restoreFactory.html'});
	}
	
	secondMenuClick(items,id);
});

$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "FW_UPNP";
    var items = [];

    items.push({ title: MENU.fw.upnp, url: 'html/firewall/upnp.html' });
    
    secondMenuClick(items,id);
});

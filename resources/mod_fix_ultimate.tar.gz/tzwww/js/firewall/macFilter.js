$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, wifiInfohtml.helper.title5,
        DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule
    ];
    var htmlData = []
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            all: DOC.lbl.all,
            tcp: DOC.net.tcp,
            udp: DOC.net.udp,
            ipAddress: dialconfightml.vpnTable.vpnMacTh,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            save: DOC.btn.save,
            close: DOC.btn.close,
            macFiltering: TAB.fw.macFiltering,
            radioModelValue: false,
            ipAddressValue: "",
            commentValue: "",
            flag: "",
            isWork: false,
            ipproValue: "IPV4",
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }

                    }
                });
            },
            applyRulesClick: function () {
                this.isWork = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isWork = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.MAC_FILTER,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.ipproValue = "IPV4";
                this.ipAddressValue = "";
                this.commentValue = ""
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            btnSave: function () {
                if (this.ipAddressValue == "") {
                    AlertUtil.alertMsg(CHECK.required.mac);
                    return false;
                }
                if (!CheckUtil.checkMac(this.ipAddressValue)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                var arr = {
                    enableLink: this.radioModelValue,
                    remark: this.commentValue,
                    ippro: this.ipproValue,
                    mac: this.ipAddressValue.match(/[0-9a-f]{2}/ig).join(":").toUpperCase()
                }
                for(var i=0;i<this.value.length;i++){
                    var flag = 0;
                    if(this.value[i].ippro == arr.ippro){
                        flag+=1;
                    }
                    if(this.value[i].mac == arr.mac){
                        flag+=1;
                    }
                    if(flag == 2){
                        if(this.flag === i && (this.value[i].remark != arr.remark || this.value[i].enableLink != arr.enableLink)){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.flag === "number"){
                    arr.enableRule = this.value[this.flag].enableRule;
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true;
                    this.value.push(arr);
                }
                this.btnCloseClick();
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
            },
            editClick: function (event, index) {
                this.flag = index;
                this.ipAddressValue = event.mac;
                this.commentValue = event.remark;
                this.ipproValue = event.ippro;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                })
            }
        },
        mounted: function(){
            this.getData();
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEFAULT_FILTER,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    if(!!data.datas){
                        vm.radioModelValue = !data.datas[0].acceptAll;
                    } else {
                        vm.radioModelValue = false;
                    }
                }
            });
        }
    });
    var $box = $('#edit_box'),
        $mask = $('#mask');
});
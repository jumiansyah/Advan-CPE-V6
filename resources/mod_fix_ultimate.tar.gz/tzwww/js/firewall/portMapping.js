$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.protocol, DOC.net.portStart, DOC.net.mappingIp, DOC.net.mappingPort, DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule];
    var htmlData = []
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            colon: DOC.colon,
            protocol: DOC.net.protocol,
            portMode: DOC.net.portMode,
            mappingIp: DOC.net.mappingIp,
            tcp: DOC.net.tcp,
            mappingPort: DOC.net.mappingPort,
            portStart: DOC.net.portStart,
            udp: DOC.net.udp,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            all: DOC.lbl.all,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            save: DOC.btn.save,
            close: DOC.btn.close,
            portEnd: DOC.net.portEnd,
            addPortMapping: DOC.title.addPortMapping,
            oneToOne: DOC.net.oneToOne,
            manyToMany: DOC.net.manyToMany,
            portRangeText: DOC.net.portRange,
            lblPortRange: DOC.lbl.portRange,
            redirectPortValue: "",
            redirectAddrValue: "",
            portEndValue: "",
            portStartValue: "",
            commentValue: "",
            ProtocolValue: "all",
            flag: "",
            portRangeShow: false,
            isApply: false,
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.OTHER_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }

                    }
                });
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.ProtocolValue = "all";
                this.commentValue = "";
                this.portStartValue = "";
                this.portEndValue = "";
                this.redirectAddrValue = "";
                this.redirectPortValue = "";
                this.portRangeShow = false;
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            applyRulesClick: function () {
                fyAlertMsgLoading();
                this.isApply = true;
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.OTHER_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isApply = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail()
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.OTHER_FILTER,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail()
                            }
                        }
                    });
                })

            },
            btnSave: function () {
                var portStartValue = this.portStartValue;
                var redirectAddrValue = this.redirectAddrValue;
                var redirectPortValue = parseInt(this.redirectPortValue, 10);

                // Start Port校验
                if (this.portStartValue == "") {
                    AlertUtil.alertMsg(CHECK.required.startPort);
                    return;
                }
                if (!(/^[0-9]+$/.test(portStartValue))) {
                    AlertUtil.alertMsg(CHECK.format.startPort);
                    return;
                }
                if (portStartValue < 0 || portStartValue > 65535) {
                    AlertUtil.alertMsg(CHECK.range.startPort);
                    return;
                }

                // Mapping IP校验
                if (redirectAddrValue == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return;
                }
                if (!CheckUtil.checkIp(redirectAddrValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return;
                }

                // Mapping Port校验
                if (this.redirectPortValue == "") {
                    AlertUtil.alertMsg(CHECK.required.mappingPort);
                    return;
                }
                if (!/^[0-9]*[1-9][0-9]*$/.test(this.redirectPortValue)) {
                    AlertUtil.alertMsg(CHECK.format.mappingPort);
                    return;
                }
                if (redirectPortValue < 0 || redirectPortValue > 65535) {
                    AlertUtil.alertMsg(CHECK.range.mappingPort);
                    return;
                }

                var arr = {
                    port: this.portStartValue,
                    mappingIpPort: this.redirectAddrValue + ":" + this.redirectPortValue,
                    mappingIp: this.redirectAddrValue,
                    mappingPort: this.redirectPortValue,
                    remark: this.commentValue,
                    enableRule: true,
                    protocol: this.ProtocolValue
                };
                if(typeof this.flag === "number"){
                    this.value[this.flag].port = this.portStartValue;
                    this.value[this.flag].protocol = this.ProtocolValue;
                    this.value[this.flag].remark =this.commentValue;
                    this.value[this.flag].mappingIp = this.redirectAddrValue;
                    this.value[this.flag].mappingPort = this.redirectPortValue;
                    this.value[this.flag].mappingIpPort = this.redirectAddrValue + ":" + this.redirectPortValue;
                } else {
                    this.value.push(arr);
                }
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
                this.btnCloseClick();
            },
            editClick: function (index) {
                this.flag = index;
                this.ProtocolValue = this.value[index].protocol;
                this.commentValue = this.value[index].remark;
                this.portStartValue = this.value[index].port;
                this.redirectAddrValue = this.value[index].mappingIp;
                this.redirectPortValue = this.value[index].mappingPort;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    });
    var $box = $('#edit_box'),$mask = $('#mask');
});
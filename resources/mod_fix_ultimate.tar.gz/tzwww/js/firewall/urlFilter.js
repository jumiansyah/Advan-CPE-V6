$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, DOC.net.url, DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule];
    var strRegex = "^((http|ftp|rtsp|mms|https)?://)" +
        "?(([0-9a-zA-Z_!~*'().&=+$%-]+: )?[0-9a-zA-Z_!~*'().&=+$%-]+@)?" //ftp的user@
        +
        "(([0-9]{1,3}\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
        +
        "|" // 允许IP和DOMAIN（域名）
        +
        "([0-9a-zA-Z_!~*'()-]+\.)*" // 域名- www.
        +
        "([0-9a-zA-Z][0-9a-zA-Z-]{0,61})?[0-9a-zA-Z]\." // 二级域名
        +
        "[a-zA-Z]{2,6})" // first level domain- .com or .museum
        +
        "(:[0-9]{1,4})?" // 端口- :80
        +
        "((/?)|" +
        "(/[0-9a-zA-Z_!~*'().;?:@&=+$,%#-]+)+/?)$";
    var reg = new RegExp(strRegex);
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            save: DOC.btn.save,
            close: DOC.btn.close,
            urlFilter: MENU.fw.urlFilter,
            urlKeyword: DOC.lbl.urlKeyword,
            advancedOptions: DOC.lbl.advancedOptions,
            commentValue: "",
            flag: "",
            btnSaveShow: true,
            editSaveShow: false,
            isWork: false,
            urlValue: "",
            lanDiv: false,
            ipproValue: "IPV4",
            isApply: false,
            showTip: false,
            radioModelValue: true
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_DEFAULT_FILTER,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if(!!data.datas){
                            vm.radioModelValue = !data.datas[0].acceptAll;
                        } else {
                            vm.radioModelValue = false;
                        }
                    }
                });
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.urlValue = "";
                this.commentValue = "";
                this.btnSaveShow = true;
                this.editSaveShow = false;
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            applyRulesClick: function () {
                fyAlertMsgLoading();
                this.isApply = true;
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isApply = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.URL_FILTER,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            },
            btnSave: function () {
                if (this.urlValue == "") {
                    AlertUtil.alertMsg(CHECK.required.url);
                    return false;
                }
                if (!(reg.test(this.urlValue))) {
                    AlertUtil.alertMsg(CHECK.format.url);
                    return false;
                }
                var arr = {
                    enableLink: this.radioModelValue,
                    remark: this.commentValue,
                    ippro: this.ipproValue,
                    url: this.urlValue
                }
                for(var i=0;i<this.value.length;i++){
                    var flag = 0 ;
                    if(this.value[i].ippro == arr.ippro){
                        flag += 1;
                    }
                    if(this.value[i].url == arr.url){
                        flag += 1;
                    }
                    if(flag == 2){
                        if(this.flag === i && (this.value[i].remark != arr.remark || this.value[i].enableLink != arr.enableLink)){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if (typeof this.flag === "number") {
                    arr.enableRule = this.value[this.flag].enableRule;
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true;
                    this.value.push(arr);
                }
                this.showTip = false;
                this.$nextTick(function(){
                    this.showTip = true;
                });
                this.btnCloseClick();
            },
            editClick: function (event, index) {
                this.flag = index;
                this.commentValue = event.remark;
                this.urlValue = event.url;
                this.ipproValue = event.ippro;
                this.btnSaveShow = false;
                this.editSaveShow = true;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function(){
                        vm.showTip = true;
                    });
                });
            }
        }
    })
    vm.getData();
    var $box = $('#edit_box'),
        $mask = $('#mask');
});
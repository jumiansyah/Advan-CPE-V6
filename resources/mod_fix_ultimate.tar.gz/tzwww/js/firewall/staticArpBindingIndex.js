$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "STATIC_ARP_BINDING";
    var items = [];
    
    items.push({ title: MENU.sys.staticArp, url: 'html/firewall/staticArpBinding.html' });
    
    secondMenuClick(items,id);
});

$(document).ready(function () {
    Page.render();
    var vm = new Vue({
        el: "#default_box",
        data: {
            ipv4FilterRule: DOC.lbl.ipv4FilterRule,
            accept: DOC.lbl.accept,
            reject: DOC.lbl.reject,
            ipv6FilterRule: DOC.lbl.ipv6FilterRule,
            save: DOC.btn.save,
            acceptAllIPv4: "false",
            disabled: false,
            value: []
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_DEFAULT_FILTER,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if(!!data.datas){
                            vm.acceptAllIPv4 = data.datas[0].acceptAll ? "1" : "0";
                        } else {
                            vm.acceptAllIPv4 = "1";
                        }
                        vm.currentFlag = vm.acceptAllIPv4;
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
            },
            btnSave: function () {
                if(vm.currentFlag === vm.acceptAllIPv4){
                    AlertUtil.alertMsg(CHECK.format.defaultDate);
                    return ;
                }
                this.disabled = true;
                fyAlertMsgLoading();
                var acceptAllIPv4 = this.acceptAllIPv4 == "1" ? true : false;
                var datas=[{"enableRule":true,"acceptAll":acceptAllIPv4,"ippro":"IPV4"},{"enableRule":true,"acceptAll":acceptAllIPv4,"ippro":"IPV6"}];
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_DEFAULT_FILTER,
                        method: JSONMethod.POST,
                        success:true,
                        datas: datas
                    },
                    success: function (data) {
                        vm.disabled = false;
                        vm.currentFlag = vm.acceptAllIPv4;
                        if (data.success == true) {
                            if(vm.value.length > 0){
                                vm.applyRulesClick();
                            } else {
                                Page.applyFilter();
                            }
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            applyRulesClick: function () {
                for(var i=0;i<this.value.length;i++){
                    this.value[i].enableLink = this.acceptAllIPv4 == "1" ? false : true;
                }
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.URL_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        }
    })
    vm.getData();
});
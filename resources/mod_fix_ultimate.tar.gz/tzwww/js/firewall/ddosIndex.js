$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "DDOS_PROTECTION";

    items.push({ title: MENU.fw.ddosProtection, url: 'html/firewall/ddos.html' });

    secondMenuClick(items,id);
});
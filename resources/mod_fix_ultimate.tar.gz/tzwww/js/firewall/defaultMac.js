$(document).ready(function () {
    Page.render();
    var vm = new Vue({
        el: "#default_box",
        data: {
            ipv4FilterRule: DOC.lbl.ipv4FilterRule,
            accept: DOC.lbl.accept,
            reject: DOC.lbl.reject,
            ipv6FilterRule: DOC.lbl.ipv6FilterRule,
            save: DOC.btn.save,
            acceptAllIPv4: "false",
            disabled: false,
            acceptAllIPv6: "false"
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_DEFAULT_FILTER,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.acceptAllIPv4 = data.datas[0].acceptAll == "true" ? "true" : "false";
                        vm.acceptAllIPv6 = data.datas[1].acceptAll == "true" ? "true" : "false";
                    }
                });
            },
            btnSave: function () {
                this.disabled = true;
                var datas = [{
                    "enableRule": true,
                    "acceptAll": this.acceptAllIPv4,
                    "ippro": "IPV4"
                }, {
                    "enableRule": true,
                    "acceptAll": this.acceptAllIPv6,
                    "ippro": "IPV6"
                }]
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_DEFAULT_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: datas
                    },
                    success: function (data) {
                        vm.disabled = false;
                        AlertUtil.alertMsg(PROMPT.saving.success);
                    }
                });
            }
        }
    })
    vm.getData();
});
$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "FW_DMZ";
    var items = [];

    items.push({ title: "DMZ", url: 'html/firewall/dmz.html' });
    
    secondMenuClick(items,id);
});


$(document).ready(function () {
    var id = "FW_URL_FILTER";
    var items = [];
    items.push({ title: TAB.fw.defaultSetting, url: 'html/firewall/default2.html' });
    items.push({ title: MENU.fw.urlFilter, url: 'html/firewall/urlFilter.html' });

    secondMenuClick(items,id);
});

$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "FW_MAC_FILTER";
    var items = [];

    items.push({ title: TAB.fw.macFiltering, url: "html/firewall/macFilter.html" });
    items.push({ title: TAB.fw.defaultSetting, url: 'html/firewall/defaultMac.html' });
    
    secondMenuClick(items,id);
});

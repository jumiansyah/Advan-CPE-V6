$(document).ready(function () {
    var $mask = $('#mask');
    var titleArr = [DOC.table.enableRule, DOC.table.priority, DOC.net.protocol, DOC.net.ipv46, DOC.net.sourceAddr, DOC.net.targeAddr,
        DOC.lbl.remark, DOC.table.filterMode, DOC.table.editRule, DOC.table.delRule
    ];
    var vm = new Vue({
        el: "#child_container",
        data: {
            title: titleArr,
            value: [],
            addAclFiltering: DOC.title.addAclFiltering,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            clearAllRules: DOC.btn.clearAllRules,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            filterMode: DOC.table.filterMode,
            accept: DOC.status.accept,
            reject: DOC.status.reject,
            protocol: DOC.net.protocol,
            all: DOC.lbl.all,
            tcp: DOC.net.tcp,
            udp: DOC.net.udp,
            sourceAddr: DOC.net.sourceAddr,
            targeAddr: DOC.net.targeAddr,
            remark: DOC.lbl.remark,
            confirm: DOC.lbl.confirm,
            close: DOC.btn.close,
            ippro: 'IPV4',
            action: "1",
            protocolRe: 'all',
            src_ipaddr: '',
            dest_ipaddr: '',
            comment: '',
            rowFlag: "",
            edit_box: false,
            isApply: false,
            ipproValue: "",
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.FIRWALL_ACL_FILTER,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
            },
            changeAccept: function (event) {
                return event == true ? DOC.status.accept : DOC.status.reject;
            },
            changeAcceptClass: function (event) {
                return event == true ? "ok" : "red";
            },
            editAcl: function (index) {
                this.edit_box = true;
                $mask.show();
                this.action = this.value[index].enableLink == true ? "1" : "0";
                this.protocolRe = this.value[index].protocol;
                this.src_ipaddr = this.value[index].srcIp;
                this.dest_ipaddr = this.value[index].destIp;
                this.comment = this.value[index].remark;
                this.ipproValue = this.value[index].ippro;
                this.rowFlag = index;
            },
            delAcl: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                })
            },
            btnCloseRule: function () {
                this.edit_box = false;
                this.rowFlag = '';
                $mask.hide();
            },
            addRuleClick: function () {
                this.edit_box = true;
                $mask.show();
                this.action = "1";
                this.protocolRe = 'ALL';
                this.src_ipaddr = '';
                this.dest_ipaddr = '';
                this.comment = '';
                this.ipproValue = "IPV4";
            },
            btnSave: function () {
                if (this.src_ipaddr == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (this.dest_ipaddr == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.src_ipaddr, this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.dest_ipaddr, this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }

                var temp = {};
                temp.protocol = this.protocolRe;
                temp.ippro = this.ipproValue;
                temp.srcIp = this.src_ipaddr;
                temp.destIp = this.dest_ipaddr;
                temp.remark = this.comment;
                temp.enableLink = this.action == "1" ? true : false;

                for (var i = 0; i < this.value.length; i++) {
                    var flag = 0;
                    if (this.value[i].protocol == temp.protocol) {
                        flag += 1;
                    }
                    if (this.value[i].ippro == temp.ippro) {
                        flag += 1;
                    }
                    if (this.value[i].srcIp == temp.srcIp) {
                        flag += 1;
                    }
                    if (this.value[i].destIp == temp.destIp) {
                        flag += 1;
                    }
                    if (flag == 4) {
                        if(this.rowFlag === i && (this.value[i].remark != temp.remark || this.value[i].enableLink != temp.enableLink)){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if (typeof this.rowFlag === "number") {
                    temp.enableRule = this.value[this.rowFlag].enableRule;
                    this.value[this.rowFlag] = temp;
                } else {
                    temp.enableRule = true;
                    this.value.push(temp);
                }
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
                this.btnCloseRule();
            },
            applyRulesClick: function () {
                this.isApply = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.FIRWALL_ACL_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isApply = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.FIRWALL_ACL_FILTER,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                            vm.isApply = false;
                        }
                    });
                })
            }
        }
    });
    vm.getData();
});
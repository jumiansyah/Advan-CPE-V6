$(document).ready(function () {
    var $mask = $('#mask');
    var vm = new Vue({
        el: "#child_container",
        data: {
            disabled: false,
            lockPlmnName: DOC.lbl.lockPlmn,
            colon: DOC.colon,
            setVal: DOC.btn.set,
            islockPlmn: DOC.lbl.islockPlmn,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            lockPlmn: false,
            editBox: false,
            edit: networkconfightml.form1.edit,
            del: networkconfightml.form1.del,
            exam: DOC.lbl.example,
            save: DOC.btn.save,
            confirm: DOC.lbl.confirm,
            close: DOC.btn.close,
            plmnItem: '',
            flag: '',
            lockPlmnList: [],
            add: DOC.table.addPlmn
        },
        methods: {
            btnSave: function () {
                var json = {};
                if (this.lockPlmn) {
                    if (this.lockPlmnList.length == 0) {
                        AlertUtil.alertMsg(CHECK.required.plmnRequired);
                        return false;
                    }
                    if (this.lockPlmnList.length > 64) {
                        AlertUtil.alertMsg(CHECK.required.plmnMax);
                        return false;
                    }
                    json.lockPlmn = this.lockPlmn ? "1" : "0";
                    json.lockPlmnList = this.lockPlmnList.join(",");
                } else {
                    json.lockPlmn = this.lockPlmn ? "1" : "0";
                }
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.LOCK_PLMN;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LOCK_PLMN,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.lockPlmn = datas.lockPlmn == "1" ? true : false;
                        vm.lockPlmnList = datas.lockPlmnList ? datas.lockPlmnList.split(",") : [];
                    }
                });
            },
            addPlmn: function () {
                $mask.show();
                this.editBox = true;
                this.plmnItem = '';
            },
            btnClose: function () {
                $mask.hide();
                this.editBox = false;
                this.flag = '';
            },
            isAddSave: function () {
                if (!CheckUtil.checkPlmn(this.plmnItem.trim())) {
                    AlertUtil.alertMsg(CHECK.required.plmnError);
                    return false;
                }
                for(var i=0;i<this.lockPlmnList.length;i++){
                    if(this.plmnItem == this.lockPlmnList[i]){
                        AlertUtil.alertMsg(CHECK.required.samePlmn);
                        return false;
                    }
                }
                if (this.flag !== "") {
                    this.lockPlmnList[this.flag] = this.plmnItem.trim()
                } else {
                    this.lockPlmnList.push(this.plmnItem.trim());
                }
                this.btnClose();
            },
            clickEdit: function (index) {
                this.flag = index;
                this.plmnItem = this.lockPlmnList[index];
                this.editBox = true;
                $mask.show();
            },
            clickDel: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.lockPlmnList.splice(index, 1);
                });
            },
        }
    })
    vm.getData();
});

$(document).ready(function () {
    var $mask = $('#mask');
    var vm = new Vue({
        el: "#apnSetting_template",
        data: {
            colon: DOC.colon,
            help: [  //网页右侧帮助信息
                {
                    title: TAB.advance.qosupload,
                    name: TAB.advance.rulesInfo1
                },
                {
                    title: TAB.advance.qosdownload,
                    name: TAB.advance.rulesInfo2
                },
                {
                    title: TAB.advance.qosMaxupload,
                    name: TAB.advance.rulesInfo3
                },
                {
                    title: TAB.advance.qosMaxdownload,
                    name: TAB.advance.rulesInfo4
                }
            ],
            rule: { //单条数据记录增、改
                ip: '',
                port: '',
                upBandwidth: '',
                downBandwidth: '',
                maxUpBandwidth: '',
                maxDownBandwidth: ''
            },
            datas: [], //规则列表数据
            editBox: false, //编辑框显示隐藏切换
            flag: '',
            ipType: false,
            portType: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.QoS_CONFIG,
                        subcmd: 1
                    },
                    success: function (data) {
                        vm.datas = data.datas;
                    }
                });
            },
            btnSaveList: function () {
                var json = {};
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.QoS_CONFIG;
                json.subcmd = 1;
                json.datas = this.datas;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            addRule: function () {   //新增规则
                $mask.show();
                this.editBox = true;
            },
            clickEdit: function (index) { //编辑规则
                this.flag = index;
                this.rule = $.extend(true, {}, this.datas[this.flag]);
                if(this.rule.ip == "All") {
                    this.ipType = true;
                } else {
                    this.ipType = false;
                }
                if(this.rule.port == "All") {
                    this.portType = true;
                } else {
                    this.portType = false;
                }
                this.editBox = true;
                $mask.show();
            },
            clickDel: function (index) {  //删除单挑规则
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.datas.splice(index, 1);
                });
            },
            btnClose: function () { //关闭弹出窗
                $mask.hide();
                this.editBox = false;
                this.flag = '';
                this.rule.ip = '';
                this.rule.port = '';
                this.rule.upBandwidth = '';
                this.rule.downBandwidth = '';
                this.rule.maxUpBandwidth = '';
                this.rule.maxDownBandwidth = '';
                this.ipType = false;
                this.portType = false;
            },
            isAddSave: function () {  //将新增或编辑的规则插入表格 注意此时数据仅插入,并未保存
                if (!CheckUtil.checkIp(this.rule.ip) && this.rule.ip != 'All') {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (!CheckUtil.checkPort(this.rule.port).isValid && this.rule.port != 'All') {
                    AlertUtil.alertMsg(CHECK.format.port);
                    return false;
                }
                if(this.rule.ip == 'All' && this.rule.port == 'All'){
                    AlertUtil.alertMsg(CHECK.format.qosIpPort);
                    return false;
                }
                if (this.rule.upBandwidth == '' || this.rule.upBandwidth < 0) {
                    console.log(this.rule.qosupload)
                    AlertUtil.alertMsg(CHECK.format.qosUploadLimit);
                    return false;
                }
                if (this.rule.downBandwidth == '' || this.rule.downBandwidth < 0) {
                    AlertUtil.alertMsg(CHECK.format.qosDownloadLimit);
                    return false;
                }
                if (this.rule.maxUpBandwidth == '' || this.rule.maxUpBandwidth < 0) {
                    AlertUtil.alertMsg(CHECK.format.qosUploadLimit);
                    return false;
                }
                if (this.rule.maxDownBandwidth == '' || this.rule.maxDownBandwidth < 0) {
                    AlertUtil.alertMsg(CHECK.format.qosDownloadLimit);
                    return false;
                }
                if (this.flag !== '') {
                    this.datas[this.flag] = $.extend(true, {}, this.rule);
                } else {
                    this.datas.push($.extend(true, {}, this.rule));
                }
                this.btnClose();
            }
        },
        mounted: function () {
            this.getData()
        }
    });
});
$(document).ready(function () {
    var vm = new Vue({
        el: '#child_container',
        data: {
            disabled: false,
            networkMode: '',
            colon: DOC.colon
        },
        methods: {
            btnSave: function () {
                this.disabled = true;
                fyAlertMsgLoading();
                var json = {};
                json.networkMode = vm.networkMode;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORKMODE_SWITCH;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.disabled = false;
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORKMODE_SWITCH,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.networkMode = data.networkMode || 'mobile';
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    });
});
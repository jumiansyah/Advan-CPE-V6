$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm2(fm);
    var rules = {
            dnn: {
                apnUser: true
            },
            appid: {
                APPID: true
            },
            fqdn: {
                apnUser: true
            },
            ip: {
                apnUser: true,
                required: true
            },
            port: {
                digits: true, 
                range: [0, 65535],
                required: true
            },
            proid: {
                digits: true, 
                range: [0, 255],
                required: true
            }
        },
        messages = {
            dnn: {
                apnUser: CHECK.format.dnnname
            },
            appid: {
                APPID: CHECK.format.dnnname
            },
            fqdn: {
                apnUser: CHECK.format.dnnname
            },
            ip: {
                apnUser: CHECK.format.dnnname,
                required:CHECK.required.noEmpty
            },
            port: {
                digits: CHECK.format.digits,
                range: CHECK.range.port,
                required:CHECK.required.noEmpty
            },
            proid: {
                digits: CHECK.format.digits,
                range: CHECK.range.proID,
                required:CHECK.required.noEmpty
            }
        };
    var vm = new Vue({
        el: "#child_container",
        data: {
            switch2: DOC.lbl.switch,
            dnn: DOC.lbl.dnn,
            colon: DOC.colon,
            disabled: false,
            btn_save: DOC.btn.save,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            sliceEnabled: false,
            ipAdd: DOC.net.ip,
            portTile: dialconfightml.form1.portTh,
            protocolId: DOC.lbl.protocolId,
            dnnValue: "",
            appidValue: "",
            fqdnValue: "",
            ip: "",
            port: "",
            proid: ""
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SLICE_CONIFIG
                    },
                    success: function (data) {
                        vm.sliceEnabled = data.slice_sw == "1" ? true : false;
                        vm.dnnValue = data.slice_dnn || "";
                        vm.appidValue = data.slice_appid || "";
                        vm.fqdnValue = data.slice_fqdn || "";
                        vm.port = data.port || "";
                        vm.proid = data.proid || "";
                        vm.ip = data.ip || "";
                    }
                })
            },
            clickBtnSave: function () {
                var $form = $('#childForm');
                if (!this.dnnValue && !this.appidValue && !this.fqdnValue) {
                    AlertUtil.alertMsg(CHECK.required.oneMoreSlice);
                    return false;
                }
                if (!this.ip && !this.port && !this.proid) {
                    $('input[name="ip').addClass("ignore");
                    $('input[name="port').addClass("ignore");
                    $('input[name="proid').addClass("ignore");
                } else {
                    $('input[name="ip"]').removeClass("ignore");
                    $('input[name="port"]').removeClass("ignore");
                    $('input[name="proid"]').removeClass("ignore");
                }
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    return false;
                }
                this.disabled = true;
                fyAlertMsgLoading();
                var json = {};
                // json.apn = vm.apn;
                json.slice_sw = this.sliceEnabled ? "1" : "0";
                if(this.sliceEnabled == "1"){
                    json.slice_dnn = this.dnnValue;
                    json.slice_appid = this.appidValue;
                    json.slice_fqdn = this.fqdnValue;
                    json.ip = this.ip;
                    json.port = this.port;
                    json.proid = this.proid;
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.SLICE_CONIFIG;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            }
        },
        mounted: function () {
            this.getData()
        }

    });
});
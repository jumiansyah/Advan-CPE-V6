$(document).ready(function () {

    var id = "ROUTER_TABLE";
    var items = [];

    items.push({ title: TAB.route.routingTable, url: 'html/advance/route.html' });
    if(Page.pageHideCheck(30))
     	items.push({ title: TAB.route.arpTime, url: 'html/advance/arp.html' });

    secondMenuClick(items,id);
});


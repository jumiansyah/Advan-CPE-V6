$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    var rules = {
        upBandwidth: {
            required: true,
            digits: true
        },
        downBandwidth: {
            required: true,
            digits: true
        }
    },
    messages = {
        upBandwidth: {
            required: wirelessconfightml.prompt.noEmpty,
            digits: CHECK.format.digits
        },
        downBandwidth: {
            required: wirelessconfightml.prompt.noEmpty,
            digits: CHECK.format.digits
        }
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            qosSw: false,
            colon: DOC.colon,
            upBandwidth: "",
            downBandwidth: "",
            help:[TAB.advance.qosInfo1,TAB.advance.qosInfo2]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.QoS_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.qosSw = data.qosSw == "1" ? true : false;
                        vm.upBandwidth = data.upBandwidth;
                        vm.downBandwidth = data.downBandwidth;
                    }
                });
            },
            btnSave: function () {
                var json = {};
                json.cmd = RequestCmd.QoS_CONFIG;
                json.subcmd = 0;
                json.method = JSONMethod.POST;
                if(this.qosSw){
                    if (!CheckUtil.checkForm($('#childForm'), rules, messages)) {
                        return false;
                    }
                    json.qosSw = "1";
                    json.upBandwidth = this.upBandwidth;
                    json.downBandwidth = this.downBandwidth;
                } else {
                    json.qosSw = "0";
                }
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
        }
    })

});
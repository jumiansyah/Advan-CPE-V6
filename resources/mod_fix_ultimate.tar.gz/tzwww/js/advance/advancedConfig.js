$(document).ready(function () {
    var tabs = TAB.advance;
    var id = "ADVANCED_CONFIG";
    var items = [];
    // DDNS and Remote Login are intentionally hidden.
    // if(Page.pageHideCheck(35))
    //     items.push({ title: DOC.lbl.islockPlmn, url: 'html/advance/lockPlmn.html' });
    if(Page.pageHideCheck(36))
        items.push({ title: tabs.lockFreq, url: "html/advance/lockBand.html" });
    if(Page.pageHideCheck(37))
        items.push({ title: tabs.lockPhyCell, url: 'html/advance/lockPhyCell.html' });
    if(Page.level == "1"){
        items.push({ title: TAB.basic.remotePin, url: 'html/advance/remotePin.html' });
    }
    
    secondMenuClick(items,id);
});

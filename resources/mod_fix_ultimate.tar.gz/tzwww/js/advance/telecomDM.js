$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm2(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            disabled: false,
            btn_save: DOC.btn.save,
            receiveAdd: '',
            simCenterAdd: ''
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.TELECOM_DM,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.receiveAdd = data.receiveAdd;
                        vm.simCenterAdd = data.simCenterAdd;
                    }
                })
            },
            clickBtnSave: function () {
                this.disabled = true;
                fyAlertMsgLoading();
                var json = {};
                json.receiveAdd = this.receiveAdd;
                json.simCenterAdd = this.simCenterAdd;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.TELECOM_DM;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            }
        },
        mounted: function () {
            this.getData()
        }
    });
});
$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            value:"",
            flag:"",
            save: DOC.btn.save,
            disabled:false,
            colon: DOC.colon,
            simChange:DOC.lbl.simChange,
            content:[
                {name:TAB.basic.showSim ,value:"0"},
                {name:TAB.basic.showEsim,value:"1"}
            ]
        },
        methods: {
            getData:function(){
                 Page.postJSON({
                    json: {
                        cmd: RequestCmd.CHANGE_CARD_TYPE,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.value = datas.current_card_type || "0";
                        vm.flag = datas.current_card_type;
                    }
                });
            },
            btnSave: function () {
                if(this.flag === this.value){
                    AlertUtil.alertMsg(DOC.lbl.notChange);
                    return false;
                }
                vm.disabled = true;
                var json={};
                json.cmd = RequestCmd.CHANGE_CARD_TYPE;
                json.method = JSONMethod.POST;
                json.current_card_type = this.value;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.flag == "1"){
                            fyAlertMsgSuccess();
                            vm.flag = json.current_card_type;
                            if(json.current_card_type == "0"){
                                $('#ESIM_MANAGE').removeClass().addClass("not_click");
                            } else {
                                $('#ESIM_MANAGE').removeClass();
                            }
                        }else{
                            fyAlertMsgFail();
                        } 
                    },
                    complete:function(){
                        vm.disabled = false;
                    }
                });
            }
        },
        mounted:function(){
            this.getData();
        }
    })
});
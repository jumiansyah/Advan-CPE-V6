$(document).ready(function () {

    var id = "ONENET_SETTING";
    var items = [];

    if (Page.pageHideCheck(32)) {
        items.push({ title: "OneNET", url: 'html/advance/onenet.html' });
    }
    if (Page.pageHideCheck(53)) {
        items.push({ title: DOC.tr069.mobileDM, url: 'html/advance/dmPlatform.html' });
    }
    if (Page.pageHideCheck(54)) {
        items.push({ title: DOC.tr069.teleDM, url: 'html/advance/telecomDM.html' });
    }
    secondMenuClick(items,id);
});
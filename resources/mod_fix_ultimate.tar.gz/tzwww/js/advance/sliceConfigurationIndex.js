$(document).ready(function () {

    var id = "SLICE_CONIFIG";
    var items = [];

    items.push({ title: TAB.basic.sliceConfiguration, url: 'html/advance/sliceConfiguration.html' });

    secondMenuClick(items,id);
});
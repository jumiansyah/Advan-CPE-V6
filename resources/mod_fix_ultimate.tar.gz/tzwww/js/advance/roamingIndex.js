$(document).ready(function () {
    var id = "ROAMING_CONFIG";
    var items = [];

    items.push({ title: TAB.basic.pinSet, url: 'html/advance/roaming.html' });
    secondMenuClick(items,id);
});


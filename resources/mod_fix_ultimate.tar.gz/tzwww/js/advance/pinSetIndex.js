/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-05-19 11:59:35
 * @,@LastEditTime: ,: 2021-05-19 16:56:42
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\advance\pinSetIndex.js
 */
$(document).ready(function () {
    var id = "PIN_CONFIG";
    var items = [];

    items.push({ title: DOC.lbl.pinCode, url: 'html/advance/pinSet.html' });
    // if(Page.esim_show == "1" || Page.pageHideCheck(17))
    //     items.push({ title: DOC.lbl.simChange, url: 'html/advance/simChange.html' });
    secondMenuClick(items,id);
});


$(document).ready(function () {
    var id = "AUTODIAL_CONFIG";
    var items = [];

    items.push({ title: DOC.lbl.autoDial, url: 'html/advance/autoDial.html' });
    secondMenuClick(items,id);
});


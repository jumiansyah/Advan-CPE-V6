$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var $mask = $('#mask');
    var showText = wirelessconfightml.prompt;
    var vm = new Vue({
        el: "#reContent",
        data: {
            remoteLogin: DOC.lbl.remoteLogin,
            colon: DOC.colon,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            remotePort: DOC.lbl.remotePort,
            remoteIpList: DOC.lbl.remoteIpList,
            remoteIp_list: false,
            addRemoteIp: DOC.lbl.addRemoteIp,
            dafulteIpList: DOC.lbl.dafulteIpList,
            dafulteIp_list: false,
            addRemoteDafultIp: DOC.lbl.addRemoteDafultIp,
            rules: {
                remoteLoginPort: {
                    required: true,
                    range: [0, 65535]
                }
            },
            messages: {
                remoteLoginPort: {
                    required: CHECK.required.remotePort,
                    range: CHECK.range.port
                }
            },
            save: DOC.btn.save,
            close: DOC.btn.close,
            remoteIp: DOC.lbl.remoteIp,
            example: DOC.lbl.example,
            enableRemoteLogin: false,
            edit: showText.edit,
            del: showText.del,
            remoteLoginPort: '',
            editBox: false,
            btnDis: false,
            btnSaveDis: false,
            btnEditDis: false,
            ipListsDafult: [],
            ipLists: [],
            ipList: '',
            rowFlag: 0,
            typeFlag: '1',
            edit_title: ''
        },
        methods: {
            getData: function () {
                // if (Page.getShowHideByBit(17)) {
                //     this.remoteIp_list = true;
                // } else {
                //     this.remoteIp_list = false;
                // };
                // if (Page.getShowHideByBit(103)) {
                //     this.dafulteIp_list = true;
                // } else {
                //     this.dafulteIp_list = false;
                // }
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WEB_LIST
                    },
                    success: function (datas) {
                        vm.remoteLoginPort = datas.port;
                        vm.enableRemoteLogin = datas.enableRule == '1' ? true :false;
                        if (datas.datas) {
                            vm.ipLists = datas.datas;
                        }
                    }
                   
                });
            },
            btnClose: function () {
                this.editBox = false;
                $mask.hide();
                this.ipList = '';
            },
            ipDel: function (index, type) {
                if (type == '1') {
                    this.ipLists.splice(index, 1);
                } else {
                    this.ipListsDafult.splice(index, 1);
                }

            },
            ipEdit: function (index, type) {
                $mask.show();
                this.editBox = true;
                this.btnSaveDis = false;
                this.btnEditDis = true;
                this.edit_title = DOC.table.edit + DOC.lbl.remoteIp;
                // SysUtil.setBoxStyle1($("#edit_box"));
                this.rowFlag = index;
                this.typeFlag = type;
                if (type == '1') {
                    this.ipList = this.ipLists[index].ip;
                } else {
                    this.ipList = this.ipListsDafult[index];
                }
            },
            btnSave: function () {
                // this.btnDis = true;
                var $form = $('#childForm');
                var json = JSON.parmsToJSON($form);
                if (!CheckUtil.checkForm($form, this.rules, this.messages)) {
                    this.btnDis = false;
                    return;
                }
                var json = {};
                    json.datas = this.ipLists;
                    if (this.ipLists.length > 0) {
                        json.datas = this.ipLists;
                    } else json.datas = [];
                // if (Page.level == "1") {
                //     if (this.ipListsDafult.length > 0) {
                //         json.dataList2 = this.ipListsDafult;
                //     } else json.dataList2 = [""];

                // };
                json.port = this.remoteLoginPort;
                json.enableRule = this.enableRemoteLogin?"1":"0";
                json.success=true;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WEB_LIST;
                fyConfirmMsg(PROMPT.tips.remoteTips , function () {
                  
                    fyAlertMsgLoading(PROMPT.status.rebooting + "," + CHECK.format.waiting);
    
                    setTimeout(function(){
                        Page.postJSON({
                            json: json,
                            success: function (data) {
                                AlertUtil.alertMsg(PROMPT.saving.success);
                            },
                            complete: function () {
                                vm.btnDis = false;
                            }
                        });
                    }, 3000);
                    setTimeout(function () {
                        location.reload();
                    }, 120000);
                  
                })
                
            },
            btnAdd: function () {
                $mask.show();
                this.editBox = true;
                this.btnSaveDis = true;
                this.btnEditDis = false;
                this.edit_title = DOC.table.add + DOC.lbl.remoteIp;
                this.ipList = '';
                this.typeFlag = '1';
            },
            btnAdd2: function () {
                $mask.show();
                this.editBox = true;
                this.btnSaveDis = true;
                this.btnEditDis = false;
                this.edit_title = DOC.table.add + DOC.lbl.remoteIp;
                this.ipList = '';
                this.typeFlag = '2';
            },
            btnSaveIp: function () {
                if (this.ipList == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.ipList)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.typeFlag == "1") {
                    this.ipLists.push({ip:this.ipList});
                } else {
                    this.ipListsDafult.push({ip:this.ipList});
                }
                this.btnClose();
            },
            btnEditIp: function () {
                if (this.ipList == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.ipList)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.typeFlag == "1") {
                    this.$set(this.ipLists, this.rowFlag, {ip:this.ipList});
                } else {
                    this.$set(this.ipListsDafult, this.rowFlag,{ip:this.ipList});
                }
                this.btnClose();
            }
        },
        mounted: function(){
            Page.createForm2(fm);
        }
    });
    vm.getData();
});
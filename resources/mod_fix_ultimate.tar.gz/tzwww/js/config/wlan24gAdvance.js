var fm = ["childForm", "wlform1_template", "childFormId"];
var form1 = wirelessconfightml.form1;
var rules = {
    maxNum: {
        required: true,
        range: [1, 32],
        digits: true
    },
    connectNum: {
        required: true,
        integer: true,
        range: [-99, 0]
    },
    eliminateNum: {
        required: true,
        integer: true,
        range: [-99, 0]
    }
};
var messages = {
    maxNum: {
        required: wirelessconfightml.prompt.maxStationCheckMsg1,
        range: wirelessconfightml.prompt.maxStationCheckMsg3,
        digits: CHECK.format.digits
    },
    connectNum: {
        required:wirelessconfightml.prompt.noEmpty,
        integer: wirelessconfightml.prompt.limitError,
        range: wirelessconfightml.prompt.limitError
    },
    eliminateNum: {
        required:wirelessconfightml.prompt.noEmpty,
        integer: wirelessconfightml.prompt.limitError,
        range: wirelessconfightml.prompt.limitError
    }
};
var vm = new Vue({
    el: "#wlform1_template",
    data: {
        wifiFunction: form1.wifiSwitch,
        enable: DOC.status.enable,
        disable: DOC.status.disable,
        wifitxPower: form1.txPower,
        wifichannel: form1.channel,
        wifiMode: form1.wifiMode,
        wifibandwidth: wlan5ghtml.form1.bandWidth,
        wifiNum: wirelessconfightml.helper.title8_2 + ":",
        btnSave: form1.btnSave,
        connect: wirelessconfightml.helper.title12 + ":",
        eliminate: wirelessconfightml.helper.title11 + ":",
        passType: "password",
        countryCode: "",
        countryCodeList: WlanPara.countryCode,
        txOption: [{
                name: "100%",
                value: '100'
            },
            {
                name: "70%",
                value: '70'
            },
            {
                name: "50%",
                value: '50'
            },
            {
                name: "35%",
                value: '35'
            },
            {
                name: "15%",
                value: '15'
            }
        ],
        channelOption: [],
        wifiWorkMode: WlanPara.wlan_2g.wifiWorkMode,
        channel_option: "auto",
        wifi_workMode: "auto",
        band_width: "1",
        tx_power: "",
        wifiOpen: true,
        maxNum: "",
        connectNum: "",
        eliminateNum: "",
        butAble: false,
        helps: [{
                title: wlan5ghtml.helper.title8,
                item: wlan5ghtml.helper.item8
            },
            {
                title: wlan5ghtml.helper.title4,
                item: wlan5ghtml.helper.item4
            },
            {
                title: wlan5ghtml.helper.title5,
                item: wlan5ghtml.helper.item5
            },
            {
                title: wlan5ghtml.helper.title12,
                item: wlan5ghtml.helper.item12
            }
        ]
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.WIRELESS_ADVANCE,
                    methods: JSONMethod.GET
                },
                success: function (data) {
                    vm.wifiOpen = data.wifiOpen == "1" ? true : false;
                    vm.countryCode = data.countryCode;
                    vm.channelChange();
                    vm.tx_power = data.txPower;
                    vm.channel_option = data.channel == "0" ? "auto" : data.channel;;
                    vm.wifi_workMode = data.wifiWorkMode;
                    vm.band_width = data.bandWidth;
                    vm.maxNum = data.maxNum;
                    vm.eliminateNum = data.eliminateNum || 0;
                    vm.connectNum = data.connectNum || 0;
                }
            })
        },
        clickBtnSave: function () {
            var $form = $("#childForm");
            if (!CheckUtil.checkForm($form, rules, messages)) {
                this.butAble = false;
                return;
            }
            if(Number(vm.connectNum)<Number(vm.eliminateNum)){
                AlertUtil.alertMsg(CHECK.format.threshold);
                return false;
            }
            this.butAble = true;
            fyAlertMsgLoading();
            var json = {};
            json.wifiOpen = vm.wifiOpen ? "1" : "0";
            json.txPower = vm.tx_power;
            json.channel = (vm.channel_option == "auto" || vm.channel_option == "Auto") ? "0" :vm.channel_option;
            json.countryCode = vm.countryCode;
            json.wifiWorkMode = vm.wifi_workMode;
            json.bandWidth = vm.band_width;
            json.maxNum = vm.maxNum;
            json.eliminateNum = vm.eliminateNum;
            json.connectNum = vm.connectNum;
            json.method = JSONMethod.POST;
            json.cmd = RequestCmd.WIRELESS_ADVANCE;
            Page.postJSON({
                json: json,
                success: function (data) {
                    vm.butAble = false;
                    if (data.success == true) {
                        setTimeout(function () {
                            fyAlertMsgSuccess();
                        }, 6000);
                    } else {
                        setTimeout(function () {
                            fyAlertMsgFail();
                        }, 6000);
                    }
                }
            })
        },
        channelChange: function(){
            this.channelOption = [];
            if(!!this.countryCode){
                for(var i=0;i<this.countryCodeList.length;i++){
                    if(this.countryCodeList[i].value == this.countryCode){
                        this.channelOption = WlanPara[this.countryCodeList[i].channel_2g];
                    }
                }
            }
            if(this.channelOption.length == 0 ){
                this.channelOption = WlanPara.channel_2g_default;
            }
            if(!!this.channel_option){
                this.channel_option = this.channelOption[0].value;
            }
        }
    },
    computed:{
      bandWidthOption:function(){
          if(this.wifi_workMode == "0" || this.wifi_workMode == "1" || this.wifi_workMode == "3"){
            if (this.band_width === '2' || this.band_width === '1') {
                this.band_width = "0";
            }
            return [{ "name": "20MHz", "value": "0" }]
          }else{
            return WlanPara.wlan_2g.bandWidth
          }
      }
    },
    mounted: function () {
        Page.createForm(fm);
        this.getData();
    }
});
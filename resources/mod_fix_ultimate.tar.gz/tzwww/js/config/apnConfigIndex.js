$(document).ready(function () {

    var tabs = DOC.apn;
    var id = "APN_CONFIG";
    var items = [];

    items.push({ title: tabs.setting_apn, url: 'html/config/setting_apn.html' });
	if(Page.pageHideCheck(15))
		items.push({ title: tabs.setting_apn1, url: 'html/config/setting_apn1.html' });
    if(Page.pageHideCheck(16))
        items.push({ title: tabs.setting_apn2, url: 'html/config/setting_apn2.html' });
    
    secondMenuClick(items,id);
});


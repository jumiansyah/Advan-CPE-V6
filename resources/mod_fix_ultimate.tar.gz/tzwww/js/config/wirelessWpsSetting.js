$(document).ready(function () {
    var fm = ["childForm", "wpsSet", "childFormId"];
    var vm = new Vue({
        el: "#wpsSet",
        data: {
            wps: DOC.lbl.wpsEnable,
            colon: DOC.colon,
            wifiMode: DOC.lbl.bindwifiMode,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            btn_save: DOC.btn.save,
            btn_apply: DOC.btn.apply,
            lbl_wpsPin: DOC.lbl.wpsPin,
            lbl_wpsRandomPin: DOC.lbl.wpsRandomPin,
            lbl_wpsCreatePin: DOC.lbl.wpsCreatePin,
            btn_close: DOC.btn.close,
            net_mobilePhone: DOC.net.mobilePhone,
            net_wpsSetup: DOC.net.wpsSetup,
            unit_second: DOC.unit.second,
            wpsPinInputPROMPT: PROMPT.input.wpsPin,
            lbl_wps_pcb: DOC.lbl.wpsPBC,
            wpsEnable: false,
            btnAbl: false,
            btnAbl1: false,
            btnAbl2: false,
            wpsPin: '',
            showWps: false,
            wifiOpen: false,
            close:false,
            wifiSames: false,
            showTip:false,
            butAble: false,
            helps: [{
                title: "WPS",
                item: wlan5ghtml.helper.item14
            }]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WPS_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        if(data.wifiOpen == "1"){
                            vm.wpsEnable = data.wlan2g_wps_switch == "1" ? true : false;
                            vm.showWps = data.wlan2g_wps_switch == "1" ? true : false;
                        } else {
                            vm.btnAbl = true;
                            vm.showWps = false;
                            vm.wifiOpen = true;
                        }
                    }
                })

            },
            getwifiData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        if (data.wifiSames == "1") {
                            vm.showTip = true;
                            vm.wifiSames = true
                        }
                        if(data.broadcast == "0"){
                            vm.close = true
                        }else{
                            vm.close = false
                        }
                    }
                })
            },
            btnClick: function () {
                var json = {};
                json.wlan2g_wps_switch = this.wpsEnable ? "1" : "0";
                fyAlertMsgLoading();
                json.cmd = RequestCmd.WPS_CONFIG;
                json.method = JSONMethod.POST;
                json.subcmd = 0;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            setTimeout(function () {
                                fyAlertMsgSuccess();
                                vm.getData();
                            }, 6000);
                        } else {
                            setTimeout(function () {
                                fyAlertMsgFail();
                            }, 6000);
                        }
                    }
                })
            },
            btnClick2: function () {
                var json = {};
                var $form = $('#childForm');
                // 添加WPS PIN自定义校验
                jQuery.validator.addMethod("checkWpsPin", function (value, element) {
                    return this.optional(element) || (/^[0-9]*[1-9][0-9]*$/.test(value) && value.length == 8);
                }, CHECK.format.wpsPin);
                var wpsPinRules = {
                        wpsPin: {
                            required: true,
                            checkWpsPin: true
                        }
                    },
                    wpsPinMessages = {
                        wpsPin: {
                            required: CHECK.required.wpsPin,
                            checkWpsPin: CHECK.format.wpsPin
                        }
                    };
                if (!CheckUtil.checkForm($form, wpsPinRules, wpsPinMessages)) {
                    return;
                }
                if (!this.pinCheck(this.wpsPin)) {
                    AlertUtil.alertMsg(CHECK.format.wpsPin);
                    return;
                }
                json.wpsPin = this.wpsPin;
                fyAlertMsgLoading();
                json.cmd = RequestCmd.WPS_PIN_CODE;
                json.subcmd = 0;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            },
            pinCheck: function (code) {
                var accum = 0;
                accum += 3 * (parseInt(code / 10000000) % 10);
                accum += 1 * (parseInt(code / 1000000) % 10);
                accum += 3 * (parseInt(code / 100000) % 10);
                accum += 1 * (parseInt(code / 10000) % 10);
                accum += 3 * (parseInt(code / 1000) % 10);
                accum += 1 * (parseInt(code / 100) % 10);
                accum += 3 * (parseInt(code / 10) % 10);
                accum += 1 * (parseInt(code / 1) % 10);
                return (0 == (accum % 10));
            },
            wpsRandomPin: function () {
                this.btnAbl1 = true;
                var json = {};
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.OPEN_RANDOM_PIN;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (!!data.random_ping) {
                            time = 120;
                            fyAlertDestory();
                            $("#pinMobil").text(data.random_ping);
                            $('#mask').show();
                            $("#edit_box").addClass('edit_box1').show();
                            $(".wpsPIN").show();
                            vm.getRandomCode();
                            SysUtil.setBoxStyle1($("#edit_box"));
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.btnAbl1 = false;
                    }
                });
            },
            getRandomCode: function () {
                if (time > 0) {
                    time--;
                    $("#pinTime").text(time);
                } else {
                    this.btnClose();
                    this.btnAbl1 = false;
                    return
                }
                window.setTimeout(function () {
                    vm.getRandomCode();
                }, 1000);
            },
            btnClose: function () {
                time = 0;
                $("#edit_box").removeClass('edit_box1').hide();
                $('#mask').hide();
                this.btnAbl1 = false;
            },
            wpsPCB: function () {
                var json = {};
                json.subcmd = 2;
                fyAlertMsgLoading();
                json.cmd = RequestCmd.WPS_PIN_CODE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
            this.getwifiData();
        }
    });

});

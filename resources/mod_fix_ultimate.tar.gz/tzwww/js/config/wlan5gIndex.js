/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-05-21 15:10:12
 * @,@LastEditTime: ,: 2021-06-07 20:06:23
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\config\wlan5gIndex.js
 */
$(document).ready(function () {
    var tabs = TAB.advance;
    var items = [];
    var id = "WIRELESS5G_CONFIG";
    items.push({ title: wirelessconfightml.tab_menu.item1, url: 'html/config/main5gWifiSetting.html' });
    var wlan5g_switch = sessionStorage.getItem("wlan5g_switch");
    if(wlan5g_switch == "1"){
        if(Page.pageHideCheck(23))
    	items.push({ title: wirelessconfightml.tab_menu.item12, url: 'html/config/setting_5wifi_1.html' });
	if(Page.pageHideCheck(24))
        items.push({ title: wirelessconfightml.tab_menu.item13, url: 'html/config/setting_5wifi_2.html' });
	if(Page.pageHideCheck(25))
        items.push({ title: wirelessconfightml.tab_menu.item14, url: 'html/config/setting_5wifi_3.html' });
	// if(Page.pageHideCheck(26))
        // items.push({ title: wirelessconfightml.tab_menu.item15, url: 'html/config/setting_5wifi_4.html' });
    }
    secondMenuClick(items,id);
    
});
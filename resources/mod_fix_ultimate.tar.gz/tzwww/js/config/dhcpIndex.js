$(document).ready(function () {
    
    var tabs = TAB.advance;
    var items = [];
    var id = "NETWORK_CONFIG";
    items.push({ title: networkconfightml.tab_menu.item1, url: 'html/config/dhcpSetting.html' });
    secondMenuClick(items,id);
});
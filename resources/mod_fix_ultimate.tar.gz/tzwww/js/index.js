/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-28 15:20:11
 * @LastEditTime: 2021-09-27 16:22:19
 * @LastEditors: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\js\index.js
 */
$(document).ready(function () {
    if (!IsPC()) {
        // window.location.href = Page.getUrl("/mobile_web/login.html");
    }
    if (navigator.appName == "Microsoft Internet Explorer" && parseInt(navigator.appVersion.split(";")[
        1].replace(/[ ]/g, "").replace("MSIE", "")) < 10) {
        AlertUtil.alertMsg(DOC.login.Browser);
        return false;
    };
    var web_browser_title = "";
    //禁止右键和键盘复制功能
    document.oncontextmenu = function (event) {
        if (window.event) {
            event = window.event;
        }
        try {
            var the = event.srcElement;
            if (!((the.tagName == "INPUT" && the.type.toLowerCase() == "text") || the.tagName == "TEXTAREA")) {
                return false;
            }
            return true;
        } catch (e) {
            return false;
        }
    }
    document.onkeydown = function () {
        if (window.event.ctrlKey && window.event.keyCode == 85) {
            event.keyCode = 0;
            event.returnValue = false;
            return false;
        }

    }
    function init() {
        document.title = web_browser_title || DOC.head
        $.ajax({
            url: "html/home.html?t=" + Math.random(),
            dataType: "html",
            type: "GET",
            async: false,
            success: function (data) {
                if (sessionStorage['canLogin'] == "AUTH") {
                    $('#container').html(data);
                } else {
                    location.href = Page.getUrl(Url.LOGIN);
                }
            }
        });
    }
    document.onkeydown = function (event) {
        var target, code, tag;
        if (!event) {
            event = window.event; //针对ie浏览器
            target = event.srcElement;
            code = event.keyCode;
            if (code == 13) {
                tag = target.tagName;
                if (tag == "TEXTAREA") {
                    return true;
                } else {
                    return false;
                }
            }
        } else {
            target = event.target; //针对遵循w3c标准的浏览器，如Firefox
            code = event.keyCode;
            if (code == 13) {
                tag = target.tagName;
                if (tag == "INPUT") {
                    return false;
                } else {
                    return true;
                }
            }
        }
    };

    Page.postJSON({
        json: {
            cmd: RequestCmd.INIT_PAGE
        },
        success: function (data) {
            var styleTag = document.createElement("link");
            var styleTag1 = document.createElement("link");
            var styleTag2 = document.createElement("link");
            Page.webPageFlag = Page.parseHexPageHide(data.web_page_hide);
            var themeWeb = "";
            if (!data.user_web_theme) {
                themeWeb = "main.css";
            } else {
                themeWeb = data.user_web_theme;
            }
            Page.themeWeb = themeWeb;
            if (!!data.web_browser_title) {
                web_browser_title = data.web_browser_title;
            }
            styleTag.setAttribute('href', 'css/' + themeWeb + "?t=" + Math.random());

            if (themeWeb == 'main.Indonesia.css') {
                styleTag1.setAttribute('href', 'css/' + 'element.Indonesia.css' + "?t=000000");
                styleTag1.setAttribute('rel', 'stylesheet');
                styleTag1.setAttribute('type', 'text/css');
                styleTag2.setAttribute('href', 'css/' + 'home.Indonesia.css' + "?t=000000");
                styleTag2.setAttribute('rel', 'stylesheet');
                styleTag2.setAttribute('type', 'text/css');
                $("link[href^='css/']").remove();
                $("head")[0].appendChild(styleTag1);
                $("head")[0].appendChild(styleTag2);
            }

            styleTag.setAttribute('type', 'text/css');
            styleTag.setAttribute('rel', 'stylesheet');
            $("head")[0].appendChild(styleTag);
            if (data.web_logo_path == "logo_t3.png") {
                var styleTag = document.createElement("link");
                styleTag.setAttribute('href', 't3_favicon.ico');
                styleTag.setAttribute('type', 'image/x-icon');
                styleTag.setAttribute('rel', 'shortcut icon');
                $("head")[0].appendChild(styleTag);
            }
            Page.current_card_type = data.current_card_type == "1" ? "1" : "0";
            Page.iad_ready_status = data.iad_ready_status == "0" ? "0" : "1";
            Page.esim_show = data.esim_show == "1" ? "1" : "0";
            Page.onenet = data.onenet == "1" ? "1" : "0";
            Page.dm_platform = data.dm_platform == "1" ? "1" : "0";
            Page.level = data.account_level || "3";
            Page.wifiCountrySelect = data.wifiCountrySelect == "0" ? "0" : "1";
            var language = data.language.toUpperCase();
            if (Page.requireChangeLang(language)) {
                Page.language = language;
                $("script[src^='js/language/']").remove();
                $.getScript('js/language/' + language.toLowerCase() + '.js', init);
            } else {
                init();
            }
        }
    });
});

function closeBox() {
    $('#btnClose').click();
}

$(document).ready(function () {
	var fm1 = ["form1", "child_container2", "child_template2"];
	var vm = new Vue({
		el: "#child_container",
		data: {
			localUpdate: DOC.title.localUpdate,
			selectUpdateFile: DOC.sys.selectUpdateFile,
			colon: DOC.colon,
			browse: DOC.btn.browse,
			upload: DOC.btn.upload,
			update: DOC.btn.update,
			remoteUpdate: DOC.title.remoteUpdate,
			fotaUrl: DOC.lbl.fotaUrl,
			theUpdateFileName: "",
			datas: "",
			last_uptime: -1,
			needreboot: 1,
			pppUserName: DOC.apn.pppUserName,
			passwd: DOC.login.passwd,
			Btnset: DOC.btn.confirm,
			disabled: false,
			usernameValue: "",
			passwordValue: "",
			config8198d: DOC.sys.config8198d,
			isShowSuper: false
		},
		methods: {
			btnUploadClick: function () {
				SysUtil.upload($('#form1'), $('#fp'), "system", function (fileName) {
					vm.theUpdateFileName = fileName;
					closeBox();
				});
			},
			btnUpdatePartialClick: function () {
				if (vm.theUpdateFileName == "") {
					AlertUtil.alertMsg(CHECK.required.uploadFile);
					return false;
				}
				Page.postJSON({
					json: {
						cmd: RequestCmd.UPDATE_PARTIAL,
						updateType: UpdateType.CLIENT,
						method: JSONMethod.POST,
						fileName: vm.theUpdateFileName
					},
					success: function (data) {
						if (data.success) {
							localStorage.clear();
							vm.datas = data;
						} else {
							vm.datas = data;
						}
					},
					fail: function (data) {
						vm.datas = data;
					}
				});
				vm.updateFun();
			},
			updateFun: function () {
				var isOk = false;
				vm.datas = null;
				SysUtil.showProgress(ProgressTime.UPDATE_PARTIAL, PROMPT.status.updating,
					function () {
						return vm.datas != null || isOk;
					},
					function () {
						if (vm.datas.success) {
							Page.writeTime(0);
							closeBox();
							if (vm.needreboot == 1) {
								SysUtil.reboot2({
									rebootType: RENOOTTYPE.RESTORE_SETTING,
									msg: PROMPT.status.updateSuccess
								});
							} else {
								AlertUtil.alertMsg(PROMPT.status.updateSuccess);
								location.reload();
							}
						} else {
							var txt = "";
							var msg = parseInt(vm.datas.message)
							switch (msg) {
								case 101:
									txt = PROMPT.status.packageError;
									break;
								case 102:
									txt = PROMPT.status.imgPackageError;
									break;
								case 103:
									txt = PROMPT.status.spaceError;
									break;
								case 104:
									txt = PROMPT.status.uoloadFail;
									break;
								case 105:
									txt = PROMPT.status.imgUoloadFail;
									break;
								default:
									txt = PROMPT.status.unknownFail;
							}
							SysUtil.processMsg(txt);
							closeBox();
						}
					}
				);
			},
			btnsetClick: function () {
				vm.disabled = true;
				var json = {};
				json.password = this.passwordValue;
				json.username = this.usernameValue;
				json.cmd = RequestCmd.INPUT_8198D_LOGIN;
				json.method = JSONMethod.POST;
				Page.postJSON({
					json: json,
					success: function (data) {
						vm.disabled = false;
						AlertUtil.alertMsg(PROMPT.status.success);
					}
				})
			},
			getInputData: function () {
				Page.postJSON({
					json: {
						cmd: RequestCmd.INPUT_8198D_LOGIN,
						methods: JSONMethod.GET
					},
					success: function (data) {
						vm.usernameValue = data.username;
						vm.passwordValue = data.password;
					}
				})
			}
		},
		mounted: function () {
			Page.createForm(fm1);
			$('#form1').attr({
				"enctype": "multipart/form-data",
				"method": "post"
			});
			if (Page.level == "1") {
				this.isShowSuper = false;
			}
			this.getInputData();
		}
	})
});
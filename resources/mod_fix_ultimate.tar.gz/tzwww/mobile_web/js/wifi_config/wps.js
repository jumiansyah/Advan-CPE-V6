/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-03 16:53:36
 * @,@LastEditTime: ,: 2020-12-08 15:11:04
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\wifi_config\wps.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#wifi-wps",
        data(){
            return{
                title: wirelessconfightml.tab_menu.wps_24,
                title1: wirelessconfightml.tab_menu.wps_5,
                title2:wirelessconfightml.tab_menu.wps
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            showPopup(key){
                switch (key) {
                    case 0:
                        $("#app").load("html/wifi_config/wps/wps24G.html")
                        pageUrl = "html/wifi_config/wps/wps24G.html"
                        sessionStorage.setItem("pageUrl",pageUrl)
                        break;
                    case 1:
                        $("#app").load("html/wifi_config/wps/wps5G.html")
                        pageUrl = "html/wifi_config/wps/wps5G.html"
                        sessionStorage.setItem("pageUrl",pageUrl)
                        break;
                    default:
                        break;
                }
            },
        }
    })
})
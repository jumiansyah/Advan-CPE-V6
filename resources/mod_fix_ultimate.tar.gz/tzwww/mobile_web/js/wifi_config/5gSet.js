/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-03 16:30:10
 * @,@LastEditTime: ,: 2021-02-25 14:38:41
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\wifi_config\5gSet.js
 */
$(document).ready(function () {
    var form1 = wirelessconfightml.form1;
    var vm = new Vue({
        el:"#wifi5-set",
        data(){
            return{
                title:MENU.settingWifi.wifi5gAdvance,
                title1:wlan5ghtml.form1.btnSave,
                wifitxPower: form1.txPower,
                wifichannel: form1.channel,
                wifiMode: form1.wifiMode,
                wifibandwidth: wlan5ghtml.form1.bandWidth,
                wifiNum: wirelessconfightml.helper.title8_2 + ":",
                btnSave: form1.btnSave,
                tx_power:"",
                powerIndex:"",
                channelIndex:"",
                workModeIndex:"",
                bandWithIndex:"",
                txOption: [{
                    text: "100%",
                    value: '100'
                },
                {
                    text: "70%",
                    value: '70'
                },
                {
                    text: "50%",
                    value: '50'
                },
                {
                    text: "35%",
                    value: '35'
                },
                {
                    text: "15%",
                    value: '15'
                }
                ],
                channelOption: [{
                    text: form1.auto,
                    value: "auto"
                },
                {
                    text: "36",
                    value: "36"
                },
                {
                    text: "40",
                    value: "40"
                },
                {
                    text: "44",
                    value: "44"
                },
                {
                    text: "48",
                    value: "48"
                },
                {
                    text: "52",
                    value: "52"
                },
                {
                    text: "56",
                    value: "56"
                },
                {
                    text: "60",
                    value: "60"
                },
                {
                    text: "64",
                    value: "64"
                },
                {
                    text: "149",
                    value: "149"
                },
                {
                    text: "153",
                    value: "153"
                },
                {
                    text: "157",
                    value: "157"
                },
                {
                    text: "161",
                    value: "161"
                }
            ],
            wifiWorkMode: [{
                    text: "11a only",
                    value: "7"
                },
                {
                    text: "11n only",
                    value: "8"
                },
                {
                    text: "11ac only",
                    value: "9"
                },
                {
                    text: "11a/n",
                    value: "10"
                },
                {
                    text: "11n/ac",
                    value: "11"
                },
                {
                    text: "11a/n/ac",
                    value: "13"
                },
            ],
            bandWidthOption: [{
                    text: "20MHz",
                    value: "0"
                },
                {
                    text: "40MHz",
                    value: "1"
                },
                {
                    text: "80MHz",
                    value: "3"
                },
            ],
            channel_option: "auto",
            channel_optionVal:"",
            wifi_workMode: "11b only",
            wifi_workModeVal:"",
            band_width: "40MHz",
            band_widthVal:"",
            tx_power: "",
            tx_powerVal:"",
            maxNum: "",
            show:false,
            show2:false,
            show3:false,
            show4:false,
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            openPowe(){
                this.powerIndex = this.getPowerIndex;
                this.show = true;
            },
            openChannel(){
                this.channelIndex = this.getChannelIndex
                this.show2 = true;
            },
            openWorkmode(){
                this.workModeIndex = this.wifi_workModeVal == "13"?5:Number(this.wifi_workModeVal)-7
                this.show3 = true;
            },
            openBandwith(){
                this.bandWithIndex = this.band_widthVal == "3" ? 2 : Number(this.band_widthVal);
                this.show4 = true;
            },
            onSelect4(item){
                this.show4 = false;
                this.band_width = item.text;
                this.band_widthVal = item.value;
            },
            onSelect3(item){
                this.show3 = false;
                this.wifi_workMode = item.text;
                this.wifi_workModeVal = item.value;
            },
            onSelect2(item){
                this.show2 = false;
                this.channel_option = item.text;
                this.channel_optionVal = item.value;
            },
            onSelect(item){
                this.show = false;
                this.tx_power = item.text;
                this.tx_powerVal = item.value;
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS5G_ADVANCE,
                        methods: JSONMethod.GET
                    },
                    success: function (data) {
                        for(var i =0;i<vm.txOption.length;i++){
                            if(data.txPower == vm.txOption[i].value){
                                vm.tx_power = vm.txOption[i].text;
                            }
                        }
                        for(var i =0;i<vm.channelOption.length;i++){
                            if(data.channel == vm.channelOption[i].value){
                                vm.channel_option = vm.channelOption[i].text;
                            }
                        }
                        for(var i =0;i<vm.wifiWorkMode.length;i++){
                            if(data.wifiWorkMode == vm.wifiWorkMode[i].value){
                                vm.wifi_workMode = vm.wifiWorkMode[i].text
                            }
                        }
                        vm.tx_powerVal = data.txPower;
                        vm.channel_optionVal = data.channel;
                        vm.wifi_workModeVal = data.wifiWorkMode;
                        vm.band_width = data.bandWidth == "0"?"20MHz":data.bandWidth == "3"?"80MHz":"40MHz";
                        vm.maxNum = data.maxNum;
                        vm.band_widthVal = data.bandWidth
                    }
                })
            },
            save(){
                loading();
                var json = {};
                json.wifiOpen = "1";//默认
                json.txPower = vm.tx_powerVal;
                json.channel = vm.channel_optionVal;
                json.wifiWorkMode = vm.wifi_workModeVal;
                json.bandWidth = vm.band_width=="20MHz"?"0":vm.band_width=="40MHz"?"1":"2";
                json.maxNum = vm.maxNum;
                // json.eliminateNum = vm.eliminateNum;
                // json.connectNum = vm.connectNum;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WIRELESS5G_ADVANCE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            setTimeout(function () {
                                clearToast();
                                successLoad()
                            }, 6000);
                        } else {
                            setTimeout(function () {
                                failLoad()
                            }, 6000);
                        }
                    }
                })
            }
        },
        mounted(){
            this.getData()
        },
        computed:{
            getPowerIndex(){
                switch(vm.tx_powerVal){
                    case "100":
                        return 0
                    case "75":
                        return 1
                    case "50":
                        return 2
                    case "35":
                        return 3
                    case "15":
                        return 4
                    default:
                        break
                }
            },
            getChannelIndex(){
                switch(vm.channel_optionVal){
                    case "auto":
                        return 0
                    case "36":
                        return 1
                    case "40":
                        return 2
                    case "44":
                        return 3
                    case "48":
                        return 4
                    case "52":
                        return 5
                    case "56":
                        return 6
                    case "60":
                        return 7
                    case "64":
                        return 8
                    case "149":
                        return 9
                    case "153":
                        return 10
                    case "157":
                        return 11
                    case "161":
                        return 12
                    default:
                        break
                }
            }
        }
    })
})
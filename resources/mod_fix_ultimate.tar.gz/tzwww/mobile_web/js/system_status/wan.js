/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-27 17:07:49
 * @,@LastEditTime: ,: 2021-01-29 11:04:00
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\wan.js
 */
$(document).ready(function () {
    var wan_names = [TAB.basic.apn, DOC.net.ip, DOC.net.mask, DOC.net.dns1, DOC.net.dns2,
        DOC.net.ipv6, DOC.net.dns3, DOC.net.dns4, DOC.net.rxPackets, DOC.net.txPackets, DOC.net.rxBytes, DOC.net.txBytes, DOC.lbl.ifName
    ];
    // var wan_values = new Array(14);
    var vm = new Vue({
        el:"#wan",
        data(){
            return{
                active:0,
                wan_names: wan_names,
                wan_values: [],
                wanMode:DOC.lbl.netMode,
                signal:DOC.lbl.signal,
                plmn:DOC.lbl.plmn,
                RSRP:DOC.lte.rsrp,
                RSSI:DOC.lte.rssi,
                RSRQ:DOC.lte.rsrq,
                SINR:DOC.lte.sinr,
                PCI:DOC.lte.phyCellId,
                freqPoint:DOC.lbl.freqPoint,
                enodeBId:DOC.lbl.enodeBId,
                cellId:DOC.lte.cellId,
                cqi:DOC.device.cqi,
                ul_mcs:DOC.lte.ULMCS,
                dl_mcs:DOC.lte.DLMCS,
                // mcs:DOC.lte.mcs,
                bandwidth:DOC.lte.bandwidth,
                ECGI:DOC.lte.ecgi,
                currentBand:DOC.lockband.currentBand,
                wan:MENU.info.wan,
                network:DOC.title.network,
                apnInfo:DOC.title.apnInfo,
                wanInfo:{},
                timmer:""
            }
        },
        methods:{
            onClickLeft(){
                _clearInterval();
                // localStorage.setItem("headShow",true)
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
                // location.href="javascript:history.go(-1)";
            },
            clickTab(value){
                if(value==1){
                    this.getApnInfo();
                    Page.timer = setInterval(function () {
                        vm.getApnInfo();
                    }, 3000);
                }
            },
            getWanInfo() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SYS_INFO_NETWORK
                    },
                    success: function (datas) {
                        var loading = "-";
                        var mcs_info, pci_info, bandwidth_info, sinr_info, cell_id_info, cqi_info, currentband_info, freq_info, enodebid_info, mcs_info_5g, bandwidth_info_5g, sinr_info_5g, cqi_info_5g, currentband_info_5g, cell_id_info_5g, enodebid_info_5g, pci_info_5g, freq_info_5g;
                        mcs_info = datas.ul_mcs;
                        pci_info = datas.PCI;
                        bandwidth_info = datas.bandwidth;
                        sinr_info = datas.SINR;
                        cell_id_info = datas.CELL_ID;
                        cqi_info = datas.CQI;
                        currentband_info = datas.currentband;
                        freq_info = datas.FREQ;
                        enodebid_info = datas.ENODEBID;
                        mcs_info_5g = datas.dl_mcs_5g==0&&datas.RSSI?"-":datas.dl_mcs_5g;
                        ul_mcs_5g = datas.ul_mcs_5g==0&&datas.RSSI?"-":datas.ul_mcs_5g;
                        bandwidth_info_5g = datas.bandwidth_5g;
                        sinr_info_5g = datas.SINR_5G;
                        cqi_info_5g = datas.CQI_5G ==0&&datas.RSSI?"-":datas.CQI_5G;
                        currentband_info_5g = datas.currentband_5g;
                        cell_id_info_5g = datas.CELL_ID_5G;
                        enodebid_info_5g = datas.ENODEBID_5G;
                        pci_info_5g = datas.PCI_5G;
                        freq_info_5g = datas.FREQ_5G;
                        vm.$set(vm.wanInfo, vm.wanMode, datas.network_type_str || loading);
                        if(!datas.network_type_str){
                            var signal_lvl = 0
                        }else{
                            if(datas.signal_lvl>0){
                                var signal_lvl = Number(datas.signal_lvl)+1;
                            }else{
                                var signal_lvl = 1
                            }
                        }
                        
                        vm.$set(vm.wanInfo, vm.signal,signal_lvl);
                        vm.$set(vm.wanInfo, vm.plmn, datas.network_operator || loading);
                        vm.$set(vm.wanInfo, vm.RSRP, (datas.RSRP || loading) + "/" + (datas.RSRP_5G || loading));
                        vm.$set(vm.wanInfo, vm.RSSI, (datas.RSSI || loading)+ "/" + (datas.RSSI_5G || loading));;
                        vm.$set(vm.wanInfo, vm.RSRQ, (datas.RSRQ || loading) + "/" + (datas.RSRQ_5G || loading));
                        vm.$set(vm.wanInfo, vm.SINR, (sinr_info || loading) + "/" + (sinr_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.PCI, (pci_info || loading) + "/" + (pci_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.freqPoint, (freq_info || loading) + "/" + (freq_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.enodeBId, (enodebid_info || loading) + "/" + (enodebid_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.cellId, (cell_id_info || loading) + "/" + (cell_id_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.cqi, (cqi_info || loading) + "/" + (cqi_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.ul_mcs, (datas.ul_mcs || loading) + "/" + (ul_mcs_5g || loading));
                        vm.$set(vm.wanInfo, vm.dl_mcs, (datas.dl_mcs || loading) + "/" + (mcs_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.bandwidth, (bandwidth_info || loading) + "/" + (bandwidth_info_5g || loading));
                        vm.$set(vm.wanInfo, vm.ECGI, datas.ECGI || loading);
                        vm.$set(vm.wanInfo, vm.currentBand, (currentband_info || loading) + "/" + (currentband_info_5g || loading));
                        // if(Page.level == "1")
                        // {
                        //     vm_sysInfo.$set(values_sysInfo, 16, datas.ul64qam_support == "1" ? "YES" : "NO");
                        //     vm_sysInfo.$set(values_sysInfo, 17, datas.ul256qam_support == "1" ? "YES" : "NO");
                        // }
                        // if (Page.level != "3") {
                        //     vm_sysInfo.$set(values_sysInfo, 18, datas.max_ul_qam || loading);
                        //     vm_sysInfo.$set(values_sysInfo, 19, datas.max_dl_qam || loading);
                        // }
    
                    }
                })
            },
            getApnInfo() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ROUTER_INFO
                    },
                    success: function (data) {
                        var loading = "-";
                        vm.$set(vm.wan_values, 0, data.apn_name || loading);
                        vm.$set(vm.wan_values, 1, data.wan_ip || loading);
                        vm.$set(vm.wan_values, 2, data.wan_netmask || loading);
                        vm.$set(vm.wan_values, 3, data.wan_dns || loading);
                        vm.$set(vm.wan_values, 4, data.wan_dns2 || loading);
                        vm.$set(vm.wan_values, 5, data.wan_ipv6_ip || loading);
                        vm.$set(vm.wan_values, 6, data.wan_ipv6_dns || loading);
                        vm.$set(vm.wan_values, 7, data.wan_ipv6_dns2 || loading);
                        vm.$set(vm.wan_values, 8, data.wan_rx_packets || loading);
                        vm.$set(vm.wan_values, 9, data.wan_tx_packets || loading);
                        vm.$set(vm.wan_values, 10, data.wan_rx_bytes || loading);
                        vm.$set(vm.wan_values, 11, data.wan_tx_bytes || loading);
                        vm.$set(vm.wan_values, 12, data.wan_real_iface || loading);
                    }
                })
    
            },
        },
        mounted(){
            this.getWanInfo();
            Page.timer = setInterval(() => {
                this.getWanInfo();
            }, 2000);
        },
        
    })
})
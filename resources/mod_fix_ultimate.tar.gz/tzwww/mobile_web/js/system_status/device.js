/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-30 19:13:05
 * @,@LastEditTime: ,: 2021-02-22 21:14:32
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_status\device.js
 */
$(document).ready(function () {
    var loading = "-"
    var runStatusName = [DOC.lbl.runtime, DOC.lbl.loadAvg, DOC.lbl.memoryTotal, DOC.lbl.memoryFree, DOC.lbl.memoryCache,"AP CPU0 "+DOC.lbl.temperature,"AP CPU1 "+DOC.lbl.temperature,"Sensor "+DOC.lbl.temperature,
    "NRCP "+DOC.lbl.temperature,"AP CPU0(2) "+DOC.lbl.temperature,"AP CPU1(2) "+DOC.lbl.temperature,"AP CPU TOP "+DOC.lbl.temperature];
    var deviceName = [DOC.device.model, DOC.device.softwarVersion, DOC.device.hardwareVersion, DOC.device.configVersion, DOC.device.buildTime, DOC.device.gitBranch, DOC.device.gitCommit, "SN", DOC.device.realVersion, DOC.info.simStatus, DOC.device.idu_firmware_version,
    DOC.device.idu_config_version, DOC.device.idu_config_type, DOC.device.idu_git_branch, DOC.device.idu_git_sha, DOC.device.idu_build_time, DOC.device.impower];
    var lteInfoName = [DOC.device.modemVersion, DOC.device.modsoftversion, DOC.device.modhardwareversion, "IMEI", "IMSI", "ICCID", "SN"];
    var vm = new Vue({
        el:"#device-info",
        data(){
            return{
                runStatus: DOC.title.run,
                device: DOC.title.device,
                lteInfo: DOC.title.lte,
                title1:MENU.info.version,
                runStatusValues: [],
                deviceValues: [],
                lteInfoValues: [],
                runStatusName: runStatusName,
                deviceName: deviceName,
                lteInfoName: lteInfoName,
                activeName: ['1','2','3'],
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DEVICE_INFO
                    },
                    success: function (data) {
                        vm.$set(vm.runStatusValues, 0, ConvertUtil.parseUptime2(data.uptime) || loading);
                        vm.$set(vm.runStatusValues, 1, data.cpuload || loading);
                        var memory = data.memory;
    
                        var memoryArr = memory.split(",");
                        vm.$set(vm.runStatusValues, 2, memoryArr[0] || loading);
                        vm.$set(vm.runStatusValues, 3, memoryArr[1] || loading);
                        vm.$set(vm.runStatusValues, 4, memoryArr[2] || loading);
                        if(!!data.temp_list && data.temp_list[0])
                        {
                            if(Page.level == "1")
                        {
                            vm.$set(vm.runStatusValues, 8, parseInt(data.temp_list[0]["nrcp-thmzone"])/1000+"℃" || loading);
                            vm.$set(vm.runStatusValues, 7, parseInt(data.temp_list[0]["soc-thmzone"])/1000+"℃" || loading);
                            vm.$set(vm.runStatusValues, 9, parseInt(data.temp_list[0]["ank0-thmzone"])/1000+"℃" || loading);
                            vm.$set(vm.runStatusValues, 10,parseInt(data.temp_list[0]["ank1-thmzone"])/1000+"℃" || loading);
                            vm.$set(vm.runStatusValues, 11,parseInt(data.temp_list[0]["cluster0-thmzone"])/1000+"℃" || loading);
    
                        }
                           vm.$set(vm.runStatusValues, 5, parseInt(data.temp_list[0]["apcpu0-thmzone"])/1000+"℃" || loading);
                           vm.$set(vm.runStatusValues, 6, parseInt(data.temp_list[0]["apcpu1-thmzone"])/1000+"℃" || loading);
    
                       }else
                       {
                          if(Page.level == "1")
                        {
                            vm.$set(vm.runStatusValues, 8,loading);
                            vm.$set(vm.runStatusValues, 7,loading);
                            vm.$set(vm.runStatusValues, 9,loading);
                            vm.$set(vm.runStatusValues, 10,loading);
                            vm.$set(vm.runStatusValues, 11,loading);
    
                        }
                           vm.$set(vm.runStatusValues, 5,loading);
                           vm.$set(vm.runStatusValues, 6,loading);
                       }
                        vm.$set(vm.deviceValues, 0, data.board_type || loading);
                        vm.$set(vm.deviceValues, 1, data.fake_version || loading);
                        vm.$set(vm.deviceValues, 2, data.hwversion || loading);
                        if (Page.level != "3") {
                            vm.$set(vm.deviceValues, 3, data.config_version || loading);
                            vm.$set(vm.deviceValues, 7, data.device_sn || loading);
                        }
                        if (Page.level == "1") {    
                            vm.$set(vm.deviceValues, 4, data.build_date || loading);
                            vm.$set(vm.deviceValues, 5, data.git_branch || loading);
                            vm.$set(vm.deviceValues, 6, data.git_sha || loading);
                            vm.$set(vm.deviceValues, 8, data.real_fwversion || loading);
                            vm.$set(vm.deviceValues, 9, data.sim_slot || loading);
                            vm.$set(vm.deviceValues, 10, data.idu_firmware_version || loading);
                            vm.$set(vm.deviceValues, 11, data.idu_config_version || loading);
                            vm.$set(vm.deviceValues, 12, data.idu_dev_type || loading);
                            vm.$set(vm.deviceValues, 13, data.idu_git_branch || loading);
                            vm.$set(vm.deviceValues, 14, data.idu_git_sha || loading);
                            vm.$set(vm.deviceValues, 15, data.idu_build_time || loading);
                            vm.$set(vm.deviceValues, 16, data.verify_status || loading);
                        }
                        
    
                        vm.$set(vm.lteInfoValues, 0, data.module_type || loading);
                        vm.$set(vm.lteInfoValues, 1, data.module_softver || loading);
                        vm.$set(vm.lteInfoValues, 2, data.module_hardver || loading);
                        vm.$set(vm.lteInfoValues, 3, data.module_imei || loading);
                        vm.$set(vm.lteInfoValues, 4, data.IMSI || loading);
                        vm.$set(vm.lteInfoValues, 5, data.ICCID || loading);
                        vm.$set(vm.lteInfoValues, 6, data.device_sn || loading);
                    }
                })
            },
            runStatusNameShow: function (index) {
                if (Page.level != "1" && (index == "7" || index == "8" || index == "9" || index == "10" || index == "11")) {
                    return false;
                } else {
                    return true;
                }
            },
            deviceArrShow: function (index) {
                if (Page.level != "1" && (index == "4" || index == "5" || index == "6" || index == "8" || index == "9" || index == "10" || index == "11" || index == "12" || index == "13" || index == "14" || index == "15" || index == "16")
                    ||  ((index == "3" || index == "7")&& Page.level == "3")) {
                    return false;
                } else {
                    return true;
                }
            },
            lteInfoNameShow: function (index) {
                if (Page.level == "1") {
                    return true;
                } else {
                    if (index == "3" || index == "4" || index == "5") {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },
        mounted(){
            this.getData();
            this.lteInfoNameTable = Page.level;
            Page.timer = setInterval(function () {
                vm.getData();
            }, 3000);
        }
    })
})
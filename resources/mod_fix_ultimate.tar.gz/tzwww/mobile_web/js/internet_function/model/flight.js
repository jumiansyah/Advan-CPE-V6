/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 20:16:45
 * @,@LastEditTime: ,: 2020-12-07 21:37:01
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\model\flight.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#flight-model",
        data(){
            return{
                flightMode: DOC.lbl.flightMode,
                checked:false
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/internet_function/mobile.html")
                pageUrl = "html/internet_function/mobile.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.FLIGHT_MODE_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked = data.flightMode == "1" ? true:false;
                    }
                });
            },
            submit(){
                var json = {};
                loading();
                json.flightMode = this.checked ? "1" : "0";
                json.cmd = RequestCmd.FLIGHT_MODE_INFO;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.message == "0") {
                            clearToast()
                            successLoad();
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            }
        },
        mounted(){
            this.getData()
        }
    })
})
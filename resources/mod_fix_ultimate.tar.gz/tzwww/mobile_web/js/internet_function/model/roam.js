/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 21:13:13
 * @,@LastEditTime: ,: 2020-12-07 21:36:42
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\model\roam.js
 */
/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 20:16:45
 * @,@LastEditTime: ,: 2020-12-01 20:49:05
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\model\flight.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#roam-model",
        data(){
            return{
                dataRoaming: TAB.advance.dataRoaming,
                checked:false
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/internet_function/mobile.html")
                pageUrl = "html/internet_function/mobile.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DATA_ROAMING,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked = data.roamingEnable == "1" ? true:false;
                    }
                });
            },
            submit(){
                var json = {};
                loading();
                json.roamingEnable = this.checked ? "1" : "0";
                json.cmd = RequestCmd.DATA_ROAMING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.message == "") {
                            clearToast()
                            successLoad();
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            }
        },
        mounted(){
            this.getData()
        }
    })
})
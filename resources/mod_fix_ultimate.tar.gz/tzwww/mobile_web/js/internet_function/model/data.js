/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 20:54:10
 * @,@LastEditTime: ,: 2020-12-03 13:49:55
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\model\data.js
 */
/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 20:16:45
 * @,@LastEditTime: ,: 2020-12-01 20:49:05
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\model\flight.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#data-model",
        data(){
            return{
                dataSwitch:TAB.advance.dataSwitch,
                checked:false
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/internet_function/mobile.html")
                pageUrl = "html/internet_function/mobile.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getData(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.AUTO_DIAL,
                        method:JSONMethod.GET
                    },
                    success: function (data) {
                        vm.checked = data.dialMode == "1" ? true:false;
                    }
                });
            },
            submit(){
                var json = {};
                loading();
                json.dialMode = this.checked ? "1" : "0";
                json.cmd = RequestCmd.AUTO_DIAL;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            clearToast();
                            successLoad();
                        }else{
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            }
        },
        mounted(){
            this.getData()
        }
    })
})
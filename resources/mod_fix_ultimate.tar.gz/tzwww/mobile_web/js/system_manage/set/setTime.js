/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-07 10:09:15
 * @,@LastEditTime: ,: 2020-12-18 11:49:22
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_manage\set\setTime.js
 */
$(document).ready(function(){
    var vm = new Vue({
        el:"#set-time",
        data(){
            return{
                title1:MENU.sys.timeSetting,
                systemTime: DOC.sys.systemTime,
                timezone: DOC.sys.timezone,
                ntp: DOC.sys.ntp,
                clientTime: DOC.sys.clientTime,
                getClientTime: DOC.btn.getClientTime,
                save: DOC.btn.save,
                datetimeValue: "",
                lblTimeText: "",
                timeServerValue: "",
                timeServer2Value: "",
                timeServer3Value: "",
                timeServer4Value: "",
                timezoneValue: "",
                selectIndex:"",
                timezoneHtml: [{
                    text: DOC.timezone.item,
                    value: "UTC12"
                },
                {
                    text: DOC.timezone.halfitem1,
                    value: "UTC11:30"
                },
                {
                    text: DOC.timezone.item1,
                    value: "UTC11"
                },
                {
                    text: DOC.timezone.halfitem2,
                    value: "UTC10:30"
                },
                {
                    text: DOC.timezone.item2,
                    value: "UTC10"
                },
                {
                    text: DOC.timezone.halfitem3,
                    value: "UTC9:30"
                },
                {
                    text: DOC.timezone.item3,
                    value: "UTC9"
                },
                {
                    text: DOC.timezone.halfitem4,
                    value: "UTC8:30"
                },
                {
                    text: DOC.timezone.item4,
                    value: "UTC8"
                },
                {
                    text: DOC.timezone.halfitem5,
                    value: "UTC7:30"
                },
                {
                    text: DOC.timezone.item5,
                    value: "UTC7"
                },
                {
                    text: DOC.timezone.halfitem6,
                    value: "UTC6:30"
                },
                {
                    text: DOC.timezone.item6,
                    value: "UTC6"
                },
                {
                    text: DOC.timezone.halfitem7,
                    value: "UTC5:30"
                },
                {
                    text: DOC.timezone.item7,
                    value: "UTC5"
                },
                {
                    text: DOC.timezone.halfitem8,
                    value: "UTC4:30"
                },
                {
                    text: DOC.timezone.item8,
                    value: "UTC4"
                },
                {
                    text: DOC.timezone.halfitem9,
                    value: "UTC3:30"
                },
                {
                    text: DOC.timezone.item9,
                    value: "UTC3"
                },
                {
                    text: DOC.timezone.halfitem10,
                    value: "UTC2:30"
                },
                {
                    text: DOC.timezone.item10,
                    value: "UTC2"
                },
                {
                    text: DOC.timezone.halfitem11,
                    value: "UTC1:30"
                },
                {
                    text: DOC.timezone.item11,
                    value: "UTC1"
                },
                {
                    text: DOC.timezone.halfitem12,
                    value: "UTC0:30"
                },
                {
                    text: DOC.timezone.item12,
                    value: "UTC0"
                },
                {
                    text: DOC.timezone.halfitem13,
                    value: "UTC-0:30"
                },
                {
                    text: DOC.timezone.item13,
                    value: "UTC-1"
                },
                {
                    text: DOC.timezone.halfitem14,
                    value: "UTC-1:30"
                },
                {
                    text: DOC.timezone.item14,
                    value: "UTC-2"
                },
                {
                    text: DOC.timezone.halfitem15,
                    value: "UTC-2:30"
                },
                {
                    text: DOC.timezone.item15,
                    value: "UTC-3"
                },
                {
                    text: DOC.timezone.halfitem16,
                    value: "UTC-3:30"
                },
                {
                    text: DOC.timezone.item16,
                    value: "UTC-4"
                },
                {
                    text: DOC.timezone.halfitem17,
                    value: "UTC-4:30"
                },
                {
                    text: DOC.timezone.item17,
                    value: "UTC-5"
                },
                {
                    text: DOC.timezone.halfitem18,
                    value: "UTC-5:30"
                },
                {
                    text: DOC.timezone.item18,
                    value: "UTC-6"
                },
                {
                    text: DOC.timezone.halfitem19,
                    value: "UTC-6:30"
                },
                {
                    text: DOC.timezone.item19,
                    value: "UTC-7"
                },
                {
                    text: DOC.timezone.halfitem20,
                    value: "UTC-7:30"
                },
                {
                    text: DOC.timezone.item20,
                    value: "UTC-8"
                },
                {
                    text: DOC.timezone.halfitem21,
                    value: "UTC-8:30"
                },
                {
                    text: DOC.timezone.item21,
                    value: "UTC-9"
                },
                {
                    text: DOC.timezone.halfitem22,
                    value: "UTC-9:30"
                },
                {
                    text: DOC.timezone.item22,
                    value: "UTC-10"
                },
                {
                    text: DOC.timezone.halfitem23,
                    value: "UTC-10:30"
                },
                {
                    text: DOC.timezone.item23,
                    value: "UTC-11"
                },
                {
                    text: DOC.timezone.halfitem24,
                    value: "UTC-11:30"
                },
                {
                    text: DOC.timezone.item24,
                    value: "UTC-12"
                }
            ],
            show:false,
            time:"",
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/system_manage/setting.html")
                pageUrl = "html/system_manage/setting.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            openTime(){
                this.show = true;
                this.selectIndex = this.getIndex;
            },
            onSelect(item){
                this.show = false
                this.time = item.text
                this.timezoneValue = item.value
            },
            getDateTime: function () {
                return new Date().format('yyyy-mm-dd HH:MM');
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SET_DATETIME,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.lblTimeText = data.systime;
                        vm.timeServerValue = FormatUtil.formatField(data.timeServer).trim();
                        vm.timeServer2Value = FormatUtil.formatField(data.timeServer2).trim();
                        vm.timeServer3Value = FormatUtil.formatField(data.timeServer3).trim();
                        vm.timeServer4Value = FormatUtil.formatField(data.timeServer4).trim();
                        var timezone = FormatUtil.formatField(data.timezone);
                        if (timezone.length == 0) {
                            timezone = "UTC-8";
                        }
                        vm.timezoneValue = timezone;
                        for(var i=0;i<vm.timezoneHtml.length;i++){
                            if(vm.timezoneHtml[i].value == timezone){
                                vm.time = vm.timezoneHtml[i].text
                            }
                        }
                    }
                });
    
            },
            getTime: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SET_DATETIME,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.lblTimeText = data.systime;
                    }
                });
            },
            btnSave: function () {
                
                loading();
                var json = {
                    timezone:this.timezoneValue,
                    timeServer:this.timeServerValue,
                    timeServer2:this.timeServer2Value,
                    timeServer3:this.timeServer3Value,
                    timeServer4:this.timeServer4Value
                }
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.SET_DATETIME;
    
                try {
                    var theDateTime = vm.datetimeValue;
                    var datetime = theDateTime.replace(/[\-|\:|\s]/g, "");
                    json.datetime = datetime.slice(4) + datetime.substring(0, 4);
                    console.log(json);
                    Page.postJSON({
                        json: json,
                        success: function (data) {
                            if (data.success == true) {
                                clearToast();
                                successLoad();
                            } else {
                                failLoad();
                            }
                        }
                    });
                } catch (ex) {
                    failLoad(CHECK.format.systemTime)
                }
            },
            autoTimeClick: function () {
                this.datetimeValue = this.getDateTime()
            }
        },
        mounted(){
            this.datetimeValue = this.getDateTime();
            this.getData();
            Page.timer = setInterval(function () {
                vm.getTime();
            }, 1000);
        },
        computed:{
            getIndex(){
                for(var i=0;i<vm.timezoneHtml.length;i++){
                    if(vm.timezoneHtml[i].value == vm.timezoneValue){
                        return i
                    }
                }
            }
        }
    })
})
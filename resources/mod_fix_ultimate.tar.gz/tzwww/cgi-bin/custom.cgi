#!/bin/sh
# Custom CGI - BusyBox compatible

# Simpan stderr ke log agar response HTTP tetap JSON bersih.
exec 2>>/tmp/custom_cgi.err.log

# Gabungkan QUERY_STRING + POST body (jika ada)  
# PENTING: jQuery JSONP selalu mengirim GET, jadi QUERY_STRING adalah sumber utama
if [ "$REQUEST_METHOD" = "POST" ] && [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
    POST_BODY=$(dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null)
    POST_DATA="$QUERY_STRING&$POST_BODY"
    
    # Debug POST data parsing
    echo "POST Debug: QUERY=$QUERY_STRING BODY=$POST_BODY COMBINED=$POST_DATA" >> /tmp/post_debug.log
else
    POST_DATA="$QUERY_STRING"
fi

# URL decode - BusyBox ash compatible (no local, no echo -e)
urldecode() {
    echo "$1" | sed 's/+/ /g; s/%20/ /g; s/%21/!/g; s/%22/"/g; s/%23/#/g; s/%25/%/g; s/%26/\&/g; s/%27/'\''/g; s/%28/(/g; s/%29/)/g; s/%2C/,/g; s/%2F/\//g; s/%3A/:/g; s/%3B/;/g; s/%3D/=/g; s/%3F/?/g; s/%40/@/g; s/%0D//g; s/%0A/ /g; s/%5B/[/g; s/%5D/]/g; s/%7B/{/g; s/%7D/}/g'
}

fw_tools_ready() {
    command -v iptables >/dev/null 2>&1 || return 1
    command -v ip6tables >/dev/null 2>&1 || return 1
    iptables -V >/dev/null 2>&1 || return 1
    ip6tables -V >/dev/null 2>&1 || return 1
    return 0
}

fw_try_heal() {
    if [ -x /usr/bin/limiter ]; then
        /usr/bin/limiter heal >/dev/null 2>&1
    fi
    fw_tools_ready
}

require_fw_json() {
    fw_tools_ready && return 0
    fw_try_heal && return 0
    echo '{"success":false,"msg":"Firewall tools unavailable. Jalankan limiter heal / restore xtables-multi dari /mnt/data/binary."}'
    return 1
}


# BusyBox-compatible parameter parser
get_param() {
    RAW_VAL=$(echo "$POST_DATA" | sed 's/&/\n/g' | grep "^$1=" | sed "s/^$1=//")
    urldecode "$RAW_VAL"
}

ACTION=$(get_param "action")

# Untuk semua action limiter, coba self-heal dulu secara silent jika firewall tools hilang.
if echo "$ACTION" | grep -q '^limiter_'; then
    fw_tools_ready || fw_try_heal >/dev/null 2>&1
fi

# HTTP Header
echo "Content-Type: application/json"
echo ""

case "$ACTION" in

reset_ttl)
    require_fw_json || exit 0
    # Hapus semua TTL rules + startup scripts
    iptables -t mangle -F PREROUTING 2>/dev/null
    iptables -t mangle -F POSTROUTING 2>/dev/null
    mount -o remount,rw /
    rm -f /etc/tzscript/fix_ttl_boot.sh
    rm -f /etc/init.d/S99fixttl
    rm -f /etc/rc5.d/S99fixttl
    sync && mount -o remount,ro /
    echo "{\"success\":true,\"msg\":\"TTL reset. Startup removed.\"}"
    ;;

read_ttl)
    require_fw_json || exit 0
    TTL_VAL=$(iptables -t mangle -L PREROUTING -n 2>/dev/null | grep "TTL set to" | awk '{print $NF}')
    if [ -n "$TTL_VAL" ]; then
        echo "{\"success\":true,\"ttl\":\"$TTL_VAL\"}"
    else
        echo "{\"success\":true,\"ttl\":\"0\",\"msg\":\"No TTL rule\"}"
    fi
    ;;

set_ttl)
    require_fw_json || exit 0
    TTL_VAL=$(get_param "value")
    case "$TTL_VAL" in
        ''|*[!0-9]*) echo "{\"success\":false,\"msg\":\"Invalid TTL\"}"; exit 0 ;;
    esac
    if [ "$TTL_VAL" -lt 1 ] || [ "$TTL_VAL" -gt 255 ]; then
        echo "{\"success\":false,\"msg\":\"TTL 1-255\"}"
        exit 0
    fi
    # Apply iptables sekarang
    iptables -t mangle -F PREROUTING 2>/dev/null
    iptables -t mangle -F POSTROUTING 2>/dev/null
    iptables -t mangle -A PREROUTING -j TTL --ttl-set "$TTL_VAL" 2>/dev/null
    iptables -t mangle -A POSTROUTING -j TTL --ttl-set "$TTL_VAL" 2>/dev/null

    # Persist: update boot script + init.d (Yocto rc5.d startup)
    mount -o remount,rw /
    cat > /etc/tzscript/fix_ttl_boot.sh << BOOTEOF
#!/bin/sh
sleep 5
iptables -t mangle -F PREROUTING 2>/dev/null
iptables -t mangle -F POSTROUTING 2>/dev/null
iptables -t mangle -A PREROUTING -j TTL --ttl-set $TTL_VAL
iptables -t mangle -A POSTROUTING -j TTL --ttl-set $TTL_VAL
BOOTEOF
    chmod +x /etc/tzscript/fix_ttl_boot.sh
    # Pastikan init.d + rc5.d symlink ada
    cat > /etc/init.d/S99fixttl << 'INITEOF'
#!/bin/sh
(sleep 30; /etc/tzscript/fix_ttl_boot.sh) &
INITEOF
    chmod +x /etc/init.d/S99fixttl
    ln -sf /etc/init.d/S99fixttl /etc/rc5.d/S99fixttl 2>/dev/null
    sync && mount -o remount,ro /

    # Verifikasi
    CHECK=$(iptables -t mangle -L PREROUTING -n 2>/dev/null | grep "TTL set to")
    if [ -n "$CHECK" ]; then
        echo "{\"success\":true,\"msg\":\"TTL=$TTL_VAL applied + boot script updated\",\"ttl\":\"$TTL_VAL\"}"
    else
        echo "{\"success\":false,\"msg\":\"Failed\"}"
    fi
    ;;

read_imei)
    # atcmd output: "recv:\n865840070726255\nOK"
    IMEI=$(atcmd "at+spimei?" 2>/dev/null | tr -d '\r' | grep -oE '[0-9]{15}')
    if [ -z "$IMEI" ]; then
        IMEI=$(mdlcfg -g MODULE_IMEI 2>/dev/null | tr -d '\r')
    fi
    if [ -n "$IMEI" ]; then
        echo "{\"success\":true,\"imei\":\"$IMEI\"}"
    else
        echo "{\"success\":false,\"msg\":\"Cannot read IMEI\"}"
    fi
    ;;

set_imei)
    NEW_IMEI=$(get_param "imei")
    CHECK=$(echo "$NEW_IMEI" | grep -cE '^[0-9]{15}$')
    if [ "$CHECK" != "1" ]; then
        echo "{\"success\":false,\"msg\":\"IMEI harus 15 digit\"}"
        exit 0
    fi
    RESULT=$(atcmd "at+spimei=0,\"$NEW_IMEI\"" 2>&1 | tr -d '\r')
    if echo "$RESULT" | grep -qi "OK"; then
        echo "{\"success\":true,\"msg\":\"IMEI=$NEW_IMEI OK. Rebooting...\",\"imei\":\"$NEW_IMEI\"}"
        # Auto reboot setelah 2 detik
        (sleep 2 && reboot) &
    else
        CLEAN=$(echo "$RESULT" | tr '\n' ' ' | tr '"' "'")
        echo "{\"success\":false,\"msg\":\"$CLEAN\"}"
    fi
    ;;

read_sms)
    # Delegasi ke sendsms engine
    if [ "$(get_param "clear")" = "1" ]; then
        /usr/bin/sendsms clear > /dev/null 2>&1
    fi
    /usr/bin/sendsms read
    ;;

delete_sms)
    SMS_ID=$(get_param "smsId")
    if [ -n "$SMS_ID" ]; then
        /usr/bin/sendsms delete "$SMS_ID" > /dev/null 2>&1
    elif [ "$(get_param "clear")" = "1" ]; then
        /usr/bin/sendsms clear > /dev/null 2>&1
    fi
    echo "{\"success\":true,\"message\":\"Berhasil dihapus\"}"
    ;;

save_draft)
    PHONE=$(get_param "phoneNo")
    RAW_CONTENT=$(echo "$POST_DATA" | sed 's/&/\n/g' | grep "^content=" | sed "s/^content=//")
    CONTENT=$(urldecode "$RAW_CONTENT")

    if [ -z "$CONTENT" ]; then
        echo "{\"success\":false,\"message\":\"Isi pesan kosong\"}"
        exit 0
    fi

    # Tulis isi pesan ke file temp (sendsms membaca dari file, aman untuk encrypted binary)
    echo "$CONTENT" > /tmp/sms_draft_body.txt
    (/usr/bin/sendsms draft "$PHONE" /tmp/sms_draft_body.txt > /dev/null 2>&1; rm -f /tmp/sms_draft_body.txt) < /dev/null > /dev/null 2>&1 &

    echo "{\"success\":true,\"message\":\"Draft Tersimpan!\"}"
    ;;

send_sms)
    PHONE=$(get_param "phoneNo")
    RAW_CONTENT=$(echo "$POST_DATA" | sed 's/&/\n/g' | grep "^content=" | sed "s/^content=//")
    CONTENT=$(urldecode "$RAW_CONTENT")

    if [ -z "$PHONE" ]; then
        echo "{\"success\":false,\"message\":\"Nomor tujuan kosong\"}"
        exit 0
    fi

    # Tulis isi pesan ke file temp (sendsms membaca dari file, aman untuk encrypted binary)
    echo "$CONTENT" > /tmp/sms_send_body.txt
    (/usr/bin/sendsms send "$PHONE" /tmp/sms_send_body.txt > /dev/null 2>&1; rm -f /tmp/sms_send_body.txt) < /dev/null > /dev/null 2>&1 &

    echo "{\"success\":true,\"message\":\"Pesan Terkirim!\"}"
    ;;

test_at)
    # Diagnostic: cek AT device dan test atcmd + serial
    DEVLIST=""
    for d in /dev/stty_lte0 /dev/stty_lte1 /dev/ttyGS0; do
        [ -c "$d" ] && DEVLIST="$DEVLIST $d"
    done

    AT_TEST=$(atcmd "AT" 2>&1 | tr '"' "'" | tr '\n' ' ')
    CMGF_TEST=$(atcmd "AT+CMGF?" 2>&1 | tr '"' "'" | tr '\n' ' ')
    CPMS_TEST=$(atcmd "AT+CPMS?" 2>&1 | tr '"' "'" | tr '\n' ' ')

    # Test tulis ke serial device
    SERIAL_TEST=""
    if [ -c "/dev/stty_lte1" ]; then
        printf 'AT\r' > /dev/stty_lte1
        sleep 1
        SERIAL_TEST="stty_lte1:writable"
    elif [ -c "/dev/stty_lte0" ]; then
        printf 'AT\r' > /dev/stty_lte0
        sleep 1
        SERIAL_TEST="stty_lte0:writable"
    else
        SERIAL_TEST="no_device"
    fi

    echo "{\"devices\":\"$DEVLIST\",\"at_test\":\"$AT_TEST\",\"cmgf\":\"$CMGF_TEST\",\"cpms\":\"$CPMS_TEST\",\"serial_test\":\"$SERIAL_TEST\"}"
    ;;

adb_telnet_status)
    # Gunakan pengecekan Port Jaringan (Netstat) untuk akurasi mutlak Telnet
    T_STATUS="false"
    A_STATUS="false"
    
    # Cek apakah port 23 sedang dalam status LISTEN
    if netstat -tuln 2>/dev/null | grep -q ":23 "; then
        T_STATUS="true"
    fi
    # Cek proses ADB
    if pidof adbd >/dev/null 2>&1; then
        A_STATUS="true"
    fi
    
    echo "{\"success\":true,\"telnet\":$T_STATUS,\"adb\":$A_STATUS}"
    ;;

adb_telnet_toggle)
    TARGET=$(get_param "target")
    STATE=$(get_param "state")
    
    if [ "$TARGET" = "telnet" ]; then
        if [ "$STATE" = "1" ]; then
            killall -9 telnetd > /dev/null 2>&1
            /usr/bin/telnetd -p 23 -l /bin/sh &
            echo "{\"success\":true,\"message\":\"Telnet dihidupkan pada port 23\"}"
        else
            killall -9 telnetd > /dev/null 2>&1
            echo "{\"success\":true,\"message\":\"Telnet dimatikan\"}"
        fi
    elif [ "$TARGET" = "adb" ]; then
        if [ "$STATE" = "1" ]; then
            killall -9 adbd > /dev/null 2>&1
            /usr/bin/usbenum.sh enable debug > /dev/null 2>&1
            adbd &
            echo "{\"success\":true,\"message\":\"ADB dihidupkan via USB\"}"
        else
            killall -9 adbd > /dev/null 2>&1
            /usr/bin/usbenum.sh disable debug > /dev/null 2>&1
            echo "{\"success\":true,\"message\":\"ADB dimatikan\"}"
        fi
    else
        echo "{\"success\":false,\"message\":\"Target tidak valid\"}"
    fi
    ;;

modem_info)
    IMEI=$(cat /etc/productinfo/imei 2>/dev/null | tr -d '\n\r')
    MODEL=$(cat /etc/productinfo/product_name 2>/dev/null | tr -d '\n\r')
    [ -z "$MODEL" ] && MODEL=$(atcmd "AT+CGMM" 2>/dev/null | grep -v "^recv" | grep -v "^OK" | grep -v "^$" | tr -d '\n\r')
    [ -z "$MODEL" ] && MODEL="Advan V6"
    echo "{\"imei\":\"$IMEI\",\"model\":\"$MODEL\"}"
    ;;

# ===================== SPEED LIMITER =====================

limiter_scan)
    LAN_IF="br0"
    DB="/mnt/data/limiter"
    echo '{"devices":['
    FIRST=1
    
    # AGGRESSIVE ARP CACHE FLUSH - hapus ghost IPs secara paksa
    awk -v iface="$LAN_IF" '$6==iface && $4!="00:00:00:00:00:00" {print $1}' /proc/net/arp 2>/dev/null | while read old_ip; do
        [ -z "$old_ip" ] && continue
        ip neigh del "$old_ip" dev "$LAN_IF" 2>/dev/null
        # Ping sebagai trigger ARP broadcast (1 detik timeout)
        ( ping -c 1 -W 1 "$old_ip" >/dev/null 2>&1 ) &
    done
    
    # Tunggu 1.5 detik agar device asli merespons ARP broadcast
    sleep 2
    
    # Filter HANYA ARP flag 0x2 (reachable) - ghost tidak akan bisa hidup lagi
    awk -v iface="$LAN_IF" '$6==iface && $3=="0x2" && $4!="00:00:00:00:00:00" {print $1,$4}' /proc/net/arp 2>/dev/null > /tmp/cgi_scan_$$
    while read ip mac; do
        [ -z "$mac" ] && continue
        # Hostname from DHCP leases
        hname=""
        for lf in /tmp/dhcp.leases /tmp/dnsmasq.leases /var/lib/misc/dnsmasq.leases; do
            [ -f "$lf" ] && hname=$(grep -i "$mac" "$lf" | awk '{print $4}' | head -n 1)
            [ -n "$hname" ] && [ "$hname" != "*" ] && break
        done
        [ -z "$hname" ] || [ "$hname" = "*" ] && hname="Unknown"
        hname=$(echo "$hname" | tr '"' "'")

        # Check status in limiter databases
        status="none"; speed=""
        if grep -qi "$mac" "$DB/block.db" 2>/dev/null; then
            status="blocked"
        elif grep -qi "$mac" "$DB/rules.db" 2>/dev/null; then
            status="limited"
            speed=$(grep -i "$mac" "$DB/rules.db" | head -n 1 | cut -d'|' -f3)
        fi
        if grep -qi "$mac" "$DB/pintar.db" 2>/dev/null; then
            status="scheduled"
        fi

        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"ip":"%s","mac":"%s","name":"%s","status":"%s","speed":"%s"}' "$ip" "$mac" "$hname" "$status" "$speed"
    done < /tmp/cgi_scan_$$
    rm -f /tmp/cgi_scan_$$
    echo ']}'
    ;;

limiter_status)
    DB="/mnt/data/limiter"
    mkdir -p "$DB"

    # Rules
    echo '{"rules":['
    FIRST=1
    [ -f "$DB/rules.db" ] && while IFS='|' read -r mac ip speed name; do
        [ -z "$mac" ] && continue
        name=$(echo "$name" | tr '"' "'" | tr -d '\r\n')
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"mac":"%s","ip":"%s","speed":"%s","name":"%s"}' "$mac" "$ip" "$speed" "$name"
    done < "$DB/rules.db"

    # Blocked
    echo '],"blocked":['
    FIRST=1
    [ -f "$DB/block.db" ] && while IFS='|' read -r mac ip name; do
        [ -z "$mac" ] && continue
        name=$(echo "$name" | tr '"' "'" | tr -d '\r\n')
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"mac":"%s","ip":"%s","name":"%s"}' "$mac" "$ip" "$name"
    done < "$DB/block.db"

    # Pintar (scheduled)
    echo '],"pintar":['
    FIRST=1
    [ -f "$DB/pintar.db" ] && while IFS='|' read -r mac ip name start end days cat; do
        [ -z "$mac" ] && continue
        name=$(echo "$name" | tr '"' "'" | tr -d '\r\n')
        [ -z "$cat" ] && cat="ALL"
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"mac":"%s","ip":"%s","name":"%s","start":"%s","end":"%s","days":"%s","cat":"%s"}' "$mac" "$ip" "$name" "$start" "$end" "$days" "$cat"
    done < "$DB/pintar.db"

    # Settings
    G_SPEED=""; [ -f "$DB/global.conf" ] && G_SPEED=$(cat "$DB/global.conf" | tr -d '\r\n')
    L_SPEED=""; [ -f "$DB/local.conf" ] && L_SPEED=$(cat "$DB/local.conf" | tr -d '\r\n')
    AS="off"; [ -f /etc/init.d/S99limiter ] && AS="on"

    echo "],"
    printf '"global":"%s","local":"%s","autostart":"%s"}' "$G_SPEED" "$L_SPEED" "$AS"
    ;;

limiter_set)
    MAC=$(get_param "mac")
    IP=$(get_param "ip")
    SPEED=$(get_param "speed")
    NAME=$(get_param "name")
    DB="/mnt/data/limiter"
    mkdir -p "$DB"
    [ ! -f "$DB/rules.db" ] && touch "$DB/rules.db"

    if [ -z "$MAC" ] || [ -z "$SPEED" ]; then
        echo '{"success":false,"message":"MAC dan Speed wajib diisi"}'
        exit 0
    fi

    # Hapus entry lama dengan grep -v (case-insensitive)
    if [ -f "$DB/rules.db" ]; then
        grep -iv "$MAC" "$DB/rules.db" > "$DB/rules.db.tmp" 2>/dev/null
        mv -f "$DB/rules.db.tmp" "$DB/rules.db" 2>/dev/null
    fi
    if [ -f "$DB/block.db" ]; then
        grep -iv "$MAC" "$DB/block.db" > "$DB/block.db.tmp" 2>/dev/null
        mv -f "$DB/block.db.tmp" "$DB/block.db" 2>/dev/null
    fi
    echo "$MAC|$IP|$SPEED|$NAME" >> "$DB/rules.db"
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Speed limit diterapkan"}'
    ;;

limiter_block)
    MAC=$(get_param "mac")
    IP=$(get_param "ip")
    NAME=$(get_param "name")
    DB="/mnt/data/limiter"
    mkdir -p "$DB"
    [ ! -f "$DB/block.db" ] && touch "$DB/block.db"

    if [ -z "$MAC" ]; then
        echo '{"success":false,"message":"MAC wajib diisi"}'
        exit 0
    fi

    # Hapus entry lama dengan grep -v (case-insensitive)
    if [ -f "$DB/rules.db" ]; then
        grep -iv "$MAC" "$DB/rules.db" > "$DB/rules.db.tmp" 2>/dev/null
        mv -f "$DB/rules.db.tmp" "$DB/rules.db" 2>/dev/null
    fi
    if [ -f "$DB/block.db" ]; then
        grep -iv "$MAC" "$DB/block.db" > "$DB/block.db.tmp" 2>/dev/null
        mv -f "$DB/block.db.tmp" "$DB/block.db" 2>/dev/null
    fi
    if [ -f "$DB/pintar.db" ]; then
        grep -iv "$MAC" "$DB/pintar.db" > "$DB/pintar.db.tmp" 2>/dev/null
        mv -f "$DB/pintar.db.tmp" "$DB/pintar.db" 2>/dev/null
    fi
    echo "$MAC|$IP|$NAME" >> "$DB/block.db"
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Device diblokir"}'
    ;;

limiter_unblock)
    MAC=$(get_param "mac")
    DB="/mnt/data/limiter"

    if [ -z "$MAC" ]; then
        echo '{"success":false,"message":"MAC tidak valid"}'
        exit 0
    fi

    # Gunakan grep -v untuk hapus entry MAC (lebih reliable dari sed dengan escape)
    if [ -f "$DB/block.db" ]; then
        grep -iv "$MAC" "$DB/block.db" > "$DB/block.db.tmp" 2>/dev/null
        mv -f "$DB/block.db.tmp" "$DB/block.db" 2>/dev/null
    fi
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Device di-unblock"}'
    ;;

limiter_delete)
    MAC=$(get_param "mac")
    TYPE=$(get_param "type")
    DB="/mnt/data/limiter"

    if [ -z "$MAC" ]; then
        echo '{"success":false,"message":"MAC tidak valid"}'
        exit 0
    fi

    # Gunakan grep -v untuk hapus entry MAC (lebih reliable dari sed dengan escape)
    if [ "$TYPE" = "speed" ] || [ -z "$TYPE" ]; then
        if [ -f "$DB/rules.db" ]; then
            grep -iv "$MAC" "$DB/rules.db" > "$DB/rules.db.tmp" 2>/dev/null
            mv -f "$DB/rules.db.tmp" "$DB/rules.db" 2>/dev/null
        fi
    fi
    if [ "$TYPE" = "pintar" ] || [ -z "$TYPE" ]; then
        if [ -f "$DB/pintar.db" ]; then
            grep -iv "$MAC" "$DB/pintar.db" > "$DB/pintar.db.tmp" 2>/dev/null
            mv -f "$DB/pintar.db.tmp" "$DB/pintar.db" 2>/dev/null
        fi
    fi
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Rule dihapus"}'
    ;;

limiter_global)
    SPEED=$(get_param "speed")
    DB="/mnt/data/limiter"
    mkdir -p "$DB"

    if [ -n "$SPEED" ] && [ "$SPEED" != "0" ]; then
        echo "$SPEED" > "$DB/global.conf"
        (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
        echo "{\"success\":true,\"message\":\"Global limit: $SPEED Mbps\"}"
    else
        rm -f "$DB/global.conf"
        (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
        echo '{"success":true,"message":"Global limit dihapus"}'
    fi
    ;;

limiter_local)
    SPEED=$(get_param "speed")
    DB="/mnt/data/limiter"
    mkdir -p "$DB"

    if [ -n "$SPEED" ] && [ "$SPEED" != "0" ]; then
        echo "$SPEED" > "$DB/local.conf"
        (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
        echo "{\"success\":true,\"message\":\"Local limit: $SPEED Mbps\"}"
    else
        rm -f "$DB/local.conf"
        (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
        echo '{"success":true,"message":"Local limit dihapus"}'
    fi
    ;;

limiter_load)
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Rules diterapkan"}'
    ;;

limiter_reset)
    # Hapus semua database dan config files
    DB="/mnt/data/limiter"
    rm -f "$DB/rules.db" "$DB/block.db" "$DB/pintar.db" "$DB/global.conf" "$DB/local.conf" 2>/dev/null
    # Jalankan limiter reset untuk hapus TC rules dari sistem
    (/usr/bin/limiter reset) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Limiter direset. Semua data & settingan dihapus."}'
    ;;

limiter_off)
    # Matikan limiter tanpa hapus data - hanya hapus TC rules dari sistem
    (/usr/bin/limiter off) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Limiter dimatikan. Data tetap tersimpan."}'
    ;;

limiter_backup)
    # Backup semua database dan config files
    DB="/mnt/data/limiter"
    BACKUP_DIR="/mnt/data/limiter_backup"
    mkdir -p "$BACKUP_DIR"
    
    # Copy semua .db dan .conf files
    cp -f "$DB"/*.db "$BACKUP_DIR/" 2>/dev/null
    cp -f "$DB"/*.conf "$BACKUP_DIR/" 2>/dev/null
    
    # Hitung jumlah file yang di-backup
    FILE_COUNT=$(ls -1 "$BACKUP_DIR" 2>/dev/null | wc -l)
    
    echo "{\"success\":true,\"message\":\"Backup berhasil! $FILE_COUNT file tersimpan.\"}"
    ;;

limiter_restore)
    # Restore dari backup directory
    DB="/mnt/data/limiter"
    BACKUP_DIR="/mnt/data/limiter_backup"
    
    if [ ! -d "$BACKUP_DIR" ]; then
        echo '{"success":false,"message":"Tidak ada data backup yang ditemukan."}'
        exit 0
    fi
    
    FILE_COUNT=$(ls -1 "$BACKUP_DIR" 2>/dev/null | wc -l)
    if [ "$FILE_COUNT" -eq 0 ]; then
        echo '{"success":false,"message":"Folder backup kosong."}'
        exit 0
    fi
    
    # Restore semua files
    cp -f "$BACKUP_DIR"/*.db "$DB/" 2>/dev/null
    cp -f "$BACKUP_DIR"/*.conf "$DB/" 2>/dev/null
    
    # Reload rules setelah restore
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    
    echo "{\"success\":true,\"message\":\"Restore berhasil! $FILE_COUNT file dipulihkan. Rules di-reload.\"}"
    ;;

limiter_pintar_add)
    MAC=$(get_param "mac")
    IP=$(get_param "ip")
    NAME=$(get_param "name")
    START=$(get_param "start")
    END=$(get_param "end")
    DAYS=$(get_param "days")
    CAT=$(get_param "category")
    DB="/mnt/data/limiter"
    mkdir -p "$DB"
    [ ! -f "$DB/pintar.db" ] && touch "$DB/pintar.db"

    if [ -z "$MAC" ] || [ -z "$START" ] || [ -z "$END" ]; then
        echo '{"success":false,"message":"MAC, jam mulai, dan jam selesai wajib diisi"}'
        exit 0
    fi

    # Default: setiap hari jika kosong
    [ -z "$DAYS" ] && DAYS="Mon,Tue,Wed,Thu,Fri,Sat,Sun"
    # Default: blokir total jika kategori tidak dipilih
    [ -z "$CAT" ] && CAT="ALL"

    # Hapus entry lama dengan grep -v (case-insensitive)
    if [ -f "$DB/pintar.db" ]; then
        grep -iv "$MAC" "$DB/pintar.db" > "$DB/pintar.db.tmp" 2>/dev/null
        mv -f "$DB/pintar.db.tmp" "$DB/pintar.db" 2>/dev/null
    fi
    if [ -f "$DB/block.db" ]; then
        grep -iv "$MAC" "$DB/block.db" > "$DB/block.db.tmp" 2>/dev/null
        mv -f "$DB/block.db.tmp" "$DB/block.db" 2>/dev/null
    fi

    echo "$MAC|$IP|$NAME|$START|$END|$DAYS|$CAT" >> "$DB/pintar.db"
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Jadwal pintar ditambahkan"}'
    ;;

limiter_quota_list)
    # List semua quota + usage
    DB="/mnt/data/limiter"
    echo '{"quotas":['
    FIRST=1
    
    [ -f "$DB/quota.db" ] && while IFS='|' read -r mac ip name quota_mb action penalty expire_epoch; do
        [ -z "$mac" ] && continue
        
        # Baca usage REAL-TIME langsung dari iptables (bukan dari file)
        used_mb="0"
        mac_clean=$(echo "$mac" | tr -d ':')
        CHAIN_Q="LIMITER_Q_${mac_clean}"
        # Baca byte counter dari iptables quota rule
        used_bytes=$(iptables -L "$CHAIN_Q" -v -n -x 2>/dev/null | awk '/quota:/{print $2}')
        used_bytes=${used_bytes:-0}
        # Tambahkan base usage dari sebelum reload terakhir
        base_bytes=0
        [ -f "/tmp/quota_base_${mac_clean}" ] && base_bytes=$(cat "/tmp/quota_base_${mac_clean}" 2>/dev/null)
        base_bytes=${base_bytes:-0}
        total_bytes=$((used_bytes + base_bytes))
        # Konversi bytes ke MB
        if [ "$total_bytes" -gt 0 ] 2>/dev/null; then
            used_mb=$((total_bytes / 1048576))
        fi
        
        # Hitung remaining (kedua nilai dalam MB)
        if [ "$used_mb" -gt "$quota_mb" ] 2>/dev/null; then
            remaining_mb=0
        else
            remaining_mb=$((quota_mb - used_mb))
        fi
        [ "$remaining_mb" -lt 0 ] && remaining_mb=0
        
        # Check jika sudah expired
        now_epoch=$(date +%s)
        status="active"
        [ -n "$expire_epoch" ] && [ "$expire_epoch" != "0" ] && [ "$now_epoch" -gt "$expire_epoch" ] && status="expired"
        
        # Escape JSON: konversi quote menjadi '
        name=$(echo "$name" | tr '"' "'")
        
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"mac":"%s","ip":"%s","name":"%s","quota":%s,"used":%s,"remaining":%s,"action":"%s","penalty":"%s","status":"%s"}' "$mac" "$ip" "$name" "$quota_mb" "$used_mb" "$remaining_mb" "$action" "$penalty" "$status"
    done < "$DB/quota.db"
    
    echo ']}'
    ;;

limiter_quota_add)
    MAC=$(get_param "mac")
    IP=$(get_param "ip")
    NAME=$(get_param "name")
    QUOTA=$(get_param "quota")
    ACTION=$(get_param "quota_action")
    PENALTY=$(get_param "penalty")
    DAYS=$(get_param "days")
    
    DB="/mnt/data/limiter"
    mkdir -p "$DB"
    [ ! -f "$DB/quota.db" ] && touch "$DB/quota.db"
    [ ! -f "$DB/quota_usage.db" ] && touch "$DB/quota_usage.db"
    
    if [ -z "$MAC" ] || [ -z "$QUOTA" ]; then
        echo '{"success":false,"message":"MAC dan Quota wajib diisi"}'
        exit 0
    fi
    
    # Validasi QUOTA adalah angka
    if ! echo "$QUOTA" | grep -qE '^[0-9]+$'; then
        echo '{"success":false,"message":"Quota harus berupa angka"}'
        exit 0
    fi
    
    # Default action: BLOCK
    [ -z "$ACTION" ] && ACTION="BLOCK"
    # Default penalty speed: 128Kbps
    [ -z "$PENALTY" ] && PENALTY="128"
    # Default days: 30 hari
    [ -z "$DAYS" ] && DAYS="30"
    
    # Hitung expire epoch (NOW + DAYS * 86400)
    EXPIRE_EPOCH=$(( $(date +%s) + DAYS * 86400 ))
    
    # Hapus entry lama
    if [ -f "$DB/quota.db" ]; then
        grep -iv "$MAC" "$DB/quota.db" > "$DB/quota.db.tmp" 2>/dev/null
        mv -f "$DB/quota.db.tmp" "$DB/quota.db" 2>/dev/null
    fi
    
    # Reset usage untuk MAC ini (set ke 0)
    if [ -f "$DB/quota_usage.db" ]; then
        grep -iv "$MAC" "$DB/quota_usage.db" > "$DB/quota_usage.db.tmp" 2>/dev/null
        mv -f "$DB/quota_usage.db.tmp" "$DB/quota_usage.db" 2>/dev/null
    fi
    echo "$MAC|0" >> "$DB/quota_usage.db"
    
    # Format: MAC|IP|NAME|QUOTA_MB|ACTION|PENALTY_SPEED|EXPIRE_EPOCH
    echo "$MAC|$IP|$NAME|$QUOTA|$ACTION|$PENALTY|$EXPIRE_EPOCH" >> "$DB/quota.db"
    
    # Reset base usage di RAM agar tidak carry-over dari kuota lama
    mac_clean=$(echo "$MAC" | tr -d ':')
    rm -f "/tmp/quota_base_${mac_clean}"
    
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo "{\"success\":true,\"message\":\"Quota $QUOTA MB ditambahkan untuk $NAME\"}"
    ;;

limiter_quota_delete)
    MAC=$(get_param "mac")
    DB="/mnt/data/limiter"
    
    if [ -z "$MAC" ]; then
        echo '{"success":false,"message":"MAC tidak valid"}'
        exit 0
    fi
    
    # Hapus dari quota.db dan quota_usage.db
    if [ -f "$DB/quota.db" ]; then
        grep -iv "$MAC" "$DB/quota.db" > "$DB/quota.db.tmp" 2>/dev/null
        mv -f "$DB/quota.db.tmp" "$DB/quota.db" 2>/dev/null
    fi
    if [ -f "$DB/quota_usage.db" ]; then
        grep -iv "$MAC" "$DB/quota_usage.db" > "$DB/quota_usage.db.tmp" 2>/dev/null
        mv -f "$DB/quota_usage.db.tmp" "$DB/quota_usage.db" 2>/dev/null
    fi
    
    # Bersihkan base usage di RAM
    mac_clean=$(echo "$MAC" | tr -d ':')
    rm -f "/tmp/quota_base_${mac_clean}"
    
    (/usr/bin/limiter load) < /dev/null > /dev/null 2>&1 &
    echo '{"success":true,"message":"Quota dihapus"}'
    ;;

limiter_quota_reset)
    # Reset semua quota usage ke 0 (maintenance command)
    DB="/mnt/data/limiter"
    
    # Backup old file
    [ -f "$DB/quota_usage.db" ] && cp -f "$DB/quota_usage.db" "$DB/quota_usage.db.bak"
    
    # Recreate dengan nilai 0 untuk setiap MAC di quota.db
    touch "$DB/quota_usage.db.new"
    [ -f "$DB/quota.db" ] && while IFS='|' read -r mac ip name quota_mb action penalty expire_epoch; do
        [ -z "$mac" ] && continue
        echo "$mac|0" >> "$DB/quota_usage.db.new"
    done < "$DB/quota.db"
    
    mv -f "$DB/quota_usage.db.new" "$DB/quota_usage.db"
    echo '{"success":true,"message":"Quota usage di-reset ke 0 untuk semua device"}'
    ;;

limiter_monitor)
    # Live Traffic Monitor - V2 Optimized
    CACHE_FILE="/tmp/limiter_monitor_cache_v2"
    NOW=$(date +%s)
    
    # Ambil semua data iptables sekaligus agar tidak heavy di loop
    # Gunakan format raw -c iptables-save untuk parser bytes paling akurat
    # Kita menggunakan LIMITER_ACC yang dihitung langsung sebelum CONNMARK memotong chain
    IPT_DATA=$(iptables-save -c -t mangle | grep " -A LIMITER_ACC " 2>/dev/null)

    echo '{"timestamp":'$NOW',"traffic":['
    FIRST=1

    # Scan ARP untuk ambil devices yang active
    LAN_IF="br0"
    awk -v iface="$LAN_IF" '$6==iface && $4!="00:00:00:00:00:00" && $3=="0x2" {print $1,$4}' /proc/net/arp | while read ip mac; do
        [ -z "$ip" ] || [ -z "$mac" ] && continue

        # Get hostname
        hname=""
        for lf in /tmp/dhcp.leases /tmp/dnsmasq.leases /var/lib/misc/dnsmasq.leases; do
            [ -f "$lf" ] && hname=$(grep -i "$mac" "$lf" 2>/dev/null | awk '{print $4}' | head -n 1)
            [ -n "$hname" ] && [ "$hname" != "*" ] && break
        done
        [ -z "$hname" ] || [ "$hname" = "*" ] && hname="Unknown"

        # Parse Up/Down bytes format [pkts:bytes] dari iptables-save
        # Gunakan awk split() di kolom pertama agar posisi kolom -m mac tidak merusak parsing
        MAC_L="$(echo "$mac" | tr '[A-Z]' '[a-z]')"

        # Auto-inject iptables untuk perangkat Global Rule yang baru konek setelah script berjalan
        if ! echo "$IPT_DATA" | grep -q "\-s $ip/32" 2>/dev/null; then
            iptables -t mangle -A LIMITER_ACC -m mac --mac-source "$MAC_L" -j RETURN 2>/dev/null
            iptables -t mangle -A LIMITER_ACC -s "$ip" -j RETURN 2>/dev/null
            iptables -t mangle -A LIMITER_ACC -d "$ip" -j RETURN 2>/dev/null
            # Setup nilai 0 untuk siklus detik awal ini saja
            bytes_up=0
            bytes_down=0
        else
            bytes_up=$(echo "$IPT_DATA" | awk -v ip="$ip" -v mac="$MAC_L" '
                {
                    if(tolower($0) ~ "-s " ip "/32" || tolower($0) ~ "-s " ip " " || tolower($0) ~ "--mac-source " mac " ") {
                        # Format kolom 1 adalah [pkts:bytes]
                        split($1, arr, "[:]");
                        sum += arr[2];
                    }
                }
                END { print sum+0 }
            ')
            bytes_down=$(echo "$IPT_DATA" | awk -v ip="$ip" '
                {
                    if(tolower($0) ~ "-d " ip "/32" || tolower($0) ~ "-d " ip " ") {
                        # Format kolom 1 adalah [pkts:bytes]
                        split($1, arr, "[:]");
                        sum += arr[2];
                    }
                }
                END { print sum+0 }
            ')
        fi
        # Read cache untuk delta per-arah
        p_up=0; p_down=0; p_time=$NOW
        if [ -f "$CACHE_FILE" ]; then
            line=$(grep "^${ip}|" "$CACHE_FILE" 2>/dev/null | tail -n 1)
            if [ -n "$line" ]; then
                p_up=$(echo "$line" | cut -d'|' -f2)
                p_down=$(echo "$line" | cut -d'|' -f3)
                p_time=$(echo "$line" | cut -d'|' -f4)
            fi
        fi
        
        # Hitung speed (delta bytes per second)
        dt=$((NOW - p_time))
        [ "$dt" -lt 1 ] && dt=1
        
        du=$((bytes_up - p_up)); [ "$du" -lt 0 ] && du=0
        dd=$((bytes_down - p_down)); [ "$dd" -lt 0 ] && dd=0
        
        sp_up=$((du * 8 / dt / 1024))
        sp_down=$((dd * 8 / dt / 1024))
        
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '{"ip":"%s","mac":"%s","name":"%s","up_kbps":%s,"down_kbps":%s,"total_up":%s,"total_down":%s}' \
               "$ip" "$mac" "$hname" "$sp_up" "$sp_down" "$bytes_up" "$bytes_down"
        
        # Save to new cache
        echo "$ip|$bytes_up|$bytes_down|$NOW" >> "${CACHE_FILE}.new"
    done
    
    mv -f "${CACHE_FILE}.new" "$CACHE_FILE" 2>/dev/null
    echo ']}'
    ;;

limiter_kategori_list)
    # List semua file kategori yang tersedia
    KATEGORI_DIR="/mnt/data/limiter/kategori"
    mkdir -p "$KATEGORI_DIR" 2>/dev/null
    
    echo '{"categories":['
    FIRST=1
    for f in "$KATEGORI_DIR"/*; do
        [ -e "$f" ] || continue
        fname=$(basename "$f")
        [ "$FIRST" = "1" ] && FIRST=0 || printf ','
        printf '"%s"' "$fname"
    done
    echo ']}'
    ;;

get_manifest)
    # Baca manifest file untuk uninstaller - hanya bagian FILES
    MANIFEST_FILE="/mnt/data/imba_mod_manifest.txt"
    if [ -f "$MANIFEST_FILE" ]; then
        # Extract hanya bagian [FILES]
        sed -n '/^\[FILES\]/,$ p' "$MANIFEST_FILE" | grep -v '^\[FILES\]' | grep -v '^$'
    else
        echo "# No manifest file found"
    fi
    ;;

get_security_question)
    # Ambil pertanyaan keamanan dari manifest
    MANIFEST_FILE="/mnt/data/imba_mod_manifest.txt"
    if [ -f "$MANIFEST_FILE" ]; then
        QUESTION=$(grep "^QUESTION=" "$MANIFEST_FILE" | cut -d'=' -f2- 2>/dev/null)
        echo "{\"question\":\"$QUESTION\"}"
    else
        echo "{\"question\":\"Siapa Bapak Republik?\"}"
    fi
    ;;

verify_security)
    # Verifikasi jawaban keamanan dari manifest
    # PENTING: Jangan gunakan 'read' lagi karena POST_DATA sudah dibaca di awal file
    if [ "$REQUEST_METHOD" = "POST" ]; then
        ANSWER=$(echo "$POST_DATA" | sed 's/.*answer=//; s/&.*//' | sed 's/%20/ /g; s/%2B/+/g; s/+/ /g')
        ANSWER=$(echo "$ANSWER" | tr '[:upper:]' '[:lower:]' | sed 's/^[ \t]*//;s/[ \t]*$//')
        
        # Baca jawaban benar dari manifest (Case Insensitive & Trim Whitespace)
        MANIFEST_FILE="/mnt/data/imba_mod_manifest.txt"
        if [ -f "$MANIFEST_FILE" ]; then
            CORRECT_ANSWER=$(grep "^ANSWER=" "$MANIFEST_FILE" | cut -d'=' -f2- | tr '[:upper:]' '[:lower:]' | sed 's/^[ \t]*//;s/[ \t]*$//')
        else
            CORRECT_ANSWER="tan malaka"
        fi
        
        # Validasi: Bandingkan ANSWER (dari input) dengan CORRECT_ANSWER (dari manifest)
        if [ "$ANSWER" = "$CORRECT_ANSWER" ] && [ -n "$ANSWER" ]; then
            echo '{"status":"success","message":"Security answer correct"}'
        else
            echo '{"status":"error","message":"Security answer incorrect (Check manifest answer)"}'
        fi
    else
        echo '{"status":"error","message":"Method not allowed"}'
    fi
    ;;

execute_uninstall)
    # Eksekusi script uninstaller - OPTIMIZED VERSION
    if [ "$REQUEST_METHOD" = "POST" ]; then
        if [ -x "/usr/bin/uninstall-mod" ]; then
            # Hapus log lama agar tidak terbaca hasil sebelumnya
            rm -f /tmp/uninstall.log 2>/dev/null
            
            # SARAN OPSI 3: Kirim respons sukses DULU ke browser
            # agar WebUI tidak menganggap request timeout/failed
            echo '{"status":"success","message":"Pencopotan IMBA Mod telah dimulai. Perangkat akan segera restart otomatis."}'
            
            # Baru kemudian jalankan uninstaller di background
            # Kita arahkan output ke /tmp/uninstall.log agar bisa dipantau jika perlu
            (/usr/bin/uninstall-mod > /tmp/uninstall.log 2>&1) &
        else
            echo '{"status":"error","message":"Script uninstaller tidak ditemukan di sistem!"}'
        fi
    else
        echo '{"status":"error","message":"Method not allowed"}'
    fi
    ;;

limiter_autostart)
    ACT=$(get_param "act")
    if [ "$ACT" = "on" ] || [ "$ACT" = "off" ]; then
        (/usr/bin/limiter autostart "$ACT") < /dev/null > /dev/null 2>&1 &
        echo "{\"success\":true,\"message\":\"Autostart: $ACT\"}"
    else
        AS="off"; [ -f /etc/init.d/S99limiter ] && AS="on"
        echo "{\"autostart\":\"$AS\"}"
    fi
    ;;

sms_monitoring_get)
    # Get SMS monitoring config
    CONFIG_FILE="/mnt/data/sms-laporan.json"
    if [ -f "$CONFIG_FILE" ]; then
        CONFIG_JSON=$(cat "$CONFIG_FILE" 2>/dev/null)

        # Sinkronisasi state UI vs runtime service:
        # Jika autostart OFF dan proses autosms tidak berjalan,
        # paksa toggle runtime menjadi OFF agar UI tidak misleading setelah reboot.
        AUTOSTART_STATUS=$(printf "%s" "$CONFIG_JSON" | grep -o '"autostart":[^,}]*' | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
        AUTOSTART_MONITORING_STATUS=$(printf "%s" "$CONFIG_JSON" | grep -o '"autostart_monitoring":[^,}]*' | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
        AUTOSTART_SMS_COMMAND_STATUS=$(printf "%s" "$CONFIG_JSON" | grep -o '"autostart_sms_command":[^,}]*' | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
        ENABLED_STATUS=$(printf "%s" "$CONFIG_JSON" | grep -o '"enabled":[^,}]*' | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')

        [ -z "$AUTOSTART_STATUS" ] && AUTOSTART_STATUS="false"
        [ -z "$AUTOSTART_MONITORING_STATUS" ] && AUTOSTART_MONITORING_STATUS="$AUTOSTART_STATUS"
        [ -z "$AUTOSTART_SMS_COMMAND_STATUS" ] && AUTOSTART_SMS_COMMAND_STATUS="$AUTOSTART_STATUS"

        RUNNING_STATUS="false"
        APID=""
        [ -f /tmp/autosms.pid ] && APID=$(cat /tmp/autosms.pid 2>/dev/null)
        if [ -n "$APID" ] && kill -0 "$APID" 2>/dev/null; then
            RUNNING_STATUS="true"
        elif ps | grep -q "[a]utosms.sh"; then
            RUNNING_STATUS="true"
        fi

        if [ "$RUNNING_STATUS" != "true" ]; then
            if [ "$AUTOSTART_MONITORING_STATUS" != "true" ]; then
                CONFIG_JSON=$(printf "%s" "$CONFIG_JSON" | sed 's/"enabled":true/"enabled":false/g; s/"enabled":"true"/"enabled":false/g')
            fi
            if [ "$AUTOSTART_SMS_COMMAND_STATUS" != "true" ]; then
                CONFIG_JSON=$(printf "%s" "$CONFIG_JSON" | sed 's/"sms_command_enabled":true/"sms_command_enabled":false/g; s/"sms_command_enabled":"true"/"sms_command_enabled":false/g')
            fi
            printf "%s" "$CONFIG_JSON" > "$CONFIG_FILE" 2>/dev/null
            sync
        fi

        echo "{\"status\":\"success\",\"config\":$CONFIG_JSON}"
    else
        echo "{\"status\":\"success\",\"config\":{\"enabled\":false,\"autostart\":false,\"autostart_monitoring\":false,\"autostart_sms_command\":false,\"sms_command_enabled\":false,\"ping_target\":\"8.8.8.8\",\"ping_interval\":30,\"timeout_threshold\":300,\"sms_number\":\"\",\"sms_message\":\"ALERT: Network down selama %duration%\"}}"
    fi
    ;;

sms_monitoring_save)
    # Save SMS monitoring config - BULLETPROOF VERSION
    if [ "$REQUEST_METHOD" = "POST" ]; then
        # Create debug file dengan info basic
        echo "=== SAVE CONFIG DEBUG $(date) ===" > /tmp/sms_save.log
        echo "REQUEST_METHOD: $REQUEST_METHOD" >> /tmp/sms_save.log
        echo "CONTENT_LENGTH: $CONTENT_LENGTH" >> /tmp/sms_save.log
        
        mkdir -p /mnt/data 2>/dev/null
        
        # Extract config parameter safely with awk
        CONFIG_FINAL=$(printf "%s" "$POST_DATA" | awk -F'config=' '{print $2}' | awk -F'&' '{print $1}' | awk '
        BEGIN {
            for(i=0;i<10;i++) hex[i""]=i;
            hex["A"]=10; hex["B"]=11; hex["C"]=12; hex["D"]=13; hex["E"]=14; hex["F"]=15;
            hex["a"]=10; hex["b"]=11; hex["c"]=12; hex["d"]=13; hex["e"]=14; hex["f"]=15;
        }
        {
            gsub(/\+/," ");
            res="";
            for(i=1;i<=length($0);i++) {
                c = substr($0,i,1);
                if(c == "%" && i+2 <= length($0)) {
                    h1 = substr($0,i+1,1); h2 = substr($0,i+2,1);
                    if((h1 in hex) && (h2 in hex)) {
                        res = res sprintf("%c", hex[h1]*16 + hex[h2]);
                        i+=2;
                        continue;
                    }
                }
                res = res c;
            }
            print res;
        }')
        
        # Validate JSON structure basic (must contain { and })
        if printf "%s" "$CONFIG_FINAL" | grep -q '{' && printf "%s" "$CONFIG_FINAL" | grep -q '}'; then
            # Write to file directly
            printf "%s" "$CONFIG_FINAL" > /mnt/data/sms-laporan.json 2>/dev/null
            
            # Verify file was written
            if [ -f /mnt/data/sms-laporan.json ] && [ -s /mnt/data/sms-laporan.json ]; then
                # Control autosms.sh safely via PID file
                ENABLED_STATUS=$(grep -o '"enabled":[^,}]*' /mnt/data/sms-laporan.json | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
                SMS_COMMAND_STATUS=$(grep -o '"sms_command_enabled":[^,}]*' /mnt/data/sms-laporan.json | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
                AUTOSTART_STATUS=$(grep -o '"autostart":[^,}]*' /mnt/data/sms-laporan.json | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
                AUTOSTART_MONITORING_STATUS=$(grep -o '"autostart_monitoring":[^,}]*' /mnt/data/sms-laporan.json | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')
                AUTOSTART_SMS_COMMAND_STATUS=$(grep -o '"autostart_sms_command":[^,}]*' /mnt/data/sms-laporan.json | awk -F':' '{print $2}' | tr -d ' "' | tr '[:upper:]' '[:lower:]')

                [ -z "$SMS_COMMAND_STATUS" ] && SMS_COMMAND_STATUS="$ENABLED_STATUS"
                [ -z "$AUTOSTART_STATUS" ] && AUTOSTART_STATUS="false"
                [ -z "$AUTOSTART_MONITORING_STATUS" ] && AUTOSTART_MONITORING_STATUS="$AUTOSTART_STATUS"
                [ -z "$AUTOSTART_SMS_COMMAND_STATUS" ] && AUTOSTART_SMS_COMMAND_STATUS="$AUTOSTART_STATUS"

                AUTOSTART_ANY="false"
                if [ "$AUTOSTART_MONITORING_STATUS" = "true" ] || [ "$AUTOSTART_SMS_COMMAND_STATUS" = "true" ]; then
                    AUTOSTART_ANY="true"
                fi

                # Sinkronkan autostart ke S99imba_mod (tanpa membuat init script terpisah)
                if [ -f /etc/init.d/S99imba_mod ] && grep -q "AUTOSMS_AUTOSTART_BEGIN" /etc/init.d/S99imba_mod && grep -q "AUTOSMS_AUTOSTART_END" /etc/init.d/S99imba_mod; then
                    # Rootfs sering dalam mode RO, jadi buka kunci sementara saat edit init.
                    mount -o remount,rw / 2>/dev/null
                    if [ "$AUTOSTART_ANY" = "true" ]; then
                        awk '
                        /# AUTOSMS_AUTOSTART_BEGIN/ {
                            print;
                            print "    AUTOSMS_S99_LOCK=\"/tmp/autosms_s99_start.lockdir\"";
                            print "    if mkdir \"$AUTOSMS_S99_LOCK\" 2>/dev/null; then";
                            print "        if [ ! -f /tmp/autosms.pid ] && ! ps | grep -q \"[a]utosms.sh\"; then";
                            print "            /bin/sh /usr/bin/autosms.sh --boot >/tmp/autosms_boot.log 2>&1 &";
                            print "        fi";
                            print "    fi";
                            print "";
                            print "    (";
                            print "        sleep 45";
                            print "        if [ -d /tmp/autosms_s99_start.lockdir ] && [ ! -d /tmp/autosms_boot.lockdir ] && [ ! -f /tmp/autosms.pid ] && ! ps | grep -q \"[a]utosms.sh\"; then";
                            print "            /bin/sh /usr/bin/autosms.sh --boot >/tmp/autosms_boot_retry.log 2>&1 &";
                            print "        fi";
                            print "        rmdir /tmp/autosms_s99_start.lockdir 2>/dev/null";
                            print "    ) &";
                            skip=1;
                            next;
                        }
                        /# AUTOSMS_AUTOSTART_END/ {
                            skip=0;
                            print;
                            next;
                        }
                        !skip { print }
                        ' /etc/init.d/S99imba_mod > /tmp/S99imba_mod.tmp 2>/dev/null && mv /tmp/S99imba_mod.tmp /etc/init.d/S99imba_mod 2>/dev/null
                    else
                        awk '
                        /# AUTOSMS_AUTOSTART_BEGIN/ {
                            print;
                            skip=1;
                            next;
                        }
                        /# AUTOSMS_AUTOSTART_END/ {
                            skip=0;
                            print;
                            next;
                        }
                        !skip { print }
                        ' /etc/init.d/S99imba_mod > /tmp/S99imba_mod.tmp 2>/dev/null && mv /tmp/S99imba_mod.tmp /etc/init.d/S99imba_mod 2>/dev/null
                    fi
                    chmod +x /etc/init.d/S99imba_mod 2>/dev/null
                    sync
                    mount -o remount,ro / 2>/dev/null
                fi
                
                # Matikan instance lama via PID file (termasuk child processes)
                APID=""
                [ -f /tmp/autosms.pid ] && APID=$(cat /tmp/autosms.pid 2>/dev/null)
                if [ -n "$APID" ] && kill -0 "$APID" 2>/dev/null; then
                    kill -- -"$APID" 2>/dev/null
                    kill "$APID" 2>/dev/null
                    sleep 1
                    kill -9 "$APID" 2>/dev/null
                fi
                rm -f /tmp/autosms.pid
                
                # Fallback: grep bunuh sisa proses orphan yang lolos
                PIDS=$(ps | grep "[a]utosms.sh" | awk '{print $1}')
                for P in $PIDS; do kill -9 "$P" 2>/dev/null; done

                if [ "$ENABLED_STATUS" = "true" ] || [ "$SMS_COMMAND_STATUS" = "true" ]; then
                    /bin/sh /usr/bin/autosms.sh >/dev/null 2>&1 &
                fi

                # Return clean JSON single line
                printf '{"status":"success","message":"Configuration saved successfully"}\n'
            else
                printf '{"status":"error","message":"Failed to write config file"}\n'
            fi
        else
            printf '{"status":"error","message":"Invalid JSON format received or missing config param"}\n'
        fi
    else
        printf '{"status":"error","message":"Invalid request method"}\n'
    fi
    ;;

sms_monitoring_test)
    # Test SMS functionality - BULLETPROOF VERSION
    if [ "$REQUEST_METHOD" = "POST" ]; then
        # DON'T READ AGAIN! POST_DATA already combined
        
        # Create debug file
        echo "=== SMS TEST DEBUG $(date) ===" > /tmp/sms_test.log
        echo "POST_DATA: [$POST_DATA]" >> /tmp/sms_test.log
        
        # Extract number parameter
        if printf "%s" "$POST_DATA" | grep -q "number="; then
            NUMBER_RAW=$(printf "%s" "$POST_DATA" | awk -F'number=' '{print $2}' | awk -F'&' '{print $1}')
            NUMBER_DECODED=$(printf "%s" "$NUMBER_RAW" | awk -F'&' '{print $1}' | awk '
            BEGIN {
                for(i=0;i<10;i++) hex[i""]=i;
                hex["A"]=10; hex["B"]=11; hex["C"]=12; hex["D"]=13; hex["E"]=14; hex["F"]=15;
                hex["a"]=10; hex["b"]=11; hex["c"]=12; hex["d"]=13; hex["e"]=14; hex["f"]=15;
            }
            {
                gsub(/\+/," ");
                res="";
                for(i=1;i<=length($0);i++) {
                    c = substr($0,i,1);
                    if(c == "%" && i+2 <= length($0)) {
                        h1 = substr($0,i+1,1); h2 = substr($0,i+2,1);
                        if((h1 in hex) && (h2 in hex)) {
                            res = res sprintf("%c", hex[h1]*16 + hex[h2]);
                            i+=2;
                            continue;
                        }
                    }
                    res = res c;
                }
                print res;
            }' | sed 's/^[ \t]*//; s/[ \t]*$//')
            
            echo "NUMBER_RAW: [$NUMBER_RAW]" >> /tmp/sms_test.log
            echo "NUMBER_DECODED: [$NUMBER_DECODED]" >> /tmp/sms_test.log
            
            if [ ! -z "$NUMBER_DECODED" ]; then
                # Try to send SMS NON-INTERACTIVE
                TEST_MESSAGE="Test SMS IMBA Mod $(date +%H:%M:%S)"
                echo "SENDING_TO: $NUMBER_DECODED" >> /tmp/sms_test.log
                echo "MESSAGE: $TEST_MESSAGE" >> /tmp/sms_test.log
                
                # Execute SMS command dengan better isolation
                TEST_MESSAGE="Test SMS IMBA Mod $(date +%H:%M:%S)"
                echo "SENDING_TO: $NUMBER_DECODED" >> /tmp/sms_test.log
                echo "MESSAGE: $TEST_MESSAGE" >> /tmp/sms_test.log
                
                # Clean any pending AT commands first
                sleep 1
                
                # Execute SMS with fallback methods
                # Method 1: Try modem SMS first
                SMS_RESULT=$(
                    echo "#!/bin/sh" > /tmp/sms_send.sh
                    echo "echo \"$TEST_MESSAGE\" | /usr/bin/sms-tool send \"$NUMBER_DECODED\" 2>&1" >> /tmp/sms_send.sh
                    chmod +x /tmp/sms_send.sh
                    /tmp/sms_send.sh
                    rm -f /tmp/sms_send.sh
                )
                SMS_EXIT_CODE=$?
                
                # Method 2: HTTP SMS fallback (if configured)
                if [ -f "/mnt/data/http-sms.conf" ]; then
                    echo "Trying HTTP SMS fallback..." >> /tmp/sms_test.log
                    HTTP_TOKEN=$(grep "token=" /mnt/data/http-sms.conf | cut -d'=' -f2)
                    HTTP_URL=$(grep "url=" /mnt/data/http-sms.conf | cut -d'=' -f2)
                    if [ -n "$HTTP_TOKEN" ] && [ -n "$HTTP_URL" ]; then
                        HTTP_RESULT=$(wget -q -O- --header="Authorization: $HTTP_TOKEN" \
                            --post-data="target=$NUMBER_DECODED&message=$TEST_MESSAGE" \
                            "$HTTP_URL" 2>&1)
                        echo "HTTP_SMS_RESULT: [$HTTP_RESULT]" >> /tmp/sms_test.log
                    fi
                fi
                
                # Extra debugging untuk SMS delivery
                echo "SMS_RESULT: [$SMS_RESULT]" >> /tmp/sms_test.log
                echo "SMS_EXIT_CODE: $SMS_EXIT_CODE" >> /tmp/sms_test.log
                echo "SMS_ISOLATED_COMMAND: Used temporary script for clean execution" >> /tmp/sms_test.log
                
                # Check SMS queue/status untuk debugging
                sleep 1  # Wait for SMS processing
                SMS_STATUS=$(/usr/bin/sms-tool status 2>/dev/null || echo "No status command")
                echo "SMS_MODEM_STATUS: $SMS_STATUS" >> /tmp/sms_test.log
                
                if [ $SMS_EXIT_CODE -eq 0 ] || echo "$SMS_RESULT" | grep -q -i "sent\|ok\|success\|terkirim"; then
                    printf '{"status":"success","message":"SMS sent successfully (check phone for clean delivery)"}\n'
                else
                    # Get first line only (BusyBox compatible)
                    SMS_ERROR=$(echo "$SMS_RESULT" | sed -n '1p')
                    printf '{"status":"error","message":"SMS failed: %s"}\n' "$SMS_ERROR"
                fi
            else
                echo "EMPTY_NUMBER" >> /tmp/sms_test.log
                printf '{"status":"error","message":"SMS number is empty after decoding"}\n'
            fi
        else
            echo "NO_NUMBER_PARAM" >> /tmp/sms_test.log
            printf '{"status":"error","message":"No number parameter found"}\n'
        fi
    else
        printf '{"status":"error","message":"Invalid request method"}\n'
    fi
    ;;

set_theme)
    THEME=$(get_param "theme")
    if [ -z "$THEME" ]; then
        echo '{"success":false,"message":"Theme tidak dipilih"}'
        exit 0
    fi
    mdlcfg -a SYS_USER_WEB_THEME="$THEME" 2>/dev/null
    mdlcfg -c 2>/dev/null
    
    # Save to NVRAM persistent storage (Anti-Reset Mechanism)
    echo "$THEME" > /mnt/data/theme.conf

    # Ganti logo sesuai tema (Disk Swapping) - METODE PALING PASTI
    LOGO_DIR="/tzwww/images"
    LOGO_ACTIVE="$LOGO_DIR/logo_ID0237.png"
    LOGO_BACKUP_DIR="/mnt/data/backup_original_firmware/tzwww/images"
    case "$THEME" in
        main.Indonesia.css)
            # Restore logo original — prioritas: backup baru > backup lama
            if [ -f "$LOGO_BACKUP_DIR/logo_ID0237.png" ]; then
                LOGO_SRC="$LOGO_BACKUP_DIR/logo_ID0237.png"
            elif [ -f "${LOGO_ACTIVE}.bckp" ]; then
                LOGO_SRC="${LOGO_ACTIVE}.bckp"
            else
                LOGO_SRC=""
            fi
            ;;
        main.dark_orange.css) LOGO_SRC="$LOGO_DIR/logo_ID0237-orange.png" ;;
        main.dark_lime.css) LOGO_SRC="$LOGO_DIR/logo_ID0237-lime.png" ;;
        *) LOGO_SRC="" ;;
    esac
    
    if [ -n "$LOGO_SRC" ] && [ -f "$LOGO_SRC" ]; then
        mount -o remount,rw / 2>/dev/null
        # Backup logo asli ke /mnt/data/ SEBELUM ditimpa (hanya sekali, saat pertama kali)
        if [ ! -f "$LOGO_BACKUP_DIR/logo_ID0237.png" ]; then
            mkdir -p "$LOGO_BACKUP_DIR" 2>/dev/null
            cp -p "$LOGO_ACTIVE" "$LOGO_BACKUP_DIR/logo_ID0237.png" 2>/dev/null
        fi
        cp -pf "$LOGO_SRC" "$LOGO_ACTIVE"
        sync
        mount -o remount,ro / 2>/dev/null
    fi

    echo '{"success":true,"message":"Tema diterapkan"}'
    ;;

led_control)
    # Target: wifi, data, sig, all
    # State: on, off, restore
    TARGET=$(echo "$QUERY_STRING" | grep -oE "target=[^&]+" | cut -d= -f2)
    OP=$(echo "$QUERY_STRING" | grep -oE "state=[^&]+" | cut -d= -f2)
    
    # Memeriksa POST data jika tidak ada di QUERY_STRING (fallback)
    [ -z "$TARGET" ] && TARGET=$(echo "$POST_DATA" | grep -oE "target=[^&]+" | cut -d= -f2)
    [ -z "$OP" ] && OP=$(echo "$POST_DATA" | grep -oE "state=[^&]+" | cut -d= -f2)
    
    if [ "$OP" = "restore" ]; then
        /usr/bin/led-tool restore > /dev/null 2>&1
        echo "{\"success\":true,\"message\":\"LED dikembalikan ke setelan otomatis pabrik.\"}"
    else
        # Validasi target dan op untuk keamanan murni
        case "$TARGET" in
            wifi|data|sig|all)
                if [ "$OP" = "on" ] || [ "$OP" = "off" ]; then
                    /usr/bin/led-tool "$TARGET" "$OP" > /dev/null 2>&1
                    echo "{\"success\":true,\"message\":\"Berhasil mengatur $TARGET ke $OP.\"}"
                else
                    echo "{\"success\":false,\"message\":\"Operasi tidak valid\"}"
                fi
                ;;
            *)
                echo "{\"success\":false,\"message\":\"Target tidak valid\"}"
                ;;
        esac
    fi
    ;;

sysinfo)
    # 1. TEMPERATUR
    temp="--"
    zone_path="/sys/devices/virtual/thermal/thermal_zone0/temp"
    if [ -f "$zone_path" ]; then
        t=$(cat "$zone_path" 2>/dev/null | tr -d ' \n\r')
        if [ -n "$t" ] && echo "$t" | grep -q '^[0-9][0-9]*$'; then
            if [ "$t" -ge 1000 ]; then temp=$((t / 1000))
            else temp=$t; fi
        fi
    fi

    # Fallback ke zone lain jika file di atas hilang/berubah
    if [ "$temp" = "--" ]; then
        for zone in /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp1_input; do
            if [ -f "$zone" ]; then
                t=$(cat "$zone" 2>/dev/null | tr -d ' \n\r')
                if [ -n "$t" ] && echo "$t" | grep -q '^[0-9][0-9]*$'; then
                    if [ "$t" -ge 1000 ]; then temp=$((t / 1000))
                    else temp=$t; fi
                    break
                fi
            fi
        done
    fi

    # 2. CPU LOAD (Pure Shell - BusyBox Safe)
    cpu_usage="0"
    if [ -r /proc/stat ]; then
        read -r line < /proc/stat
        set -- $line
        # $1=cpu $2=user $3=nice $4=system $5=idle $6=iowait $7=irq $8=softirq $9=steal
        # Guard: default ke 0 jika field tidak ada (kernel lama tanpa steal/guest)
        _user=${2:-0}; _nice=${3:-0}; _sys=${4:-0}; _idle=${5:-0}
        _iow=${6:-0}; _irq=${7:-0}; _sirq=${8:-0}; _steal=${9:-0}

        ctotal=$(( _user + _nice + _sys + _idle + _iow + _irq + _sirq + _steal ))
        cidle=$(( _idle + _iow ))

        CACHE_FILE="/tmp/sysinfo_cpu_cache"
        ptotal=$ctotal
        pidle=$cidle
        if [ -f "$CACHE_FILE" ]; then
            read -r _pt _pi < "$CACHE_FILE"
            # Validasi: pastikan keduanya numerik sebelum pakai
            case "$_pt$_pi" in
                *[!0-9]*) ;; # Ada karakter non-numerik, abaikan cache
                *) [ -n "$_pt" ] && [ -n "$_pi" ] && ptotal=$_pt && pidle=$_pi ;;
            esac
        fi

        printf "%s %s" "$ctotal" "$cidle" > "$CACHE_FILE"

        dtotal=$((ctotal - ptotal))
        didle=$((cidle - pidle))

        if [ "$dtotal" -gt 0 ]; then
            cpu_usage=$(( (dtotal - didle) * 100 / dtotal ))
            # Clamp 0-100 (counter wrap atau overflow protection)
            [ "$cpu_usage" -lt 0 ] && cpu_usage=0
            [ "$cpu_usage" -gt 100 ] && cpu_usage=100
        fi
    fi

    printf '{"cpu":"%s","temp":"%s"}\n' "$cpu_usage" "$temp"
    ;;

*)
    echo "{\"success\":false,\"msg\":\"Unknown action\"}"
    ;;
esac

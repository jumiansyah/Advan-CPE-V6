#!/bin/sh
flag=0
while [ ! -e /tmp/.flag_cfgd_init_finished ]
do
    	echo "mdlcfg initializing...."
	flag=$(($flag+1))
	if [ "-$flag" = "-10" ]; then
		if [ ! -s /mnt/data/etc/tzcfg/system_config.use ]; then
			rm /mnt/data/etc/tzcfg/system_config.use
			reboot
		fi
        	echo "mdlcfg initializing fail...."
		exit 0
	fi 
    	sleep 1
done

exit 0

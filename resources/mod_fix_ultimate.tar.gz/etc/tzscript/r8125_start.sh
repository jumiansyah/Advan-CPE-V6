#!/bin/sh

#################################
#Auth: bjj
#Date: 2020.7.16
#
#func: this script need run when device starting.
#If we need run it after br0 created, we should rebuild br0, do "brctl addif br0 eth0" and "ifconfig eth0 up"
################################

TEE_PRO="busybox tee -ai"
ECHO_PRO="echo"
MKDIR_PRO="mkdir"
CHMOD_PRO="chmod"
TOUCH_PRO="touch"
IFCONFIG_PRO="busybox ifconfig"
BRCTL_PRO="brctl"
PS_PRO="ps"
COPY_PRO="cp"
PARA_ALL=$*
DATA_PATH=/mnt/data
DATA_LOCAL_PATH=$DATA_PATH/local
DATA_VAR_PATH=$DATA_PATH/var
DATA_VAR_CONF_PATH=$DATA_VAR_PATH/conf
DATA_VAR_RUN_PATH=$DATA_VAR_PATH/run
LOG_PATH=$DATA_LOCAL_PATH/log
LOG_FILE=$LOG_PATH/r8125.log

EFUSE_FL=$LOG_PATH/r8125_efuse
EFUSE_FL2=$LOG_PATH/r8125_efuse_2

R8125CFG_FL=8125BEF.cfg

rm $LOG_FILE
$ECHO_PRO "Enter r8125_start.sh" | $TEE_PRO $LOG_FILE

check_r8125_efuse()
{
	$ECHO_PRO "Start to rm r8125 gpdrv" | $TEE_PRO $LOG_FILE
	#need rm r8125, there is some conflicts in loading pgdrv when r8125 is loaded
	rmmod r8125
	rmmod pgdrv

	$ECHO_PRO "Insmod pgdrv.ko" | $TEE_PRO $LOG_FILE
	insmod /lib/pgdrv/pgdrv.ko

	#read efuse of r8125, if efuse datas are all 0xFF, need to write configs
	pgtool /efuse /r > $EFUSE_FL

	LINE=`sed -n "/Start to Dump and Parse EFuse Content/=" $EFUSE_FL`
	let LINE++
	EFUSE_DATA_FIRST=`sed -n "$LINE"p $EFUSE_FL`

	$ECHO_PRO "getdata=$EFUSE_DATA_FIRST" | $TEE_PRO $LOG_FILE

	RET=$(echo $EFUSE_DATA_FIRST | grep "FF FF FF FF")

	if [[ "$RET" != "" ]]; then
		$ECHO_PRO "Need Write Efuse!!" | $TEE_PRO $LOG_FILE
		if [ ! -d $DATA_VAR_CONF_PATH/$R8125CFG_FL ]; then
			cp /bin/$R8125CFG_FL $DATA_VAR_CONF_PATH/$R8125CFG_FL
		fi
		cd $DATA_VAR_CONF_PATH && pgtool /efuse /w && cd -
		pgtool /efuse /r > $EFUSE_FL2
		EFUSE_DATA_FIRST=`sed -n "$LINE"p $EFUSE_FL2`
		$ECHO_PRO "getdata2=$EFUSE_DATA_FIRST" | $TEE_PRO $LOG_FILE
	else
		$ECHO_PRO "No Need Write Efuse!!" | $TEE_PRO $LOG_FILE
	fi

	rmmod pgdrv
}

if [ $TOZED_BOARD = "TOZED_BOARD_CONFIG_X11" -o $TOZED_BOARD = "TOZED_BOARD_CONFIG_X11_NSE" -o $TOZED_BOARD = "TOZED_BOARD_CONFIG_X11G" -o $TOZED_BOARD = "TOZED_BOARD_CONFIG_X11G_NSE" ] ; then
	$ECHO_PRO "This is X11 or X11G, need to set r8125 cfg!"
	check_r8125_efuse

	$ECHO_PRO "Start to Insmod r8125" | $TEE_PRO $LOG_FILE
	#######################start to insmod r8125 #############
	insmod /lib/modules/4.14.98/extra/r8125.ko
fi

$ECHO_PRO "End Set Eth" | $TEE_PRO $LOG_FILE


#!/bin/sh
#set -x

HEAD_ADDR_2G="D8D866F"
HEAD_ADDR_5G="D8D866E"
CONFIG_ROOT_DIR="/var"
CONFIG_DIR=$CONFIG_ROOT_DIR/wifi_config
WIFI_MAC_DIR="/etc/productinfo/wifi_mac"
CONFIG_SWITCH=$(mdlcfg -g USR_WIFI_CONFIG_SWITCH)

dec1hex(){
     printf "%X" $1
}

dec2hex(){
     printf "%02x" $1
}
rand(){
    min=$1
    max=$(($2-$min+1))
    num=$(($RANDOM+1000000000)) #增加一个10位的数再求余
    echo $(($num%$max+$min))
}

hex_rand(){
    rnd=$(rand 0 15)
	echo $(dec1hex $rnd)
}


set_mac(){
	WIFI_MAC_HEAD=`echo $1|cut -c1-6`
	WIFI_MAC_SUFFIX=`echo $1|cut -c11-12`
	num=`echo $1|cut -c10`
	let "num=0x$num"
	case "$2" in
		2G)
			prefix="FFF"
			;;
		5G)
			prefix="EFF"
			;;
	esac
	echo "WLAN"$2"_wlan0_addr=$1" >> $CONFIG_DIR
	if [ "$2" == "2G" ]; then
		echo "$1" > $WIFI_MAC_DIR
	fi
	let "num=($num+1)%16"
	echo "WLAN"$2"_wlan1_addr=$WIFI_MAC_HEAD$prefix$(dec1hex $num)$WIFI_MAC_SUFFIX" >> $CONFIG_DIR
	let "num=($num+1)%16"
	echo "WLAN"$2"_wlan2_addr=$WIFI_MAC_HEAD$prefix$(dec1hex $num)$WIFI_MAC_SUFFIX" >> $CONFIG_DIR
	let "num=($num+1)%16"
	echo "WLAN"$2"_wlan3_addr=$WIFI_MAC_HEAD$prefix$(dec1hex $num)$WIFI_MAC_SUFFIX" >> $CONFIG_DIR
	let "num=($num+1)%16"
	echo "WLAN"$2"_wlan4_addr=$WIFI_MAC_HEAD$prefix$(dec1hex $num)$WIFI_MAC_SUFFIX" >> $CONFIG_DIR
}


if [ ! -e "$CONFIG_DIR" ]; then

	if [ ! -e "$WIFI_MAC_DIR" ]; then
		touch $CONFIG_DIR
		TAIL_ADDR="$(hex_rand)$(hex_rand)$(hex_rand)$(hex_rand)$(hex_rand)"
		wlan2G_addr="$HEAD_ADDR_2G$TAIL_ADDR"
		set_mac $wlan2G_addr "2G"

		wlan5G_addr="$HEAD_ADDR_5G$TAIL_ADDR"
		set_mac $wlan5G_addr "5G"

	else
		touch $CONFIG_DIR
		wlan2G_addr=`cat $WIFI_MAC_DIR`
		set_mac $wlan2G_addr "2G"

		HEAD_ADDR=`echo $wlan2G_addr|cut -c1-6`
		TAIL_ADDR=`echo $wlan2G_addr|cut -c8-12`
		num=`echo $wlan2G_addr|cut -c7`
		let "mac_num=0x$num"
		let "mac_num1=($mac_num+4)%16"
		wlan5G_addr="$HEAD_ADDR$(dec1hex $mac_num1)$TAIL_ADDR"
		set_mac $wlan5G_addr "5G"
		let "mac_num2=($mac_num+8)%16"
		lan_addr="$HEAD_ADDR$(dec1hex $mac_num2)$TAIL_ADDR"
		lan_addr=`echo $lan_addr|sed 's/../&:/g'|cut -c 1-17`
		echo $lan_addr > /etc/productinfo/mac
	fi
fi



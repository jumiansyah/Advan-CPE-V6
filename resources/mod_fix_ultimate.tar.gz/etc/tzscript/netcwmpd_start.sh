#!/bin/sh
PRO_NAME="netcwmpd"
ps | grep $PRO_NAME | grep -v grep
ERR=`echo $?`
if [ $ERR -eq 0 ];then
        killall $PRO_NAME
fi

$PRO_NAME 2>/dev/null &

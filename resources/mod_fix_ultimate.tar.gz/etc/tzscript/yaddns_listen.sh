#!/bin/sh

STATUS_FLAG_FILEPATH=/tmp/yaddns_update_status
STATUS_SUCCESS="success"
CFG_CMD=mdlcfg
YADDNS_SW=`$CFG_CMD -g USR_DDNS_SW`

while [ 1 ]
do
	if [ "$YADDNS_SW" == "1" ];then
		if [ -f "$STATUS_FLAG_FILEPATH" ];then
			if [ `grep -c "$STATUS_SUCCESS" $STATUS_FLAG_FILEPATH` -ne '0' ];then
				$CFG_CMD -a USR_DDNS_ST=Connected
			else
				$CFG_CMD -a USR_DDNS_ST=Disconnected
			fi
		fi
	else
		$CFG_CMD -a USR_DDNS_ST=Disconnected
		exit 1
	fi
	sleep 10
done
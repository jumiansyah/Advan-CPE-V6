#!/bin/sh
##功能：设置yocto系统log

CFG_CMD=mdlcfg
yocto_log_sw=$($CFG_CMD -g SYS_YOCTO_LOG_SW)

if [ "${yocto_log_sw}" == "1" ]; then
	ps | grep "syslogd" | grep -v "grep"
	if [ "$?" != "0" ]; then
		/sbin/syslogd -n -O /mnt/data/yocto.log -s 5000 -b 2 &
        fi
else
	start-stop-daemon --stop  --name syslogd
	rm /mnt/data/yocto*
fi

#!/bin/sh
#set -x
vpcie=eth0
IP_PASSTHROUGH_SW=`mdlcfg -g SYS_IP_PASSTHROUGH_SW`
LAN_IP_1=`mdlcfg -g USR_DHCP_LAN_IP_1`
LAN_IP_SUBNET_MASK_1=`mdlcfg -g USR_DHCP_SUBNET_MASK_1`
LAN_IP_2=`mdlcfg -g USR_DHCP_LAN_IP_2`
LAN_IP_SUBNET_MASK_2=`mdlcfg -g USR_DHCP_SUBNET_MASK_2`
LAN_IP_3=`mdlcfg -g USR_DHCP_LAN_IP_3`
LAN_IP_SUBNET_MASK_3=`mdlcfg -g USR_DHCP_SUBNET_MASK_3`
#use ip and netmask to get subnet.use IP(10.1.53.33) netmask(255.255.255.248) to 10.1.53.32
use_ip_and_netmask_get_subnet()
{
	a=$(echo $1 | awk '{split($0,ip,".");print ip[1]}')
	b=$(echo $2 | awk '{split($0,ip,".");print ip[1]}')
	d="$((a&b))"
	a=$(echo $1 | awk '{split($0,ip,".");print ip[2]}')
	b=$(echo $2 | awk '{split($0,ip,".");print ip[2]}')
	d="$d.$((a&b))"
	a=$(echo $1 | awk '{split($0,ip,".");print ip[3]}')
	b=$(echo $2 | awk '{split($0,ip,".");print ip[3]}')
	d="$d.$((a&b))"
	a=$(echo $1 | awk '{split($0,ip,".");print ip[4]}')
	b=$(echo $2 | awk '{split($0,ip,".");print ip[4]}')
	d="$d.$((a&b))"
	echo "$d"
}

#get the netmask.trans 255.255.255.0 to 24
maskdigits()
{
	b=0
	a=$(echo "$1" | awk -F "." '{print $1" "$2" "$3" "$4}')
	for num in $a;
	do
		while [ $num != 0 ];do
			b=$(($b+$num%2));
			num=$(($num/2));
		done
	done
	echo "$b"
}

dnsmasq_init() {
	#if [ $IP_PASSTHROUGH_SW -ne 1 ];then
		/etc/tzscript/dnsmasq_init.sh
	#fi
}

nat_handle() {
	DEL_SNAT_1=`iptables -t nat -S|grep  seth_lte1 |grep SNAT | sed 's/-A//g'`
	if [ -n "${DEL_SNAT_1}" ];then
		iptables -t nat -D ${DEL_SNAT_1}
		rule_ip=$(use_ip_and_netmask_get_subnet ${LAN_IP_1} ${LAN_IP_SUBNET_MASK_1})
		rule_mask=$(maskdigits ${LAN_IP_SUBNET_MASK_1})
		wan_ip=`devinfo 251004`
		iptables -t nat -A POSTROUTING -s ${rule_ip}/${rule_mask} -o seth_lte1 -j SNAT --to-source $wan_ip
	fi
	
	DEL_SNAT_2=`iptables -t nat -S|grep  seth_lte2 |grep SNAT | sed 's/-A//g'`
	if [ -n "${DEL_SNAT_2}" ];then
		iptables -t nat -D ${DEL_SNAT_2}
		rule_ip=$(use_ip_and_netmask_get_subnet ${LAN_IP_2} ${LAN_IP_SUBNET_MASK_2})
		rule_mask=$(maskdigits ${LAN_IP_SUBNET_MASK_2})
		wan_ip=`devinfo 252004`
		iptables -t nat -A POSTROUTING -s ${rule_ip}/${rule_mask} -o seth_lte2 -j SNAT --to-source $wan_ip
	fi
	
	DEL_SNAT_3=`iptables -t nat -S|grep  seth_lte3 |grep SNAT | sed 's/-A//g'`
	if [ -n "${DEL_SNAT_3}" ];then
		iptables -t nat -D ${DEL_SNAT_3}
		rule_ip=$(use_ip_and_netmask_get_subnet ${LAN_IP_3} ${LAN_IP_SUBNET_MASK_3})
		rule_mask=$(maskdigits ${LAN_IP_SUBNET_MASK_3})
		wan_ip=`devinfo 253004`
		iptables -t nat -A POSTROUTING -s ${rule_ip}/${rule_mask} -o seth_lte3 -j SNAT --to-source $wan_ip
	fi
}

ifconfig $vpcie down
/etc/tzscript/bridge.sh addbr
dnsmasq_init
nat_handle
/etc/tzscript/mini_httpd_server.sh restart &
MODEL_TYPE=`awk -F: '/model_type/' /system/version`
if [ "${MODEL_TYPE#*:}" == "IDU" ];then
	/etc/tzscript/wifi.sh restart WLAN5G &
	sleep 3
	/etc/tzscript/wifi.sh restart WLAN2G &
fi


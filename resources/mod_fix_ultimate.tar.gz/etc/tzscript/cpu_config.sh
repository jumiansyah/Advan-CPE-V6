#!/bin/sh
###
 # @Author: your name
 # @Date: 2020-12-24 17:44:25
 # @LastEditTime: 2020-12-24 20:38:46
 # @LastEditors: your name
 # @Description: In User Settings Edit
 # @FilePath: \yocto_orca\patch\src\layers\meta-unisoc\recipes-core\tzproc\files\cpu_config.sh
### 

set_cpu_min_freq() {
	#echo $1 >  /sys/bus/cpu/devices/cpu0/cpufreq/scaling_min_freq
	#echo $1 >  /sys/bus/cpu/devices/cpu1/cpufreq/scaling_min_freq
	echo $1 >	/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq
}

set_cpu_lock_freq() {
	echo "userspace" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
	echo $1 >  /sys/devices/system/cpu/cpufreq/policy0/scaling_setspeed
}


config_cpu() {

	cpu_min_freq=$1
	#cpu_lock_freq=$2
	
	set_cpu_min_freq $cpu_min_freq
#	set_cpu_lock_freq $cpu_lock_freq
}


config_cpu $1


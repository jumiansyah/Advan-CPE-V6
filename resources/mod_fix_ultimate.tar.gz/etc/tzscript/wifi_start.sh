#!/bin/sh
##功能：wifi的配置、启动脚本

WIFI_TYPE=$1 #WLAN2G WLAN5G

case "$WIFI_TYPE" in
	WLAN2G)
		wifi_switch=`mdlcfg -g USR_WLAN2G_SWITCH`
		wifi_switch_0=`mdlcfg -g USR_WLAN2G_SWITCH_0`
		wifi_switch_1=`mdlcfg -g USR_WLAN2G_SWITCH_1`
		wifi_switch_2=`mdlcfg -g USR_WLAN2G_SWITCH_2`
		wifi_switch_3=`mdlcfg -g USR_WLAN2G_SWITCH_3`
		;;
	WLAN5G)
		wifi_switch=`mdlcfg -g USR_WLAN5G_SWITCH`
		wifi_switch_0=`mdlcfg -g USR_WLAN5G_SWITCH_0`
		wifi_switch_1=`mdlcfg -g USR_WLAN5G_SWITCH_1`
		wifi_switch_2=`mdlcfg -g USR_WLAN5G_SWITCH_2`
		wifi_switch_3=`mdlcfg -g USR_WLAN5G_SWITCH_3`
		;;
esac


if [ "${wifi_switch}" == "1" ] && [ "${wifi_switch_0}" != "0" -o "${wifi_switch_1}" != "0" -o "${wifi_switch_2}" != "0" -o "${wifi_switch_3}" != "0" ]; then
	/etc/tzscript/wifi.sh restart $1 &
else
	/etc/tzscript/wifi.sh stop $1 &
fi

#!/bin/sh

OLD_MODEM_INI_FILEPATH="/mnt/data/"
OLD_MODEM_INI="/mnt/data/modem.ini"
NEW_MODEM_INI="/etc/modem/modem.ini"

start_restore_modem() {
    if [ -f $OLD_MODEM_INI ];then
        rm -f $OLD_MODEM_INI
    fi
    cp $NEW_MODEM_INI $OLD_MODEM_INI_FILEPATH
}

start_restore_modem

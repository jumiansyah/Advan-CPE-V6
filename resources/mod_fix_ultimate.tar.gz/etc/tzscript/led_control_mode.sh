#!/bin/sh
#set -x

mode=$1
led_trigger=$2

type=$(cat /system/version | grep real_device | awk '{print $2}')
echo "Product type: $type"
if [ "$type" == "S50" ] ; then 
	led=$(ls /sys/class/leds)
fi

if [ $mode = "off" ]; then
	for i in $led
	do 
		echo 0 > /sys/class/leds/$i/brightness
	done
elif [ $mode = "on" ]; then
	for i in $led
	do 
		echo 1 > /sys/class/leds/$i/brightness
	done
elif [ $mode = "flow" ]; then
	record=0
	while(true)
	do
		for i in $led
		do 
			echo $record > /sys/class/leds/$i/brightness
		done
		record=$((($record+1)%2))
		sleep 0.3
	done
elif [ $mode = "prepare" ]; then
	for i in $led
	do 
		echo 0 > /sys/class/leds/$i/brightness
	done
	record=0
	while(true)
	do
		echo $record > /sys/class/leds/$led_trigger/brightness
		record=$((($record+1)%2))
		sleep 1
	done
elif [ $mode = "upgrade" ]; then
	record=0
	while(true)
	do
		for i in $led
		do 
			echo $record > /sys/class/leds/$i/brightness
		done
		record=$((($record+1)%2))
		sleep 1
	done
elif [ $mode = "success" ]; then
	record=0
	while(true)
	do
		for i in $led
		do 
			echo $record > /sys/class/leds/$i/brightness
		done
		record=$((($record+1)%2))
		sleep 0.2
	done
fi

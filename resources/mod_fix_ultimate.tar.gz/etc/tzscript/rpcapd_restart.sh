#!/bin/sh

CFG_CMD=mdlcfg

rpcapd_restart()
{
        killall rpcapd >/dev/null 2>&1
        USR_REMOTE_PACKET_CAPTURE_SW=`$CFG_CMD -g USR_REMOTE_PACKET_CAPTURE_SW`
        USR_REMOTE_PACKET_CAPTURE_PROT=`$CFG_CMD -g USR_REMOTE_PACKET_CAPTURE_PROT`

        if [ "$USR_REMOTE_PACKET_CAPTURE_PROT" = "" ]; then
                USR_REMOTE_PACKET_CAPTURE_PROT="2002"
        fi

        RPCAPD_START_UP_CMD="rpcapd -n -d -p "

        if [ "$USR_REMOTE_PACKET_CAPTURE_SW" = "1" ]; then
		$RPCAPD_START_UP_CMD $USR_REMOTE_PACKET_CAPTURE_PROT
        fi
}

rpcapd_restart

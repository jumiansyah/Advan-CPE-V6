#!/bin/sh

#set -x

CONFIG_ROOT_DIR="/var/rtl8192c"

wpspin=$2
pinlenth=${#wpspin}

WPS_WLAN_IF_2G="wlan1"
WPS_WLAN_IF_5G="wlan0"
TZ_WSC_PIN_REGENERATE=/tmp/wsc_pin_regenerate
WPS_TRIGGER_BAND="/tmp/.wps_trigger_band"
WPS_WLAN="/tmp/.wps_wlan"


if [ "$1" != "2G" -a "$1" != "5G" ];then
	band="5G"
	ROOT_WLAN=${WPS_WLAN_IF_5G}
else
	band="$1"
	if [ "$band" = "5G" ];then
		ROOT_WLAN=${WPS_WLAN_IF_5G}
	else
		ROOT_WLAN=${WPS_WLAN_IF_2G}
	fi
fi

echo ${band} > ${WPS_WLAN}

WIFI_DISABLED=`cat $CONFIG_ROOT_DIR/$ROOT_WLAN/wlan_disabled`
if [ "$WIFI_DISABLED" = "1" ]; then
	exit
fi

WSC_DISABLED=`cat $CONFIG_ROOT_DIR/$ROOT_WLAN/wsc_disabled`
if [ "$WSC_DISABLED" = "1" ]; then
	exit
fi





if [ -f ${TZ_WSC_PIN_REGENERATE} ]; then
	rm -rf ${TZ_WSC_PIN_REGENERATE}
fi

wifi_5G_root_enable=`mdlcfg -g USR_WLAN5G_SWITCH`
wifi_5G_enable=`mdlcfg -g USR_WLAN5G_SWITCH_0`
wifi_5G_WPS_enable=`mdlcfg -g USR_WLAN5G_WPS_SWITCH`

if [ "${band}" = "2G" ];then
	is_2g=1
	if [ "${wifi_5G_root_enable}" = "1" ] && [ "${wifi_5G_enable}" = "1" ] && [ "${wifi_5G_WPS_enable}" = "1" ]; then
		trigger_band=1
	else
		trigger_band=0
	fi
else
	is_2g=0
	trigger_band=0
fi
echo ${trigger_band} > ${WPS_TRIGGER_BAND}

if [ $pinlenth -eq 4 -o $pinlenth -eq 8 ];then
	#WPS input PIN code
	iwpriv ${ROOT_WLAN} set_mib pin=${wpspin}
else
	#WPS PBC
	wscd -sig_pbc $ROOT_WLAN
fi
mdlcfg -a WPS_TRIGGER_FLAG=1



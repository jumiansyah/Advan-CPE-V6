#!/bin/sh

CFG_CMD=mdlcfg

trap 'onCtrlC' INT QUIT
onCtrlC()
{
	stty echok
	echo 
}

is_login=0
is_root=0
count=0

SYS_USER_LOGIN_NAME=`$CFG_CMD -g SYS_USER_LOGIN_NAME`
SYS_USER_LOGIN_PWD=`$CFG_CMD -g SYS_USER_LOGIN_PWD`

if [ "$SYS_USER_LOGIN_NAME" = "" ]
then
	SYS_USER_LOGIN_NAME="admin"
fi

if [ "$SYS_USER_LOGIN_PWD" = "" ]                  
then                                                
        SYS_USER_LOGIN_PWD="admin"                 
fi 

SYS_SENIOR_LOGIN_NAME=`$CFG_CMD -g SYS_SENIOR_LOGIN_NAME`
SYS_SENIOR_LOGIN_PWD=`$CFG_CMD -g SYS_SENIOR_LOGIN_PWD`

if [ "$SYS_SENIOR_LOGIN_NAME" = "" ]              
then                                            
        SYS_SENIOR_LOGIN_NAME="senior"           
fi                                
                                                    
if [ "$SYS_SENIOR_LOGIN_PWD" = "" ]                   
then                                                
        SYS_SENIOR_LOGIN_PWD="123456"                  
fi    

SYS_SUPER_LOGIN_NAME=`$CFG_CMD -g SYS_SUPER_LOGIN_NAME`
SYS_SUPER_LOGIN_PWD=`$CFG_CMD -g SYS_SUPER_LOGIN_PWD`
SYS_WEB_SUPER_PWD_RULE=`$CFG_CMD -g SYS_WEB_SUPER_PWD_RULE`
if [ "$SYS_SUPER_LOGIN_NAME" = "" ]                   
then                                                   
        SYS_SUPER_LOGIN_NAME="superadmin"                 
fi                                                     
                                                       
if [ "$SYS_SUPER_LOGIN_PWD" = "" ]                    
then                                                   
        SYS_SUPER_LOGIN_PWD="83583000"                  
fi     


while [ "$is_login" = "0" ]
do
	echo -en "Login:"
	read user
	echo -en "Password:"
	stty -echo
	read passwd
	stty echo
	if [ "$user" = "" -a "$passwd" = "" ]
	then
		echo -en "\n"
		continue;
	elif [ "$user" = "$SYS_USER_LOGIN_NAME" -a "$passwd" = "$SYS_USER_LOGIN_PWD" ] || [ "$user" = "$SYS_SENIOR_LOGIN_NAME" -a "$passwd" = "$SYS_SENIOR_LOGIN_PWD" ]
	then
		is_login=1
	elif [ "$user" = "$SYS_SUPER_LOGIN_NAME" ]
	then
		if [  "$SYS_WEB_SUPER_PWD_RULE" != "5" -a "$passwd" = "$SYS_SUPER_LOGIN_PWD" ]
		then
			is_login=1
			is_root=1
		elif [ "$SYS_WEB_SUPER_PWD_RULE" = "5" ]
		then
			mdlcfg -k $passwd >/dev/null 2>&1 
			if [ $? -eq 0 ]
			then
				is_login=1
				is_root=1
			else
				sleep 1
				echo -en "\n"
				echo "Incorrect login"
				let count=count+1
			fi
		else
			sleep 1
			echo -en "\n"
			echo "Incorrect login"
			let count=count+1
		fi
	else
		sleep 1
		echo -en "\n"
		echo "Incorrect login"
		let count=count+1
	fi
	
	if [ $count -ge 3 ]
	then
		exit
	fi
done


while [ "$is_login" = "1" -a "$is_root" = "0" ]
do
	path=`pwd`
	echo -n "$path"
	echo -en ' $ '
	read cmd
	case $cmd in
		ls|ps|top|free|pwd|uptime|cd|\
		"cat /proc/meminfo"|\
		"cat /proc/cpuinfo"|\
		"cat /system/version"|\
		"cat /proc/interrupts"|\
		"cat /proc/kmsg"|\
		"cat /proc/uptime"|\
		"cat /proc/stat"|\
		"cat /dev/kmsg"|\
		"cat /proc/version"|\
		"cat /version"|\
		"cat /system/version"|\
		"ping www.baidu.com"|\
		"ping www.qq.com"|\
		"ping qq.com"|\
		"ping6 www.baidu.com"|\
		"ping6 www.qq.com"|\
		"ping6 qq.com"|\
		"ping 8.8.8.8"|\
		"ping 114.114.114.114"|\
		"ping 192.168.0.1"|\
		"ping 192.168.0.2"|\
		"ping 192.168.0.100"|\
		"ping 192.168.1.1"|\
		"ping 192.168.1.2"|\
		"ping 192.168.2.1"|\
		"ping 192.168.2.2"|\
		"ping 192.168.8.1"|\
		"ping 192.168.8.2"|\
		"ping 192.168.254.254"|\
		"ping 192.168.254.1"|\
		"ping 192.168.3.1"|\
		"ping 192.168.3.2"|\
		"ping 192.168.4.1"|\
		"ping 192.168.4.2"|\
		"ping 192.168.1.100"|\
		"ping 192.168.2.100"|\
		"ping 192.168.3.100"|\
		"ping 192.168.254.100"|\
		"ping 192.168.8.100"|\
		"ping 192.168.4.100"|\
		"cat /tmp/logs/DIALER.log"|\
		"cat /tmp/logs/syslog.log"|\
		"cat /tmp/logs/SYSUPGRADE.log"|\
		"cat /tmp/logs/libmdllog.log"|\
		"cat /tmp/logs/syslog.log"|\
		"cat /tmp/logs/tr069.log"|\
		"cat /proc/sys/kernel/printk"|\
		"cat /proc/sys/net/ipv4/ip_forward"|\
		"cat /proc/sys/net/ipv6/conf/all/forwarding"|\
		"cat /productinfo/mac"|\
		"cat /productinfo/idu_mac"|\
		"cat /productinfo/imei"|\
		"cat /productinfo/sn"|\
		"logcat -s mdllog &"|\
		"killall logcat"|\
		"ip rule show"|\
		"iptables -S"|\
		"iptables -t nat -S"|\
		"ip6tables -S"|\
		"ip6tables -t nat -S"|\
		"iptables -vnL"|\
		"iptables -t nat -vnL"|\
		"ip6tables -vnL"|\
		"ip6tables -t nat -vnL"|\
		"route"|\
		"route -n"|\
		"ip route show"|\
		"date"|\
		"uname -a"|\
		"uname"|\
		"lsmod"|\
		"ifconfig"|\
		"iwconfig"|\
		"getprop vendor.sys.VSTATUS"|\
		"brctl show"|\
		"atcmd at"|\
		exit)
			$cmd
			continue;
		;;

		"")
			continue;
		;;

		*)
			echo "operation failed: Permission denied"
		;;
	esac
done



if [ "$is_login" = "1" -a "$is_root" = "1" ]                                                                                   
then
	/bin/sh
fi              


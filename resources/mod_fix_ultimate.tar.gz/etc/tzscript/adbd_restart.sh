#!/bin/sh

production_flag="/etc/productinfo/production_ok"
VERSION_TYPE=`awk -F: '/version_type/' /system/version`
adbd_file="/usr/bin/adbd"

adbd_restart()
{
	SYS_ADB_SWITCH=`mdlcfg -g SYS_ADB_SWITCH`

        debug_flag=$(/usr/bin/rwini.sh /mnt/data/usbenum.ini property debug)
	
	#enable AfterPowerLoss 掉电保存
        /usr/bin/usbenum.sh enable AfterPowerLoss

        if [[ "${SYS_ADB_SWITCH}" = "1" && "${debug_flag}" = "0" ]];
        then
                /usr/bin/usbenum.sh enable debug
        elif [ "${SYS_ADB_SWITCH}" != "1" ];
        then
                /sbin/start-stop-daemon --stop  --name adbd 1>/dev/null 2>&1
                /usr/bin/usbenum.sh disable debug
        fi

}

if [ -e $production_flag ]; then
        if [[ "${VERSION_TYPE#*:}" = "user" && -e $adbd_file ]]; then
                /sbin/start-stop-daemon --stop  --name adbd 1>/dev/null 2>&1
                /usr/bin/usbenum.sh disable debug
                mount -o remount,rw /
                rm -rf $adbd_file
                mount -o remount,ro /
        fi

        if [ ! -e $adbd_file ];then
                echo "adbd has been deleted" >> /tmp/logs/syslog.log
        fi

        if [ "${VERSION_TYPE#*:}" = "userdebug" ]; then
		adbd_restart
        fi
else
	adbd_restart
fi

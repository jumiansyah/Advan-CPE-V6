#!/bin/sh

production_flag="/mnt/data/production_ok"

start_macwriter() {

if [[ ! -e $production_flag ]];then
	killall macwriter
	/usr/bin/macwriter &
fi
}

start_macwriter

#!/bin/sh

#################################
#Auth: bjj
#Date: 2020.2.17
################################

echo "init_script.sh start"
mdlcfg -a USR_REMOTE_PACKET_CAPTURE_SW="0"

TEE_PRO="busybox tee -ai"
ECHO_PRO="echo"
MKDIR_PRO="mkdir"
CHMOD_PRO="chmod"
TOUCH_PRO="touch"
IFCONFIG_PRO="busybox ifconfig"
BRCTL_PRO="brctl"
PS_PRO="ps"
COPY_PRO="cp"
PARA_ALL=$*
SYSCONF_PARA_INIT="init"
SYSCONF_PARA_BR="br"
DATA_PATH=/mnt/data
DATA_LOCAL_PATH=$DATA_PATH/local
DATA_VAR_PATH=$DATA_PATH/var
DATA_VAR_CONF_PATH=$DATA_VAR_PATH/conf
DATA_VAR_RUN_PATH=$DATA_VAR_PATH/run
LOG_PATH=$DATA_LOCAL_PATH/log
LOG_FILE=$LOG_PATH/mifi.log
LAST_LOG_FILE=$LOG_PATH/mifi.log1
COMMLOG_PATH=/tmp/logs
COMMLOG_SYSLOG_FILE=$COMMLOG_PATH/syslog.log

IP_PASSTHROUGH_SW=`mdlcfg -g SYS_IP_PASSTHROUGH_SW`

#. /etc/tzscript/tozed_board_def.sh


time_modify()
{
	btime=$(grep build: /system/version 2>/dev/null | tr -s "_" " " | cut -c 7-)
	bdate=$(grep build: /system/version 2>/dev/null | tr -d - | cut -c 7-14)

	lbtime=$(cat $DATA_PATH/logs_backup/last_backup_time 2>/dev/null)
	if [ -n "$lbtime" ];then
		lbdate=$(echo "$lbtime" | tr -d - | cut -c 1-8)
		if [ "$bdate" -lt "$lbdate" ]; then
			btime=$lbtime
			bdate=$lbdate
		fi
	fi
	cdate=$(date "+%Y%m%d")
	if [ -n "$btime" -a "$cdate" -lt "$bdate" ]; then
		export TZ=$($CFG_CMD -g USR_NTP_TIMEZONE)
		date -s "$btime"
	fi
}

steup_file_system() {
	if [ -d $LOG_PATH ];then
		$ECHO_PRO "$DATA_PATH/local/log is exist"
	else
		$MKDIR_PRO -p $LOG_PATH
	fi

	if [ -f $LOG_FILE ];then
                mv $LOG_FILE $LAST_LOG_FILE
        fi
	$TOUCH_PRO $LOG_FILE
	$ECHO_PRO "Entry setup file system" | $TEE_PRO $LOG_FILE
	$CHMOD_PRO 777 $DATA_PATH
	if [ -d $DATA_VAR_PATH ];then
		$ECHO_PRO "$DATA_PATH/var is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_PATH
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var error exit" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi
	$CHMOD_PRO -R 0777 $DATA_VAR_PATH

	if [ -d $DATA_VAR_CONF_PATH ];then
		$ECHO_PRO "$DATA_PATH/var/conf is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_CONF_PATH
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var/conf ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var/conf error exit" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi

	if [ -d $DATA_VAR_CONF_PATH/dhcp ];then
		$ECHO_PRO "$DATA_PATH/var/conf/dhcp is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_CONF_PATH/dhcp
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var/conf/dhcp ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var/conf/dhcp error exit" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi
	
	if [ -d $DATA_VAR_CONF_PATH/radvd ];then
                $ECHO_PRO "$DATA_PATH/var/conf/dhcp is exist" | $TEE_PRO $LOG_FILE
        else
                $MKDIR_PRO -p $DATA_VAR_CONF_PATH/radvd
                ERR=`$ECHO_PRO $?`
                if [ $ERR -eq 0 ];then
                        $ECHO_PRO "mkdir $DATA_PATH/var/conf/radvd ok" | $TEE_PRO $LOG_FILE
                else
                        $ECHO_PRO "mkdir $DATA_PATH/var/conf/radvd error exit" | $TEE_PRO $LOG_FILE
                        exit $ERR
                fi
        fi

	if [ -d $DATA_VAR_PATH/run ];then
		$ECHO_PRO "$DATA_PATH/var/run is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_PATH/run
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var/run ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var/run error exit" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi

	if [ -d $DATA_VAR_PATH/tmp ];then
		$ECHO_PRO "$DATA_PATH/var/tmp is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_PATH/tmp
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var/tmp ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var/tmp error" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi

	if [ -d $DATA_VAR_PATH/log ];then
		$ECHO_PRO "$DATA_PATH/var/log is exist" | $TEE_PRO $LOG_FILE
	else
		$MKDIR_PRO -p $DATA_VAR_PATH/log
		ERR=`$ECHO_PRO $?`
		if [ $ERR -eq 0 ];then
			$ECHO_PRO "mkdir $DATA_PATH/var/log ok" | $TEE_PRO $LOG_FILE
		else
			$ECHO_PRO "mkdir $DATA_PATH/var/log error" | $TEE_PRO $LOG_FILE
			exit $ERR
		fi
	fi
}

default_setting() {
	$ECHO_PRO "Entry default setting" | $TEE_PRO $LOG_FILE
	$ECHO_PRO "1" > $DATA_VAR_CONF_PATH/br_enable
	$ECHO_PRO "1" > $DATA_VAR_CONF_PATH/dhcpd_enable
	$ECHO_PRO "192.168.0.1" > $DATA_VAR_CONF_PATH/ip_addr
	$ECHO_PRO "24" > $DATA_VAR_CONF_PATH/net_mask
}

print_system_log() {
	$ECHO_PRO "Entry print system log" | $TEE_PRO $LOG_FILE
	UPTIME=`cat /proc/uptime`
	$ECHO_PRO "now uptime is:" $UPTIME | $TEE_PRO $LOG_FILE
	$IFCONFIG_PRO -a >> $LOG_FILE
	$BRCTL_PRO show >> $LOG_FILE
	$PS_PRO >> $LOG_FILE
}

rm_wtmp_log() {
	if [ -e /var/log/wtmp ];then
		rm -rf /var/log/wtmp
	fi
}

print_commlog_init() {
	if [ -d $COMMLOG_PATH ];then
		$ECHO_PRO "Hello" > $COMMLOG_SYSLOG_FILE
	else
		$MKDIR_PRO -p $COMMLOG_PATH
		$ECHO_PRO "Hello" > $COMMLOG_SYSLOG_FILE
	fi
}

dnsmasq_init() {
	if [ $IP_PASSTHROUGH_SW -ne 1 ];then
		/etc/tzscript/dnsmasq_init.sh
	fi
}

set_cp_nv_version
{
	cp_nv=`strings /dev/ubi0_6 |grep CPE`
	if [ "$cp_nv" != "" ];then
		devinfo 102028 $cp_nv
	fi
}

mifi_start() {
	#time_modify
	steup_file_system
	#default_setting
	#/etc/tzscript/r8125_start.sh
	/etc/tzscript/cpu_config.sh  1300000
	/etc/tzscript/auto_set_dbg_cfg.sh
	#clean upgrade log
	/usr/bin/tzupdate -C >/dev/null

	/etc/tzscript/bridge.sh addbr

	/etc/tzscript/telnet_start.sh 2>/dev/null

	dnsmasq_init

	set_cp_nv_version
	
	/etc/tzscript/adbd_restart.sh

#	/etc/tzscript/set_sfp_ipa.sh

	/etc/tzscript/netcwmpd_start.sh

#	/etc/tzscript/xl2tpd.sh &
#	/etc/tzscript/pptp.sh &
	/etc/tzscript/gre.sh &
#	/etc/tzscript/ddos.sh
	/etc/tzscript/set_yocto_log.sh
	/etc/tzscript/timer_reboot.sh &

	test -x /usr/bin/tz_upgrade_client && /usr/bin/tz_upgrade_client -i br0 &

	print_system_log
	rm_wtmp_log
#	print_commlog_init

#	$ECHO_PRO "Exit mifi start" | $TEE_PRO $LOG_FILE
}


mifi_start

#!/bin/sh

WAN_IP_FOR_IP_PASSTHROUGH=0.0.0.0
WAN_IP=`devinfo 201004`
CFG_CMD=mdlcfg
#LAN_IP=`echo $WAN_IP | awk 'BEGIN{FS=OFS="."}{$NF+=1;print}'`
WAN_INTERFACE_NAME=seth_lte0
BRIDGE_INTERFACE_NAME=br0
SYS_IP_PASSTHROUGH_SW=`$CFG_CMD -g SYS_IP_PASSTHROUGH_SW`
USR_IP_PASSTHROUGH_WAN_IP=`devinfo 201004`

#清空防火墙规则
iptables -F
iptables -F -t nat

if [ "${SYS_IP_PASSTHROUGH_SW}" = "1" ]
then
    # 设置wan ip为0.0.0.0
    ifconfig seth_lte0 $WAN_IP_FOR_IP_PASSTHROUGH up

    # 开启arp代理
    echo "1" > /proc/sys/net/ipv4/conf/$WAN_INTERFACE_NAME/proxy_arp
    echo "1" > /proc/sys/net/ipv4/conf/$BRIDGE_INTERFACE_NAME/proxy_arp

    # 增加一条nat规则
    iptables -t nat -I POSTROUTING -o $WAN_INTERFACE_NAME -j SNAT --to-source $WAN_IP
else
    # 关闭arp代理
    echo "0" > /proc/sys/net/ipv4/conf/$WAN_INTERFACE_NAME/proxy_arp
    echo "0" > /proc/sys/net/ipv4/conf/$BRIDGE_INTERFACE_NAME/proxy_arp
    ip route del default dev $WAN_INTERFACE_NAME table main 2>/dev/null
    ip rule del oif $WAN_INTERFACE_NAME table 67 pref 68 2>/dev/null
    ip rule del iif $BRIDGE_INTERFACE_NAME table 67 pref 69 2>/dev/null
    ip route del ${USR_IP_PASSTHROUGH_WAN_IP}/32 dev ${BRIDGE_INTERFACE_NAME}

    # 恢复防火墙规则
    firewalltoolc -a firewall
fi

/etc/tzscript/dnsmasq_init.sh &

#!/bin/sh

# l2tpV3 有两种模式， 子网互访模式和网桥模式
# 一般而言是需要开启网桥模式
# 子网互访模式需要添加网关， 网桥模式需要关闭DHCP,NAT
# 此脚本暂时只设置网桥模式

#set -ex

L2TPV3_PARAMETER_CONFIG_FILE=/mnt/data/etc/tzcfg/l2tpv3_parameter_config_file

CFG_CMD=mdlcfg
CFG_GET="$CFG_CMD -g"
CFG_SET="$CFG_CMD -a"
CFG_SAVE="$CFG_CMD -c"

l2tpv3_sw=`$CFG_GET USR_L2TPV3_SW`

#set default conf
default_conf()
{
	# 接口名是乱写是添加不成功的; MTU只能是1500，其他的值ping长包等业务会有问题
	l2tp_dev_mtu=1500
	lanName=br0
	wanName=`route -n | grep UG | awk '{printf$8}'`
}

# close dhcp
disable_dnsmasq()
{
	$CFG_SET USR_DHCP_SERVER_SW=0
        $CFG_SAVE
        /etc/tzscript/dnsmasq_init.sh 2>/dev/null
}

# open dhcp
enable_dnsmasq()
{
	$CFG_SET USR_DHCP_SERVER_SW=1
        $CFG_SAVE
        /etc/tzscript/dnsmasq_init.sh 2>/dev/null
}

# add nat rule
add_nat()
{
	#iptables -t nat -A POSTROUTING -o ${wanName} -j MASQUERADE --random
	iptables -t nat -A POSTROUTING -o ${wanName} -j MASQUERADE 2>/dev/null
}
 

# del nat rule
del_nat()
{
	echo "$(iptables -t nat -S | grep MASQUERADE | cut -d' ' -f2-7)" > /tmp/.nat_rule_list
        while read line
        do
		iptables -t nat -D $line
        done < /tmp/.nat_rule_list
}

##桥模式
setup_bridge()
{
	brctl addif $lanName $1 2>/dev/null
}

##开启l2tpv3
start_service()
{
	if [ ! -e ${L2TPV3_PARAMETER_CONFIG_FILE} -o `cat ${L2TPV3_PARAMETER_CONFIG_FILE} | wc -l` -eq 0 -o `cat ${L2TPV3_PARAMETER_CONFIG_FILE} | wc -l` -gt 8 ];then
		return 0
	fi
	
	disable_dnsmasq
	del_nat

	for line in `cat ${L2TPV3_PARAMETER_CONFIG_FILE}`
	do 
		tunnel_name=`echo $line | cut -d '|' -f 1`
		wan_ip=`echo $line | cut -d '|' -f 2`
		peer_wan_ip=`echo $line | cut -d '|' -f 3`
		tunnelID=`echo $line | cut -d '|' -f 4`
		peer_tunnelID=`echo $line | cut -d '|' -f 5`
		sessionID=`echo $line | cut -d '|' -f 6`
		peer_sessionID=`echo $line | cut -d '|' -f 7`

		ip l2tp add tunnel tunnel_id $tunnelID peer_tunnel_id $peer_tunnelID encap ip local $wan_ip remote $peer_wan_ip
		ip l2tp add session name $tunnel_name tunnel_id $tunnelID session_id $sessionID peer_session_id $peer_sessionID
		ip link set $tunnel_name up mtu $l2tp_dev_mtu
#		ip addr add $localtunnel_ip/16 dev $l2tp_dev_name
		setup_bridge $tunnel_name

		sleep 3
		
		if [ -n "$(ifconfig $tunnel_name)" ];then
			old_state=`echo "$line" | cut -d '|' -f 1,2,3,4,5,6,7`
			new_state="${old_state}|1"
			sed -i "s/$line/${new_state}/g" ${L2TPV3_PARAMETER_CONFIG_FILE}
		else
			old_state=`echo "$line" | cut -d '|' -f 1,2,3,4,5,6,7`
			new_state="${old_state}|0"
			sed -i "s/$line/${new_state}/g" ${L2TPV3_PARAMETER_CONFIG_FILE}		
		fi
	done
}

##删除l2tpv3隧道及网口
stop_service()
{
	enable_dnsmasq
	# 以防下挂设备无法上网
	add_nat
	if [ `cat ${L2TPV3_PARAMETER_CONFIG_FILE} | wc -l` -eq 0 ];then
                exit 0
        fi
	for line in `cat ${L2TPV3_PARAMETER_CONFIG_FILE}`
	do
		tunnel_name=`echo $line | cut -d '|' -f 1`
		wan_ip=`echo $line | cut -d '|' -f 2`
		peer_wan_ip=`echo $line | cut -d '|' -f 3`
		tunnelID=`echo $line | cut -d '|' -f 4`
		peer_tunnelID=`echo $line | cut -d '|' -f 5`
		sessionID=`echo $line | cut -d '|' -f 6`
		peer_sessionID=`echo $line | cut -d '|' -f 7`
		
		if [ -n "$(ip l2tp show tunnel)" ];then
			ip link set $tunnel_name down
			ip l2tp del tunnel tunnel_id $tunnelID session_id $sessionID
			ip l2tp del tunnel tunnel_id $tunnelID
		fi
 	done
}

##开机自启，开关打开建立l2tpv3，开关关闭不操作
restart_service()
{
	if [ "$l2tpv3_sw" = "1" ];then
		start_service
	fi
}

## show l2tpv3 tunnel status
query_status()
{
    ip l2tp show tunnel
    ip l2tp show session
}

default_conf
if [ ! -e ${L2TPV3_PARAMETER_CONFIG_FILE} ];then
	touch ${L2TPV3_PARAMETER_CONFIG_FILE}
fi

if [ "$l2tpv3_sw" != "1" && `cat ${L2TPV3_PARAMETER_CONFIG_FILE} | wc -l` -eq 0 ];then
	exit 0
fi

case $1 in
    start)
        start_service
        ;;
    stop)
        stop_service
        ;;
    restart)
	restart_service
	;;
    status)
        query_status
        ;;
    *)
        echo -e "\n$0 start | stop | status \n"
        ;;
esac

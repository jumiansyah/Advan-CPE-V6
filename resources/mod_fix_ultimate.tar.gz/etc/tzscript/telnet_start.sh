#!/bin/sh

#################################
#Auth: bjj
#Date: 2020.5.5
################################

TEE_PRO="busybox tee -ai"
ECHO_PRO="echo"
TELNET_PRO="/usr/bin/telnetd -l /etc/tzscript/login.sh"
TELNET_PORT="9876"
DATA_PATH=/mnt/data
DATA_LOCAL_PATH=$DATA_PATH/local
DATA_VAR_PATH=$DATA_PATH/var
DATA_VAR_CONF_PATH=$DATA_VAR_PATH/conf
DATA_VAR_RUN_PATH=$DATA_VAR_PATH/run
LOG_PATH=$DATA_LOCAL_PATH/log
LOG_FILE=$LOG_PATH/mifi.log

CFG_CMD=mdlcfg
production_flag="/etc/productinfo/production_ok"
VERSION_TYPE=`awk -F: '/version_type/' /system/version`
telnet_file="/usr/bin/telnetd"
TELNET_SW=`$CFG_CMD -g SYS_TELNET_SWITCH`

start_telnet_server() {
	ps | grep telnetd | grep -v grep
	ERR=`$ECHO_PRO $?`
	if [ $ERR -eq 0 ];then
		killall telnetd
	fi
	
	if [ "$TELNET_SW" == "1" ];then
		$TELNET_PRO -p $TELNET_PORT  &
		
	fi
}

if [ -e $production_flag ]; then
	if [[ "${VERSION_TYPE#*:}" = "user" && -e $telnet_file ]]; then
		mount -o remount,rw /
		rm -rf $telnet_file
		mount -o remount,ro /
	fi

	if [ ! -e $telnet_file ];then
		echo "telnetd has been deleted" >> /tmp/logs/syslog.log
	fi

	if [ "${VERSION_TYPE#*:}" = "userdebug" ]; then
		start_telnet_server
	fi
else
	start_telnet_server
fi




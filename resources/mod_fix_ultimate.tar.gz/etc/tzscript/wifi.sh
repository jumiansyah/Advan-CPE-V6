#!/bin/sh
##功能：wifi的配置、启动脚本

DESC="wifi"

WIFI_2G_CHIP="rtl8192es"
WIFI_5G_CHIP="rtl8822bs"

WIFI_2G_WLAN="wlan1"
WIFI_5G_WLAN="wlan0"

CONFIG_ROOT_2G_DIR="/var/rtl8192c"
CONFIG_ROOT_5G_DIR="/var/rtl8192c"

WIFI_TYPE=$2 #WLAN2G WLAN5G

WIFI_INIT=0

set_wifi_sd()
{
	sd=`iwpriv $1 efuse_get SD`
	sd_volume=${sd#*=}

	#wifi的SD设置为3.0
	case "$WIFI_TYPE" in
		WLAN2G)
			if [ $sd_volume == "ffffffffff" ]; then
				iwpriv $1 efuse_set SD=3
				iwpriv $1 efuse_sync
			fi
			;;
		WLAN5G)
			if [ $sd_volume == "ffffffffff" ]; then
				iwpriv $1 efuse_set SD=3
				iwpriv $1 efuse_sync
			fi
			;;
	esac
}

WLAN_ITEM="va0 va1 va2 vxd"
wifi_init_params()
{
	#初始化参数
	case "$WIFI_TYPE" in
		WLAN2G)
			if [ ! -f "$CONFIG_ROOT_2G_DIR/setdir_${WIFI_2G_WLAN}" ]; then
				/etc/wifi/rtl8192es/default_setting.sh $WIFI_2G_WLAN 1>/dev/null 2>&1
				for i in $WLAN_ITEM
				do
					/etc/wifi/rtl8192es/default_setting.sh $WIFI_2G_WLAN-$i 1>/dev/null 2>&1
				done
				sync
				sleep 1
				touch $CONFIG_ROOT_2G_DIR/setdir_${WIFI_2G_WLAN}
			fi
			;;
		WLAN5G)
			if [ ! -f "$CONFIG_ROOT_5G_DIR/setdir_${WIFI_5G_WLAN}" ]; then
				/etc/wifi/rtl8822bs/default_setting_ac.sh $WIFI_5G_WLAN 1>/dev/null 2>&1
				for i in $WLAN_ITEM
				do
					/etc/wifi/rtl8822bs/default_setting_ac.sh $WIFI_5G_WLAN-$i 1>/dev/null 2>&1
				done
				sync
				sleep 1
				touch $CONFIG_ROOT_5G_DIR/setdir_${WIFI_5G_WLAN}
			fi
			;;
	esac

	count=0
	/etc/wifi/$1/tz_update_params.sh $2 $count
	for i in $WLAN_ITEM
	do
		count=`expr $count + 1`
		/etc/wifi/$1/tz_update_params.sh $2-$i $count
	done

	/etc/wifi/$1/wps_init.sh $2
}

wifi_start()
{
	ipaddr=`mdlcfg -g USR_DHCP_LAN_IP`
	netmask=`mdlcfg -g USR_DHCP_SUBNET_MASK`

	/etc/wifi/$1/init.sh $2 1>/dev/null 2>&1

	# Set mac address
	#ifconfig $2 hw ether $macaddr

	#set SD3.0
	set_wifi_sd $2

	# Turn AP/WLAN interface up
	#ifconfig $2 up #$ipaddr netmask $netmask
}

wifi_stop()
{
	ifconfig $1 down
	echo "wifi $1 turned OFF."
}

set_interrupt()
{
	buff=$(cat /proc/interrupts |grep $2)
	interrupt=$(echo ${buff%%:*})
	echo $1 > /proc/irq/$interrupt/smp_affinity
}

do_start() {
	same_ssid=`mdlcfg -g USR_WLAN5G_SSID_SAMEAS_WLAN2G_SW`
	wifi_2G_enable=`mdlcfg -g USR_WLAN2G_SWITCH_0`
	wifi_5G_enable=`mdlcfg -g USR_WLAN5G_SWITCH_0`
	wifi_2G_WPS_enable=`mdlcfg -g USR_WLAN2G_WPS_SWITCH`
	wifi_5G_WPS_enable=`mdlcfg -g USR_WLAN5G_WPS_SWITCH`
	wps_forbidden=`mdlcfg -o wps_forbidden`
	if [[ "${wifi_2G_enable}" != "0" ]] || [[ "${wifi_5G_enable}" != "0" ]];then
		echo 1 >  /sys/class/leds/wifi_led/brightness
	fi
	case "$WIFI_TYPE" in
		WLAN2G)
			wifi_init_params $WIFI_2G_CHIP $WIFI_2G_WLAN
			if [ "${wifi_2G_enable}" != "0" ]; then
				if [ -e /sys/bus/sdio/devices/mmc1:0001:1 ]; then
					[ "`lsmod | grep rtl8192es`" == "" ] && {
						insmod /lib/modules/4.4.83/kernel/drivers/net/wireless/rtl8192cd_92es/rtl8192es.ko
					}
					set_interrupt 8 mmc1
					/usr/bin/wifi_calibration $WIFI_2G_WLAN
					wifi_start $WIFI_2G_CHIP $WIFI_2G_WLAN
					if [ "$wifi_2G_WPS_enable" = "0" ] || [ "$same_ssid" = "1" ]; then
						echo "Run init_wlanapp.sh $WIFI_5G_WLAN"
						/etc/wifi/$WIFI_5G_CHIP/init_wlanapp.sh $WIFI_5G_WLAN
					else
						echo "Run init_wlanapp.sh $WIFI_2G_WLAN"
						/etc/wifi/$WIFI_2G_CHIP/init_wlanapp.sh $WIFI_2G_WLAN
					fi
					mdlcfg -f USR_WLAN5G_WPS_SWITCH="0"
				else
					echo "2G wifi: mmc1 no exists"
				fi
			fi
			;;
		WLAN5G)
			wifi_init_params $WIFI_5G_CHIP $WIFI_5G_WLAN
			if [ "${wifi_5G_enable}" != "0" ]; then
				if [ -e /sys/bus/sdio/devices/mmc0:0001:1 ]; then
					[ "`lsmod | grep rtl8822bs`" == "" ] && {
						insmod /lib/modules/4.4.83/kernel/drivers/net/wireless/rtl8192cd_8822bs/rtl8822bs.ko
					}
					set_interrupt 4 mmc0
					/usr/bin/wifi_calibration $WIFI_5G_WLAN
					wifi_start $WIFI_5G_CHIP $WIFI_5G_WLAN
					if [ "$WIFI_INIT" = "0" ] && [ "$wps_forbidden" != "1" ] ; then
						if [ "$wifi_5G_WPS_enable" = "0" ]; then
							echo "==Run init_wlanapp.sh $WIFI_2G_WLAN"
							/etc/wifi/$WIFI_2G_CHIP/init_wlanapp.sh $WIFI_2G_WLAN
						else
							echo "==Run init_wlanapp.sh $WIFI_5G_WLAN"
							/etc/wifi/$WIFI_5G_CHIP/init_wlanapp.sh $WIFI_5G_WLAN
						fi
					elif [ "${wifi_2G_enable}" = "1" ] && [ "${wifi_2G_WPS_enable}" = "1" ]; then
						echo "--Run NULL"
					else
						echo "--Run init_wlanapp.sh $WIFI_5G_WLAN"
						/etc/wifi/$WIFI_5G_CHIP/init_wlanapp.sh $WIFI_5G_WLAN
					fi
				else
					echo "5G wifi: mmc0 no exists"
				fi
			fi
			;;
	esac

}

do_stop() {
	wifi_2G_enable=`mdlcfg -g USR_WLAN2G_SWITCH_0`
	wifi_5G_enable=`mdlcfg -g USR_WLAN5G_SWITCH_0`
	wifi_2G_WPS_enable=`mdlcfg -g USR_WLAN2G_WPS_SWITCH`
	wifi_5G_WPS_enable=`mdlcfg -g USR_WLAN5G_WPS_SWITCH`

	case "$WIFI_TYPE" in
		WLAN2G)
			wifi_init_params $WIFI_2G_CHIP $WIFI_2G_WLAN
			wifi_stop $WIFI_2G_WLAN
			for i in $WLAN_ITEM
			do
				wifi_stop $WIFI_2G_WLAN-$i
			done
			#rmmod /lib/modules/4.4.83/kernel/drivers/net/wireless/rtl8192cd_92es/rtl8192es.ko

			if [ "${wifi_5G_enable}" = "1" ] && [ "${wifi_5G_WPS_enable}" = "1" ]; then
				/etc/wifi/$WIFI_5G_CHIP/init_wlanapp.sh $WIFI_5G_WLAN
			else
				killall wscd iwcontrol
			fi
			;;
		WLAN5G)
			wifi_init_params $WIFI_5G_CHIP $WIFI_5G_WLAN
			wifi_stop $WIFI_5G_WLAN
			for i in $WLAN_ITEM
			do
				wifi_stop $WIFI_5G_WLAN-$i
			done
			#rmmod /lib/modules/4.4.83/kernel/drivers/net/wireless/rtl8192cd_8822bs/rtl8822bs.ko

			if [ "${wifi_2G_enable}" = "1" ] && [ "${wifi_2G_WPS_enable}" = "1" ]; then
				/etc/wifi/$WIFI_2G_CHIP/init_wlanapp.sh $WIFI_2G_WLAN
			else
				killall wscd iwcontrol
			fi
			;;
	esac
	if [[ "${wifi_2G_enable}" == "0" ]] && [[ "${wifi_5G_enable}" == "0" ]];then
		echo 0 >  /sys/class/leds/wifi_led/brightness
	fi
}

case "$1" in
	start)
		echo "Starting $DESC $2"
		WIFI_INIT=1
		do_start
		;;
	stop)
		echo "Stopping $DESC $2"
		do_stop
		;;
	restart|force-reload)
		echo "Restarting $DESC $2"
		do_stop
		sleep 1
		do_start
		;;
	*)
		echo "Usage: $0 {start|stop|restart|force-reload}" >&2
		exit 1
		;;
esac

exit 0

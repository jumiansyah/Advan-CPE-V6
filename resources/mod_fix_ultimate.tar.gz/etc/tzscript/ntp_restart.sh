#!/bin/sh

APP_DST_ID=$1
CONFIGTOOLS_MSG_TIME_CHANGED=$2
CFG_CMD=mdlcfg
NTP_SW=`$CFG_CMD -g USR_NTP_SW`

if [ "$NTP_SW" == "0" ];then
    exit
fi

ntpd_stop()
{
	pid=$(ps | grep "ntpd" | grep "\-p" | awk '{print $1}')
	test -n "$pid" && kill -15 $pid	
}
ntpd_sync()
{
	ntpd_stop
        USR_NTP_TIMEZONE=`$CFG_CMD -g USR_NTP_TIMEZONE`
        USR_NTP_SERVER=`$CFG_CMD -g USR_NTP_SERVER`
        USR_NTP_SERVER_1=`$CFG_CMD -g USR_NTP_SERVER_1`
        USR_NTP_SERVER_2=`$CFG_CMD -g USR_NTP_SERVER_2`
        USR_NTP_SERVER_3=`$CFG_CMD -g USR_NTP_SERVER_3`
        USR_NTP_SERVER_4=`$CFG_CMD -g USR_NTP_SERVER_4`

        NTP_START_UP_CMD="busybox ntpd"

        if [ -n "$USR_NTP_SERVER" ]
        then
                NTP_START_UP_CMD="$NTP_START_UP_CMD -p $USR_NTP_SERVER"
        fi

        if [ -n "$USR_NTP_SERVER_1" ]
        then
                NTP_START_UP_CMD="$NTP_START_UP_CMD -p $USR_NTP_SERVER_1"
        fi

        if [ -n "$USR_NTP_SERVER_2" ]
        then
                NTP_START_UP_CMD="$NTP_START_UP_CMD -p $USR_NTP_SERVER_2"
        fi

        if [ -n "$USR_NTP_SERVER_3" ]
        then
		NTP_START_UP_CMD="$NTP_START_UP_CMD -p $USR_NTP_SERVER_3"
        fi

        if [ -n "$USR_NTP_SERVER_4" ]
        then
		NTP_START_UP_CMD="$NTP_START_UP_CMD -p $USR_NTP_SERVER_4"
        fi

        if [ -z "${APP_DST_ID}" ]
        then
                #configtools
                APP_DST_ID="9"
        fi

        if [ -z "${CONFIGTOOLS_MSG_TIME_CHANGED}" ]
        then
                #configtools CONFIGTOOLS_MSG_TIME_CHANGED
                CONFIGTOOLS_MSG_TIME_CHANGED="8198"
        fi

        $NTP_START_UP_CMD
        sockmsg_send -d ${APP_DST_ID} -m ${CONFIGTOOLS_MSG_TIME_CHANGED} 1>/dev/null 2>/dev/null &
}

ntpd_sync


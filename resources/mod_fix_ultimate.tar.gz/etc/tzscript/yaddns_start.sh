#!/bin/sh

CFG_CMD=mdlcfg
CONF_FILEPATH=/tmp/yaddns.conf
STATUS_FLAG_FILEPATH=/tmp/yaddns_update_status
STATUS_SUCCESS="success"
MYIP_HOST=
MYIP_PATH=

YADDNS_SW=`$CFG_CMD -g USR_DDNS_SW`
YADDNS_SERVER=`$CFG_CMD -g USR_DDNS_SERVER`
YADDNS_USERNAME=`$CFG_CMD -g USR_DDNS_USERNAME`
YADDNS_PWD=`$CFG_CMD -g USR_DDNS_PWD`
YADDNS_DOMAIN=`$CFG_CMD -g USR_DDNS_DOMAIN`
YADDNS_ST=`$CFG_CMD -g USR_DDNS_ST`

start_yaddns() {
	if [ "$YADDNS_SW" == "1" ];then
			killall -9 yaddns
			killall -9 yaddns_listen.sh
	        if [ -f "$CONF_FILEPATH" ];then
            		rm $CONF_FILEPATH
        	fi
		touch $CONF_FILEPATH
		echo -e 'wanifname = "seth_lte0"' >> $CONF_FILEPATH
	        echo -e 'mode = "direct"\n' >> $CONF_FILEPATH
        	echo 'myip_host = "'$MYIP_HOST'"' >> $CONF_FILEPATH
	        echo 'myip_path = "'$MYIP_PATH'"' >> $CONF_FILEPATH
        	echo 'myip_port = 80' >> $CONF_FILEPATH
	        echo -e 'myip_upint = 60\n' >> $CONF_FILEPATH
	        echo 'account {' >> $CONF_FILEPATH
        	if [ "$YADDNS_SERVER" == "dyndns" ];then
	        	echo -e '\tname = "dyndns"' >> $CONF_FILEPATH
	        elif [ "$YADDNS_SERVER" == "no-ip" ];then
        		echo -e '\tname = "no-ip"' >> $CONF_FILEPATH
	        elif [ "$YADDNS_SERVER" == "changeip" ];then
        		echo -e '\tname = "changeip"' >> $CONF_FILEPATH
		elif [ "$YADDNS_SERVER" == "duckdns" ];then
			echo -e '\tname = "duckdns"' >> $CONF_FILEPATH
        	fi
	        echo -e '\tservice = "'$YADDNS_SERVER'"' >> $CONF_FILEPATH
        	echo -e '\tusername = "'$YADDNS_USERNAME'"' >> $CONF_FILEPATH
	        echo -e '\tpassword = "'$YADDNS_PWD'"' >> $CONF_FILEPATH
        	echo -e '\thostname = "'$YADDNS_DOMAIN'"' >> $CONF_FILEPATH
	        echo -e '}\n' >> $CONF_FILEPATH
       		/usr/bin/yaddns > /dev/null 2>&1 &
		/etc/tzscript/yaddns_listen.sh > /dev/null 2>&1 &
	else
		killall -9 yaddns
		killall -9 yaddns_listen.sh
		$CFG_CMD -a USR_DDNS_ST=Disconnected
	fi
}

start_yaddns

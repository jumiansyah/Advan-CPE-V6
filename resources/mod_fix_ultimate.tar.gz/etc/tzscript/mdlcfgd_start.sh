#!/bin/sh


if [ -f "/mnt/data/etc/tzcfg/config_upgrade_flag" ];
then
	rm -f /mnt/data/etc/tzcfg/system_config.use
	rm -f /mnt/data/etc/tzcfg/config_upgrade_flag
fi

/usr/bin/mdlcfgd &

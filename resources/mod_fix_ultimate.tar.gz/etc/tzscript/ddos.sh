#!/bin/sh
##功能：DDOS的配置脚本

#set -x

ddos_func_sw=`mdlcfg -g USR_DDOS_FUNC_SW`
ddos_defence_syn_flood_sw=`mdlcfg -g USR_DDOS_DEFENCE_SYN_FLOOD_SW`

if [ "${ddos_func_sw}" = "1" ]; then
 
 if [ "${ddos_defence_syn_flood_sw}" = "1" ]; then
  #完成三次握手前不为任何一个连接分配任何资源，默认开
  sysctl -w net.ipv4.tcp_syncookies=1
  #synack重试次数，默认5
  sysctl -w net.ipv4.tcp_synack_retries=3
  #增加SYN队列长度，默认128
  sysctl -w net.ipv4.tcp_max_syn_backlog=2048
  #打开SYN Cookie 功能
  echo 1 > /proc/sys/net/ipv4/tcp_syncookies
 else
  #关闭SYN Cookie 功能
  echo 0 > /proc/sys/net/ipv4/tcp_syncookies
 fi
  
# if [ "${TZ_ENABLE_DEFENCE_PING_OF_DEATH}" = "yes" ]; then  
#  echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all
# else
#  echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all  
# fi
 
fi 
#!/bin/sh
##功能：xl2tpd的配置、启动脚本

#set -x

#tmp vpn config convert
/etc/tzscript/vpn_config_convert.sh

##default wan interface
default_wan_if=seth_lte0

# default l2tp interface
l2tp_interface=ppp0

CFG_CMD=mdlcfg

l2tp_status_id=206021
l2tp_get_ip_id=206022
l2tp_peer_ip_id=206023

##APN的NAT开关
apn_nat_sw=$($CFG_CMD -g USR_APN_NAT)

##VPN的NAT开关
vpn_nat_sw=$($CFG_CMD -g USR_VPN_NAT_SW)

##是否设置VPN为默认路由，0为否，1为是
vpn_default_route=$($CFG_CMD -g USR_VPN_DEFAULT_ROUTE)

pid_file=/tmp/.vpn_l2tp_sh.pid
pre_pid=$(cat $pid_file 2>/dev/null)
if [ -n "$pre_pid" ]; then
    devinfo $l2tp_status_id 0
    kill -9 $pre_pid
    killall xl2tpd
    killall pppd
    rm $pid_file
fi

#保存脚本进程ID
echo $$ >$pid_file

statusInit()
{
	ppp_state=0
	devinfo $l2tp_status_id 0
	devinfo $l2tp_get_ip_id 0
	devinfo $l2tp_peer_ip_id 0
}

l2tp_sw()
{
	##是否允许l2tp
	vpn_mode=$($CFG_CMD -g USR_VPN_MODE)
	vpn_sw=$($CFG_CMD -g USR_VPN_SW)
	if [ "${vpn_mode}" == "0" -a  "${vpn_sw}" == "1" ]; then
		xl2tp_enable=1
	else
		xl2tp_enable=0
	fi
}

xl2tpd_conf_preppare()
{
    ##是否允许xl2tp
    l2tp_sw

    if [ ${xl2tp_enable} != "1" ]; then
        statusInit
        exit 1
    fi

    ##l2tp客户端名称
    lac_name=lroute
    ##l2tp_bcp客户端名称
    lac_bcp_name=lbridge
    ##lns服务器IP
    lns_ip=$($CFG_CMD -g USR_L2TP_LNS_SERVER)
    ##ppp的用户名
    ppp_user_name=$($CFG_CMD -g USR_L2TP_AUTH_NAME)
    ##ppp的认证密码
    ppp_user_pass=$($CFG_CMD -g USR_L2TP_AUTH_PASS)
    ##MTU
    mtu=$($CFG_CMD -g USR_L2TP_MTU)
    ##是否进行调试, yes 进行调试；其他值不进行调试
    IsDebug=$1

    ##LNS存活检测
    checkalive=$($CFG_CMD -g USR_L2TP_LNS_CHECKALIVE)

    ##l2tp配置文件存放路径
    config_file_l2tp=/tmp/xl2tpd
    config_ppp_resolv=/tmp/ppp
    ##l2tp客户端配置文件
    config_file_l2tpc=${config_file_l2tp}/xl2tpd.conf
    ##ppp服务配置文件
    config_file_ppp=${config_file_l2tp}/options.l2tpd.lac
    ##ppp_bcp服务配置文件
    config_file_ppp_bcp=${config_file_l2tp}/options.l2tpd.lac.noip
    ##
    xl2tp_control_file=/var/run/xl2tpd
    xl2tp_control=${xl2tp_control_file}/l2tp-control
    ##隧道认证密码文件
    file_l2tp_secrets=${config_file_l2tp}/l2tp-secrets
}

##xl2tpd的配置
xl2tpConfig()
{
	##删除原有的旧配置文件
	rm -rf ${config_file_l2tpc}
	rm -rf ${config_file_ppp}
	rm -rf ${file_l2tp_secrets}
	rm -rf ${config_file_ppp_bcp}
	rm -rf ${config_ppp_resolv}/resolv.conf

    #关闭软件加速
    echo 0 > /proc/net/sfp/enable

#------------------- xl2tpd.conf [lobal] 段参数 ---------------------------------------------------

#	echo "[global]" >> ${config_file_l2tpc}
#	echo "debug network = yes" >> ${config_file_l2tpc}
#	echo "debug tunnel = yes" >> ${config_file_l2tpc}
#	echo "debug avp = yes" >> ${config_file_l2tpc}
#	echo "force userspace = yes" >> ${config_file_l2tpc}

#-------------------- xl2tpd.conf lac[lroute] 段参数 -----------------------------------------------

#	echo "" >> ${config_file_l2tpc}
	echo "[lac ${lac_name}]" >> ${config_file_l2tpc}
	##xl2tp服务器
	echo "lns = ${lns_ip}" >> ${config_file_l2tpc}
	##ppp服务需要的配置文件
	echo "pppoptfile = ${config_file_ppp}" >> ${config_file_l2tpc}
	##当连接断开后，自动进行拨号
	echo "redial = yes" >> ${config_file_l2tpc}
	##自动拨号间隔时间,单位为秒
	echo "redial timeout = 15" >> ${config_file_l2tpc}
	##自动拨号
	echo "autodial = yes" >> ${config_file_l2tpc}	
	##是否进行调试
	if [ "${IsDebug:=no}" == "yes" ]; then
		echo "ppp debug = yes" >> ${config_file_l2tpc}
	fi

#-------------------- xl2tpd 的ppp配置文件 (/tmp/xl2tpd/options.l2tpd.lac) -------------------------------------

	##开始往ppp配置文件中写入配置
	##pppd将会接受彼端对於本地IP位址的意见，即使本地的IP位址已经在某个选项中指定
	echo "ipcp-accept-local" >> ${config_file_ppp} 
	##pppd将会接受彼端对於它的IP位址的意见，即使远端的IP位址已经在某个选项中指定
	echo "ipcp-accept-remote" >> ${config_file_ppp} 
	##拒绝使用EAP认证
	echo "refuse-eap" >> ${config_file_ppp} 
	##不要求对方认证自己
	echo "noauth" >> ${config_file_ppp} 
	echo "mtu ${mtu:=1410}" >> ${config_file_ppp} 
	##最大接收单元, 对于VPN, 设置为1410 mru范围在128-1500
	echo "mru ${mtu:=1410}" >> ${config_file_ppp}
	##使用VPN拨号提供的DNS服务
	#echo "usepeerdns" >> ${config_file_ppp}
	echo "debug" >> ${config_file_ppp}
	##ppp的用户名
	echo "name ${ppp_user_name}" >> ${config_file_ppp}
	##ppp的认证密码
	echo "password ${ppp_user_pass}" >> ${config_file_ppp} 
	if [ "${checkalive}" == "1" ]; then
		##pppd每秒将会送出一个LCP回应要求(echo-request)封包(frame)给彼端。
		echo "lcp-echo-interval 10 " >> ${config_file_ppp} 
		##如果传送n个LCP回应要求没有接收到有效的LCP回应回覆的话pppd将会推测彼端是死掉的。
		##如果发生这种情形，pppd将会终结该连线。这个选项的使用要求一个非零的lcp-echo-interval参数值
		echo "lcp-echo-failure 30" >> ${config_file_ppp} 
	else
		echo "lcp-echo-interval 0 " >> ${config_file_ppp}
		echo "lcp-echo-failure 0" >> ${config_file_ppp}  
	fi
	echo "usepeerdns" >> ${config_file_ppp}
	##是否进入调试
	if [ "${IsDebug:=no}" == "yes" ]; then
		echo "debug" >> ${config_file_ppp} 
	fi
}

get_default_route()
{
	route_str=$(route -n | grep ${l2tp_interface} -v | awk '{if($1 == "0.0.0.0"){printf("%s %s %s %s\n",$2,$3,$5,$8)}}')
	default_route_gateway=$(echo $route_str | awk '{print $1}')
	default_route_netmask=$(echo $route_str | awk '{print $2}')
	default_wan_if=$(echo $route_str | awk '{print $4}')
}

xl2tpdstart()
{
	#开启l2tp服务
	if [ -z "$(pidof xl2tpd)" ]; then
		xl2tpd -c ${config_file_l2tpc} -C ${xl2tp_control} &
		sleep 3 
	fi
}

xl2tpconnect()
{
	echo "c ${lac_name}" > ${xl2tp_control}
	sleep 3
}

xl2tpdisnect()
{
	echo "d ${lac_name}" > ${xl2tp_control}
	sleep 3
}

pppstatus()
{
	ppp_iface=${l2tp_interface}

	if [ -n "${ppp_iface}" -a -n "$(ifconfig | grep ${default_wan_if})" ]; then
		#获取对端地址
		ppp_peer_ip=$(ifconfig ${ppp_iface} | grep 'P-t-P:' | awk -F: '{print $3}' | awk -F' ' '{print $1}')

		if [ -n "${ppp_peer_ip}" ]; then
			ppp_state=1
			devinfo $l2tp_status_id 1
			devinfo $l2tp_peer_ip_id ${ppp_peer_ip}
        	else
        		ppp_state=0
			devinfo $l2tp_status_id 0
			devinfo $l2tp_peer_ip_id 0
		fi

		#$CFG_CMD -f TZ_L2TP_PEER_IP=${ppp_peer_ip}
		ppp_get_ip=$(ifconfig ${ppp_iface} | grep 'inet addr:' | awk -F: '{print $2}' | awk -F' ' '{print $1}')
		if [ -n "${ppp_get_ip}" ]; then
			devinfo $l2tp_get_ip_id ${ppp_get_ip}
		else
            		devinfo $l2tp_get_ip_id 0
        	fi
	else
		statusInit
	fi
}

ALLNatDef()
{
    if [ "${apn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${default_wan_if}) ]; then
        iptables -t nat -A POSTROUTING -o ${default_wan_if} -j MASQUERADE
    fi
    if [ "${vpn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${l2tp_interface}) ]; then
        iptables -t nat -A POSTROUTING -o ${l2tp_interface} -j MASQUERADE
    fi
}

WANNatDef()
{
	if [ "${apn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${default_wan_if}) ]; then
		iptables -t nat -A POSTROUTING -o ${default_wan_if} -j MASQUERADE
	fi
	if [ -n $(iptables -t nat -S POSTROUTING | grep ${l2tp_interface}) ]; then
		iptables -t nat -D POSTROUTING -o ${l2tp_interface} -j MASQUERADE
	fi
}

PPPRouteDef()
{
    if [ "${vpn_default_route}" = "1" -a -z "$(ip route | grep default | grep $l2tp_interface)" ]; then
        get_default_route
        if [ -n "${default_wan_if}" -a -z "$(ip route | grep ${lns_ip})" ];then
            ip route add ${lns_ip}/32 via ${default_route_gateway} dev ${default_wan_if} 2>/dev/null
        fi
        ip route del default
        ip route add default dev ${default_wan_if} via ${default_route_gateway} metric 1 2>/dev/null
        ip route add default dev ${l2tp_interface} via ${ppp_peer_ip}
    fi
}

#更新静态路由表
firewall_route_update()
{
    firewalltoolc -g
    firewalltoolc -a route
}

WANRouteDef()
{
	get_default_route
	if [ -z "$(ip route | grep default | grep $default_wan_if)" ]; then
		echo 1 > /proc/net/sfp/enable
		statusInit
		ip route del default
		ip route del default metric 1 2>/dev/null
		ip route add default dev ${default_wan_if} via ${default_route_gateway} 2>/dev/null
		firewalltoolc -g 
		firewalltoolc -a firewall
	fi
}

main()
{
    # xl2ptd 参数准备
    xl2tpd_conf_preppare
        
    ##创建l2tp配置文件存放路径
    if [ ! -d "${config_file_l2tp}" ]; then
        mkdir -p ${config_file_l2tp}
    fi

    if [ ! -d "${xl2tp_control_file}" ]; then
        mkdir -p ${xl2tp_control_file}
    fi

    if [ ! -d "${config_ppp_resolv}" ]; then
        mkdir -p ${config_ppp_resolv}
    fi

    # xl2tpd启动前默认路由及nat配置
    WANRouteDef
    WANNatDef
	
    ##配置
    xl2tpConfig

    ##启动服务
    xl2tpdstart

    ##进行连接
    xl2tpconnect

    ##ppp状态检查
    while [ 1 ]
    do
        ##获取ppp当前状态
        pppstatus
	devinfo $l2tp_status_id ${ppp_state}
        if [ "${ppp_state}" = "1" ]; then
            if [ ${routechecktime:=6} -gt 3 ]; then
                #每隔30秒检查一次路由，看路由是否会出问题
	    		PPPRouteDef
	    		ALLNatDef
	    		routechecktime=0;
	    	fi
	    	routechecktime=$((${routechecktime} + 1))
	    	if [ "${is_static_route_update:=1}" = "1"  ];then
	    		firewall_route_update
	    		is_static_route_update=0
	    	fi
        else
		is_static_route_update=1
		WANRouteDef
		WANNatDef
			
		# 断线重连
		xl2tpdstart
		xl2tpdisnect
		xl2tpconnect
        fi
	
        sleep 10
    done
}

main $@

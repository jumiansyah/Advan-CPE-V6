#!/bin/sh

vpcie="eth0"

delete_gw()
{
        ip_of_br0=`mdlcfg -g USR_DHCP_LAN_IP`
        route -n |grep ${ip_of_br0}
        need_del_default_gw=`echo $?`
        if [ "$need_del_default_gw" == "0" ]; then
                route del default gw ${ip_of_br0}
        fi
}

listen_eth0_state()
{
	state="0"
	#state is init.	
	need_flush_firewall="1"
	
	killall udhcpc
	ifconfig $vpcie down
	delete_gw
	/sbin/udhcpc -i $vpcie >/dev/null 2>&1 &

	while :
	do
		sleep 1

		ifconfig eth0 | grep "RUNNING"
		vpcie_state=`echo $?`

		ps | grep "udhcpc" | grep -v "grep"
		udhcpc_state=`echo $?`

		if [[ "$vpcie_state" == "0" && "$udhcpc_state" == "0" ]]; then
			#echo "eth0 and udhcpc are running,state is working."
			state="1"
			if [ $need_flush_firewall == "1" ]; then
                                route |grep "default" |grep "eth0"
                                can_flush_firewall=`echo $?`
                                if [ $can_flush_firewall == "0" ]; then
                                        firewalltoolc -g
                                        firewalltoolc -a firewall
                                        need_flush_firewall="0"
                                fi
                        fi
        	elif [[ "$vpcie_state" != "0" && "$udhcpc_state" == "0" && "$state" == "1" ]]; then
			#echo "eth0 is not running and udhcpc is running.state is disconnect."
			state="2"
			killall udhcpc
			ifconfig $vpcie down
			delete_gw
			/sbin/udhcpc -i $vpcie >/dev/null 2>&1 &
		elif [[ "$vpcie_state" != "0" && "$udhcpc_state" == "0" && "$state" != "1" ]]; then
			#echo "eth0 is not running and udhcpc isrunning.state is connecting."
			state="3"
		fi
	done
}

listen_eth0_state


#!/bin/sh

CFG_CMD=mdlcfg

TIMER_REBOOT_SW=`$CFG_CMD -g USR_TIMER_REBOOT_SW`

start_timer_reboot() {
	killall -9 timer_reboot
	if [ "$TIMER_REBOOT_SW" == "1" ];then
		cd /usr/bin/
		./timer_reboot
		echo "1" > /tmp/timer_reboot_sw
	else
		killall -9 timer_reboot
		echo "0" > /tmp/timer_reboot_sw
	fi
}

start_timer_reboot

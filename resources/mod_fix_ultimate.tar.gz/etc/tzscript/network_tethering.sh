#!/bin/sh

selfIp=192.168.0.1
dnsStartIp=192.168.0.100
dnsEndIp=192.168.0.100

## echo "================= =" >> $logpath
## echo "data_cfg.sh start s1=$1 s2=$2 s3=$3" >> $logpath
## echo "----------------- -" >> $logpath

exec_cmd() {
    local cmd="$@"
    eval $cmd 2>&1
}
modify_dns_filter() {
    local action=$1

    for ipt in "iptables" "ip6tables"; do
        for chn in FORWARD INPUT OUTPUT; do
            exec_cmd "$ipt -w $action $chn -p udp --dport 53 -j DROP"
        done
    done
}
modify_mld_filter() {
    local action=$1

    exec_cmd "ip6tables -w $action OUTPUT -p icmpv6 --icmpv6-type 143 -j DROP"
}
pre_ifup() {
    echo "pre_ifup"
}
ifup4() {
    local iface=$1
    local ip=$2


    exec_cmd "ip link set $iface up"
    exec_cmd "ip link set dev $iface arp off"
    exec_cmd "ip addr add $ip/32 dev $iface"

    exec_cmd "ip route add default dev $iface table 67"
    exec_cmd "ip route add default dev $iface table main"
    exec_cmd "ip rule add oif $iface table 67 pref 68"
}
ifupv6() {
    local iface=$1
    local ip=$2


    exec_cmd "ip link set $iface up"

    exec_cmd "ip link set dev $iface arp off"
    exec_cmd "ip -6 addr add $ip/64 dev $iface"

#    exec_cmd "ip -6 route add default via fe80::1 dev $iface proto ra table 67"
    exec_cmd "ip -6 route add default dev $iface table main"
    exec_cmd "ip -6 rule add oif $iface table 67 pref 68"
}
ifup() {


    if [ "$1" == "4" ]; then
      ifup4 $2 $3;
    elif [ "$1" == "6" ]; then
      ifupv6 $2 $3;
    else
      echo "$0 invalid ip type: $1"
    fi
}
create_config_radvd() {
    local ip=$1
    local dns=$2
    local tether_iface=$3


    local VALID_TIME="3600"
    local PREFER_TIME="3600"
    local PREFIX=$ip
    local PRELEN="64"
    local OLD_RADVD_PD="/tmp/.old_radvd_info"

    if [ -f "/tmp/radvd.conf" ]; then
        rm /tmp/radvd.conf;
    fi
    echo -e "interface $tether_iface\n{\n\tAdvSendAdvert on;\n\tMinRtrAdvInterval 3;\n\tMaxRtrAdvInterval 10;\n\tAdvManagedFlag off;\n\tAdvOtherConfigFlag on;" >> /tmp/radvd.conf
 
    PD_INFO=$VALID_TIME" "$PREFER_TIME" "$PREFIX" "$PRELEN
    echo -e $PD_INFO >$OLD_RADVD_PD

    echo -e "\tprefix $ip/64" >> /tmp/radvd.conf
    echo -e "\t{\n\t\tAdvOnLink off;\n\t\tAdvAutonomous on;\n\t\tAdvValidLifetime 3600;\n\t\tAdvPreferredLifetime 3600;\n\t\tAdvRouterAddr off;\n\t};" >> /tmp/radvd.conf  
    echo -e "\tRDNSS $dns" >> /tmp/radvd.conf
    echo -e "\t{\n\t\tAdvRDNSSPreference 8;\n\t\tAdvRDNSSLifetime 3600;\n\t};\n};" >> /tmp/radvd.conf

}
create_config_dhcp6s() {
    local dns6_1=$1
    local dns6_2=$2
    local iface=$3
    local prefix=$4

    if [ -f "/tmp/dhcp6s.conf" ]; then
        rm /tmp/dhcp6s.conf;
    fi

    echo -e "option domain-name-servers $dns6_1;\n" > /tmp/dhcp6s.conf
    echo -e "option domain-name-servers $dns6_2;\n" >> /tmp/dhcp6s.conf
    echo -e "interface $3 {\n" >> /tmp/dhcp6s.conf
    echo -e "address-pool pool1 3600;\n" >> /tmp/dhcp6s.conf
    echo -e "};\n" >> /tmp/dhcp6s.conf
    echo -e "pool pool1 {\n" >> /tmp/dhcp6s.conf
    echo -e "range ${prefix}::64 to ${prefix}::fa;\n" >> /tmp/dhcp6s.conf
    echo -e "};\n" >> /tmp/dhcp6s.conf

    #echo -e "12345" >> /tmp/dhcp6s.pid
}
tether4() {
    local tether_iface=$1
    local iface=$2
    local ip=$3
    local dns=$4


    exec_cmd "iptables -w -t nat -F"
    exec_cmd "mkdir /usr/dhcp"
    exec_cmd "chmod 777 /usr/dhcp"

    exec_cmd "ip link set $tether_iface up"
    exec_cmd "ip addr add $selfIp/24 dev $tether_iface"

    exec_cmd "ip rule add iif $tether_iface table 67 pref 69"
    exec_cmd "echo 1 > /proc/sys/net/ipv4/ip_forward"
    exec_cmd "echo 1 > /proc/net/sfp/enable"

    exec_cmd "iptables -w -t nat -A POSTROUTING -o $iface -j MASQUERADE"

    exec_cmd "dnsmasq -v '0xf0064|$dns' --keep-in-foreground --no-resolv --no-poll --dhcp-authoritative --dhcp-option-force=43,ANDROID_METERED --pid-file --dhcp-range=$dnsStartIp,$dnsEndIp,10h&"
}

getpostfix() {
    ifconfig $1 | grep "inet6" | awk -F' ' '{print $3}' | awk -F'::' '{print $2}' | awk -F'/' '{print $1}' | awk -F '%' '{print $1}' | awk 'BEGIN{ORS=" "}{print $0}' | sed 's/[[:space:]]//g'
}

getprefix() {
    ifconfig $1 | grep "Global" | awk -F' ' '{print $3}' | awk -F':' '{print $1,$2,$3,$4}' | awk -F' ' '{print $1":"$2":"$3":"$4}' | awk 'BEGIN{ORS=" "}{print $0}' | sed 's/[[:space:]]//g'
}

tether6() {
    local tether_iface=$1
    local iface=$2
    local ip=$3
    local dns="$4"


    exec_cmd "ip link set $tether_iface up"

    local prefix=$(getprefix $2)
    local postfix=$(getpostfix $1)
    local iface_postfix=$(getpostfix $iface)

    while true
    do
    if [ ! $postfix ]; then
        sleep 1
        postfix=$(getpostfix $1)
    else
        break;
    fi
    done

    while true
    do
    if [ ! $prefix ]; then
        sleep 1
        prefix=$(getprefix $2)
    else
        break;
    fi
    done

    while true
    do
    if [ ! $iface_postfix ]; then
        sleep 1
        iface_postfix=$(getpostfix $iface)
    else
        break;
    fi
    done

    exec_cmd "echo 1 > /proc/sys/net/ipv6/conf/all/forwarding"

    echo "===radvd.conf===="
    cat /tmp/radvd.conf
    echo "===radvd.conf===="

    echo "===radvd.pid===="
    cat /tmp/radvd.pid
    echo "===radvd.pid===="

    create_config_radvd "$prefix::" "$dns" $1

    exec_cmd "radvd -C /tmp/radvd.conf -p /tmp/radvd.pid -d 0"
    echo "ip = $ip"
    local dns6_1=$(echo $dns | awk -F' ' '{print $1}')
    local dns6_2=$(echo $dns | awk -F' ' '{print $2}')
    echo "dns1=$dns6_1"
    echo "dns2=$dns6_2"
    create_config_dhcp6s $dns6_1 $dns6_2 $tether_iface $prefix
    exec_cmd "dhcp6s -c /tmp/dhcp6s.conf -k /tmp/dhcp6s.ctl -P /tmp/dhcp6s.pid -f $tether_iface &"
    exec_cmd "devinfo 201009 $prefix:$iface_postfix  2>/dev/null 1>/dev/null"
}
tether4_auto() {
    local tether_iface=$1
    local iface=$2
    local ip=$3
    local dns=$4

    exec_cmd "iptables -w -t nat -F"
    exec_cmd "mkdir /usr/dhcp"
    exec_cmd "chmod 777 /usr/dhcp"

    exec_cmd "ip link set $tether_iface up"
    exec_cmd "ip addr add $selfIp/24 dev $tether_iface"

    exec_cmd "ip rule add iif $tether_iface table 67 pref 69"
    exec_cmd "echo 1 > /proc/sys/net/ipv4/ip_forward"
    exec_cmd "echo 1 > /proc/net/sfp/enable"

    exec_cmd "iptables -w -t nat -A PREROUTING -i $iface -j DNAT --to-destination $dnsStartIp"
    exec_cmd "iptables -w -t nat -A POSTROUTING -s $dnsStartIp -j SNAT --to-source $ip"
    exec_cmd "dnsmasq -v '0xf0064|$dns' --keep-in-foreground --no-resolv --no-poll --dhcp-authoritative --dhcp-option-force=43,ANDROID_METERED --pid-file --dhcp-range=$dnsStartIp,$dnsEndIp,10h&"
}
tether() {


    if [ "$1" == "4" ]; then
      tether4 $2 $3 $4 $5;
    elif [ "$1" == "6" ]; then
      tether6 $2 $3 $4 "$5";
    else
      echo "$0 invalid ip type: $1"
    fi
}
tether_auto() {


    if [ "$1" == "4" ]; then
      tether4_auto $2 $3 $4 $5;
    elif [ "$1" == "6" ]; then
      tether6 $2 $3 $4 "$5";
    else
      echo "$0 auto mode invalid ip type: $1"
    fi
}
untether() {
    local tether_iface=$1


    exec_cmd "ip link set $tether_iface down"
    exec_cmd "ip addr flush dev $tether_iface"
    exec_cmd "ip rule del pref 69"
    exec_cmd "echo 0 > /proc/net/sfp/enable"
    exec_cmd "iptables -w -t nat -F"
    exec_cmd "pkill dnsmasq"
    exec_cmd "rm -rf /usr/dhcp"

    exec_cmd "ip -6 rule del pref 69"
    exec_cmd "pkill radvd"
    exec_cmd "pkill dhcp6s"
    exec_cmd "echo 0 > /proc/sys/net/ipv6/conf/all/forwarding"
    exec_cmd "echo 0 > /proc/net/sfp/enable"
}
ifdown() {
    local iface=$1


    exec_cmd "ip route del default dev $iface table main"
    exec_cmd "ip route del default dev $iface table 67"
    exec_cmd "ip rule del pref 68"

    exec_cmd "ip -6 route del default dev $iface table 67"
    exec_cmd "ip -6 route del default dev $iface table main"
    exec_cmd "ip -6 rule del pref 68"
    exec_cmd "ip addr flush dev $iface"
    exec_cmd "ip link set $iface down"
}

flush_ipv6_prefix() {
    if [ -f "/tmp/radvd.conf" ]; then
        sed -i 's/AdvValidLifetime.*/AdvValidLifetime 1;/g' /tmp/radvd.conf
        sed -i 's/AdvPreferredLifetime.*/AdvPreferredLifetime 1;/g' /tmp/radvd.conf
        killall radvd
        exec_cmd "radvd -C /tmp/radvd.conf -p /tmp/radvd.pid -d 0"
        sleep 1;
    fi
}

if [ "$1" == "pre_ifup" ]; then
 pre_ifup;
elif [ "$1" == "ifup" ]; then
 ifup $2 $3 $4 $5;
elif [ "$1" == "tether" ]; then
 tether $2 $3 $4 $5 "$6";
elif [ "$1" == "tether_auto" ]; then
 tether_auto $2 $3 $4 $5 "$6";
elif [ "$1" == "ifdown" ]; then
 ifdown $2;
elif [ "$1" == "untether" ]; then
 untether $2;
elif [ "$1" == "radvd" ]; then
 create_config_dhcp6s $2 $3;
elif [ "$1" == "dns_disable" ]; then
 modify_dns_filter "-D";
 modify_mld_filter "-D";
elif [ "$1" == "dns_enable" ]; then
 modify_dns_filter "-A";
 modify_mld_filter "-A";
elif [ "$1" == "flush_ipv6_prefix" ];then
 flush_ipv6_prefix $2;
fi

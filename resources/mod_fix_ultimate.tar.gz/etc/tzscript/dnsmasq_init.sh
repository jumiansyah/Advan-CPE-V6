#!/bin/sh

TEE_PRO="busybox tee -ai"
ECHO_PRO="echo"
DATA_PATH=/mnt/data
DATA_LOCAL_PATH=$DATA_PATH/local
LOG_PATH=$DATA_LOCAL_PATH/log
LOG_FILE=$LOG_PATH/mifi.log
WAN_IFACE=seth_lte0
BRIDGE_IFACE=br0

CFG_CMD=mdlcfg

/usr/bin/killall -9 dnsmasq

dnsmasq_restart()
{
	USR_DHCP_LAN_IP=`mdlcfg -g USR_DHCP_LAN_IP`
	USR_DHCP_SUBNET_MASK=`mdlcfg -g USR_DHCP_SUBNET_MASK`
	USR_DHCP_SERVER_SW=`mdlcfg -g USR_DHCP_SERVER_SW`
	USR_DHCP_PRIMARY_DNS=`mdlcfg -g USR_DHCP_PRIMARY_DNS`
	USR_DHCP_SECONDARY_DNS=`mdlcfg -g USR_DHCP_SECONDARY_DNS`
	USR_DHCP_START_IP=`mdlcfg -g USR_DHCP_START_IP`
	USR_DHCP_END_IP=`mdlcfg -g USR_DHCP_END_IP`
	USR_DHCP_LEASE_TIME=`mdlcfg -g USR_DHCP_LEASE_TIME`
	USR_DNS_LOCAL_DOMAIN=`mdlcfg -g USR_DNS_LOCAL_DOMAIN`
	USR_DHCP_MTU=`mdlcfg -g USR_DHCP_MTU`

	USR_DHCP_GW_IP=$USR_DHCP_LAN_IP
	SYS_IP_PASSTHROUGH_SW=`$CFG_CMD -g SYS_IP_PASSTHROUGH_SW`
	USR_IP_PASSTHROUGH_WAN_IP=`devinfo 201004`

	if [ "${USR_DHCP_LAN_IP}" = "" ];
	then
		USR_DHCP_LAN_IP="192.168.0.1"
	fi

	if [ "${USR_DHCP_SUBNET_MASK}" = "" ];
        then
                USR_DHCP_SUBNET_MASK="255.255.255.0"
        fi

	if [ "${USR_DHCP_MTU}" = "" ]
	then
		USR_DHCP_MTU="1500"
	fi

	if [ "${USR_DHCP_PRIMARY_DNS}" = "" ]; then
		USR_DHCP_PRIMARY_DNS="${USR_DHCP_LAN_IP}"
	fi

	if [ "${USR_DHCP_SECONDARY_DNS}" = "" ]; then
		USR_DHCP_SECONDARY_DNS="114.114.114.114"
	fi

	if [ "${SYS_IP_PASSTHROUGH_SW}" = "1" -a "${USR_IP_PASSTHROUGH_WAN_IP}" != "" ]
	then
		mkdir -p /var/lib/misc/
		touch /var/lib/misc/udhcpd.leases
		USR_DHCP_START_IP=${USR_IP_PASSTHROUGH_WAN_IP}
		USR_DHCP_END_IP=${USR_IP_PASSTHROUGH_WAN_IP}
		USR_DHCP_SUBNET_MASK=255.255.255.255
		#USR_DHCP_PRIMARY_DNS=202.96.134.133
		USR_DHCP_GW_IP=`echo $USR_IP_PASSTHROUGH_WAN_IP | awk 'BEGIN{FS=OFS="."}{$NF=1;print}'`
	fi

	DNSMASQ_CONF_FILE=/tmp/dnsmasq.conf
	UDHCPD_CONF_FILE=/tmp/udhcpd.conf

	if [ "${SYS_IP_PASSTHROUGH_SW}" = "1" -a "${USR_IP_PASSTHROUGH_WAN_IP}" != "" ]
	then

		local_ip=${USR_DHCP_LAN_IP}
		#ip link set $BRIDGE_IFACE down 2>/dev/null
		#ip addr flush dev $BRIDGE_IFACE 2>/dev/null
		ip rule del iif $BRIDGE_IFACE table 67 pref 69 2>/dev/null
<<DHCP_NO_USE
		rm -rf /mnt/data/var/conf/dhcp
		mkdir -p /mnt/data/var/conf/dhcp
		chmod 777 /mnt/data/var/conf/dhcp
DHCP_NO_USE
		killall dnsmasq 1>/dev/null 2>/dev/null
		killall udhcpd 1>/dev/null 2>/dev/null
		#ip link set $BRIDGE_IFACE up

	#add wan ip on br0, and set udhcpd config
		$ECHO_PRO "ip addr add ${local_ip}/32 dev $BRIDGE_IFACE" | $TEE_PRO $LOG_FILE
		#ip addr add ${local_ip}/32 dev $BRIDGE_IFACE
		#ip addr add 192.168.0.1/24 dev $BRIDGE_IFACE

		USR_DHCP_PRIMARY_DNS=`devinfo 201007`
		USR_DHCP_SECONDARY_DNS=`devinfo 201008`

		echo "start ${USR_DHCP_START_IP}" > ${UDHCPD_CONF_FILE}
		echo "end ${USR_DHCP_END_IP}" >> ${UDHCPD_CONF_FILE}
		echo "interface ${BRIDGE_IFACE}" >> ${UDHCPD_CONF_FILE}
		echo "option subnet ${USR_DHCP_SUBNET_MASK}" >> ${UDHCPD_CONF_FILE}
		echo "opt router ${USR_DHCP_LAN_IP}" >> ${UDHCPD_CONF_FILE}
		echo "option dns ${USR_DHCP_PRIMARY_DNS} ${USR_DHCP_SECONDARY_DNS}" >> ${UDHCPD_CONF_FILE}
		echo "option domain local" >> ${UDHCPD_CONF_FILE}
		#echo "option lease ${USR_DHCP_LEASE_TIME}" >> ${UDHCPD_CONF_FILE}
	#add wan ip on br0, and set udhcpd config

		ip rule add iif $BRIDGE_IFACE table 67 pref 69
		ip link set $WAN_IFACE down 2>/dev/null
		#ip route del default dev $WAN_IFACE table 67 2>/dev/null
		ip route del default dev $WAN_IFACE table main 2>/dev/null
		ip rule del oif $WAN_IFACE table 67 pref 68 2>/dev/null
		ip link set $WAN_IFACE up
		ip link set dev $WAN_IFACE arp off
		#ip route add default dev $WAN_IFACE table 67
		ip route add default dev $WAN_IFACE table main
		ip rule add oif $WAN_IFACE table 67 pref 68
	fi

	bridge_iface=br0
	echo 1 > /proc/sys/net/ipv4/ip_forward

	touch /mnt/data/etc/tzcfg/dhcp_hosts

cat > ${DNSMASQ_CONF_FILE} <<EOF
user=root
group=root
interface=br0
listen-address=${USR_DHCP_LAN_IP}
listen-address=127.0.0.1
dhcp-leasefile=/tmp/dnsmasq.leases
resolv-file=/tmp/resolv.conf
dhcp-hostsfile=/mnt/data/etc/tzcfg/dhcp_hosts
#strict-order
pid-file
dhcp-range=${USR_DHCP_START_IP},${USR_DHCP_END_IP},${USR_DHCP_SUBNET_MASK},${USR_DHCP_LEASE_TIME}
dhcp-lease-max=250
dhcp-option=option:router,${USR_DHCP_LAN_IP}
dhcp-option=option:dns-server,${USR_DHCP_PRIMARY_DNS},${USR_DHCP_SECONDARY_DNS}
dhcp-option=option:mtu,${USR_DHCP_MTU}
keep-in-foreground
dhcp-authoritative
#dns
address=/${USR_DNS_LOCAL_DOMAIN}/${USR_DHCP_LAN_IP}
EOF
	if [ -f "/mnt/data/etc/tzcfg/ip_mac_binding" ];then
		/usr/bin/tzlisten add_dnsmasq_config &
	fi
	if [ "${USR_DHCP_SERVER_SW}" = "1" ]
	then
		if [ "${SYS_IP_PASSTHROUGH_SW}" = "1" -a "${USR_IP_PASSTHROUGH_WAN_IP}" != "" ]
		then
			ip route add ${USR_IP_PASSTHROUGH_WAN_IP}/32 dev ${BRIDGE_IFACE}
			udhcpd ${UDHCPD_CONF_FILE} -f &
		else
			dnsmasq -C ${DNSMASQ_CONF_FILE} -x /tmp/dnsmasq.pid &
		fi
	fi
}

dnsmasq_restart

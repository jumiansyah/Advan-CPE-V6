#!/bin/sh

DESC="mini-httpd"
set -e

mh_pro=/usr/bin/mini_httpd
mh_conf=/tmp/mini_httpd.conf
mhs_conf=/tmp/mini_httpsd.conf

do_start() {

enable=`mdlcfg -g REMOTE_LOGIN_ENABLE`
if [ $enable == "1" ]; then
	port1=`mdlcfg -g REMOTE_LOGIN_PORT`
	if [ -z $port1 ]; then
		port1="80"
	fi
else
	port1="80"
fi
cat >$mh_conf <<EOF
user=root
port=$port1
dir=/tzwww
cgipat=cgi-bin/*
pidfile=/tmp/mini_httpd.pid
logfile=/tmp/mini_httpd.log
charset=UTF-8
EOF

cat >$mhs_conf <<EOF
user=root
dir=/tzwww
cgipat=cgi-bin/*
pidfile=/tmp/mini_httpsd.pid
logfile=/tmp/mini_httpsd.log
charset=UTF-8
ssl
certfile=/usr/bin/mini_httpd.pem
EOF

$mh_pro -C $mh_conf 2>/dev/null &
$mh_pro -C $mhs_conf 2>/dev/null &
}

do_stop() {
	killall mini_httpd 1>/dev/null 2>/dev/null
}

case "$1" in
  start)
        echo "Starting $DESC"
        do_start
        ;;
  stop)
        echo "Stopping $DESC"
        do_stop
        ;;
  restart|force-reload)
        echo "Restarting $DESC"
        do_stop
        sleep 1
        do_start
        ;;
  *)
        echo "Usage: $0 {start|stop|restart|force-reload}" >&2
        exit 1
        ;;
esac

exit 0

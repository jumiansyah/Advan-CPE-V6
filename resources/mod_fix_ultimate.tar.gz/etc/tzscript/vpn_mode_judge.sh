#!/bin/sh
CFG_CMD=mdlcfg
vpn_mode=$($CFG_CMD -g USR_VPN_MODE)
vpn_sw=$($CFG_CMD -g USR_VPN_SW)
if [ "${vpn_sw}" == "1" ]; then
	if [ "${vpn_mode}" == "0" ]; then
		/etc/tzscript/xl2tpd.sh &
	else
		/etc/tzscript/pptp.sh &
	fi
fi

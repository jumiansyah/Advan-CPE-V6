#!/bin/sh
##功能：pptp的配置、启动脚本

#set -x

CFG_CMD=mdlcfg

pptp_status_id=206021
pptp_get_ip_id=206022
pptp_peer_ip_id=206023

statusInit()
{
	pptp_state=0
	devinfo $pptp_status_id 0
	devinfo $pptp_get_ip_id 0
	devinfo $pptp_peer_ip_id 0
}

pptp_sw()
{
	##是否允许pptp
	vpn_mode=$($CFG_CMD -g USR_VPN_MODE)
	vpn_sw=$($CFG_CMD -g USR_VPN_SW)
	if [ "${vpn_mode}" == "1" -a  "${vpn_sw}" == "1" ]; then
		pptp_enable=1
	else
		pptp_enable=0
	fi
}

pid_file=/tmp/.vpn_pptp_sh.pid
pre_pid=$(cat $pid_file 2>/dev/null)
if [ -n "$pre_pid" ]; then
    devinfo $pptp_status_id 0
    kill -9 $pre_pid
    killall pppd
    rm $pid_file
fi

#检查开关
pptp_sw

if [ "${pptp_enable}" != "1" ]; then
	statusInit
	exit 1
fi

echo $$ >$pid_file

##APN的NAT开关
apn_nat_sw=$($CFG_CMD -g USR_APN_NAT)

##VPN的NAT开关
vpn_nat_sw=$($CFG_CMD -g USR_VPN_NAT_SW)
##设置VPN为默认路由
vpn_default_route=$($CFG_CMD -g USR_VPN_DEFAULT_ROUTE)

##pptp服务器IP
pptp_server=$($CFG_CMD -g USR_PPTP_SERVER)
##pptp的用户名
pptp_user_name=$($CFG_CMD -g USR_PPTP_AUTH_NAME)
##pptp的认证密码
pptp_user_pass=$($CFG_CMD -g USR_PPTP_AUTH_PASS)
##MTU
pptp_mtu=$($CFG_CMD -g USR_PPTP_MTU)
##default wan interface
default_wan_if=seth_lte0
default_route_gateway=0.0.0.0
default_route_netmask=0.0.0.0
pptp_peer_ip=0.0.0.0
##pptp配置文件存放路径
config_path_peerfiles=/tmp/ppp/peers
real_config_path_peerfiles=/etc/ppp/peers
##pptp客户端配置文件
config_file_pptp=${config_path_peerfiles}/pptp_vpn_client
real_config_file_pptp=${real_config_path_peerfiles}/pptp_vpn_client
##pptp的ifname
pptp_vpn_ifname=ppp0

pptpConfig()
{
	##开始往pptp配置文件中写入配置
	echo "pty \"pptp ${pptp_server} --nolaunchpppd\"" > ${config_file_pptp}
	
	echo "name \"${pptp_user_name}\"" >> ${config_file_pptp}
	echo "password \"${pptp_user_pass}\"" >> ${config_file_pptp}
	echo "mtu ${pptp_mtu:=1400}" >> ${config_file_pptp} 
	##最大接收单元, 对于VPN, 设置为1410 mru范围在128-1460
	echo "mru ${pptp_mtu:=1400}" >> ${config_file_pptp}
	##不要求对端认证自己
	echo "noauth" >> ${config_file_pptp}
	##LCP回响
	echo "lcp-echo-interval 20" >> ${config_file_pptp}
	echo "lcp-echo-failure 3" >> ${config_file_pptp}
	##网络接口名
	#echo "ifname ${pptp_vpn_ifname}" >> ${config_file_pptp}
	echo "usepeerdns" >> ${config_file_pptp}
	echo "noipdefault" >> ${config_file_pptp}
	##断线重拨,默认10次
	echo "persist" >> ${config_file_pptp}
	##0失败一直重拨,default 10次
	echo "maxfail 0" >> ${config_file_pptp}
	#echo "debug" >> ${config_file_pptp}

	mount -o remount,rw /
	if [ ! -d "${config_path_peerfiles}" ]; then
		mkdir -p ${real_config_path_peerfiles}
	fi
	cp ${config_file_pptp} ${real_config_file_pptp}
	
	mount -o remount,ro /

}

get_default_route()
{
    route_str=$(route -n | grep ${pptp_vpn_ifname} -v | awk '{if($1 == "0.0.0.0"){printf("%s %s %s %s\n",$2,$3,$5,$8)}}')
    default_route_gateway=$(echo $route_str | awk '{print $1}')
    default_route_netmask=$(echo $route_str | awk '{print $2}')
    default_wan_if=$(echo $route_str | awk '{print $4}')
}

pptpstart()
{
    ##停止pptp服务
    if [ -n "$(ps | grep pppd | grep pptp_vpn_client)" ]; then
    	killall pppd
    	sleep 1
    fi
    ##重启pptp服务
    pppd call pptp_vpn_client >/dev/null 2>&1 &
    sleep 5 
}

pptpstatus()
{
	if [ -n "$(ip link | grep ^[0-9] | awk -F: '{print $2}' | grep ${pptp_vpn_ifname})" -a -n "$(ifconfig | grep ${default_wan_if})" ]; then
		#获取对端地址
		pptp_peer_ip=$(ifconfig ${pptp_vpn_ifname} | grep 'P-t-P:' | awk -F: '{print $3}' | awk -F' ' '{print $1}')

		devinfo $pptp_status_id ${pptp_state:=0}
		pptp_get_ip=$(ifconfig ${pptp_vpn_ifname} | grep 'inet addr:' | awk -F: '{print $2}' | awk -F' ' '{print $1}')

		if [ -n "${pptp_get_ip}" ]; then
			pptp_state=1
			devinfo $pptp_status_id 1
		else
			pptp_state=0
			devinfo $pptp_status_id 0
		fi

		devinfo $pptp_get_ip_id ${pptp_get_ip:=0}
		devinfo $pptp_peer_ip_id ${pptp_peer_ip:=0}
	else
		statusInit
	fi
}

ALLNatDef()
{
    if [ "${apn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${default_wan_if}) ]; then
        iptables -t nat -A POSTROUTING -o ${default_wan_if} -j MASQUERADE
    fi
    if [ "${vpn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${pptp_vpn_ifname}) ]; then
        iptables -t nat -A POSTROUTING -o ${pptp_vpn_ifname} -j MASQUERADE
    fi
}

WANNatDef()
{
    if [ "${apn_nat_sw}" = "1" -a -z $(iptables -t nat -S POSTROUTING | grep ${default_wan_if}) ]; then
        #iptables -t nat -F POSTROUTING
	#clean all MASQUERADE,then we add only default_wan_if MASQUERADE
	echo "$(iptables -t nat -S | grep MASQUERADE | cut -d' ' -f2-6)" > /tmp/.nat_rule_list
        while read line
        do
		iptables -t nat -D $line
        done < /tmp/.nat_rule_list

        iptables -t nat -A POSTROUTING -o ${default_wan_if} -j MASQUERADE
    fi
}

PPTPRouteDef()
{
    if [ "${vpn_default_route}" = "1" -a -z "$(ip route | grep default | grep $pptp_vpn_ifname)" ]; then
        get_default_route
        if [ -n "${default_wan_if}" -a -z "$(ip route | grep ${pptp_server})" ];then
            ip route add ${pptp_server}/32 via ${default_route_gateway} dev ${default_wan_if} 2>/dev/null
        fi
        ip route del default
        ip route add default dev ${default_wan_if} via ${default_route_gateway} metric 1 2>/dev/null
        ip route add default dev ${pptp_vpn_ifname} via ${pptp_peer_ip}
    fi
}

#更新静态路由表
firewall_route_update()
{
    firewalltoolc -g
    firewalltoolc -a route
}

WANRouteDef()
{
    get_default_route
    if [ -z "$(ip route | grep default | grep $default_wan_if)" ]; then
        statusinit
        ip route del default
        ip route del default metric 1 2>/dev/null
        ip route add default dev ${default_wan_if} via ${default_route_gateway} 2>/dev/null
        firewalltoolc -g
        firewalltoolc -a firewall
    fi
}
##创建pptp配置文件存放路径
if [ ! -d "${config_path_peerfiles}" ]; then
	mkdir -p ${config_path_peerfiles}
fi

#WANRouteDef
##配置
pptpConfig
##启动服务
pptpstart
##ppp状态检查
while [ 1 ]
do
	##获取ppp当前状态
	pptpstatus
	if [ "${pptp_state}" = "1" ]; then
		if [ ${routechecktime:=6} -gt 3 ]; then
			#每隔30秒检查一次路由，看路由是否会出问题
			PPTPRouteDef
			ALLNatDef	
			routechecktime=0;
		fi
                
		if [ "${is_static_route_update:=1}" = "1"  ];then
                        firewall_route_update
                        is_static_route_update=0
                fi
		routechecktime=$((${routechecktime} + 1))
		reconnet_time=0
	else
                is_static_route_update=1
		WANRouteDef
		WANNatDef
		if [ ${reconnet_time:=0} -gt 12 -o -n "$(ifconfig |grep ${default_wan_if})" -a -z "$(ps | grep pppd | grep pptp_vpn_client)" ]; then
			pptpstart
			reconnet_time=0
		fi
		reconnet_time=$((${reconnet_time} + 1))
	fi
	
	pptp_sw
	if [ "${pptp_enable}" != "1" ]; then
		WANRouteDef
		statusInit
		killall pppd
		killall -9 pptp
    		rm $pid_file
		exit 0 
	fi
	sleep 10
done


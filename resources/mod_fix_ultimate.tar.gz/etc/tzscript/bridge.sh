#!/bin/sh

p1=$1
iface=br0
usb0=sipa_usb0
vpcie=eth0
default_mtu=1500

IP_LINK_SET="ip link set"
CAT_PRO="cat"
MAC_ADDR_FILE=/etc/productinfo/mac

WAN_MODE=`mdlcfg -g USR_WAN_MODE`

wait_iface_load()
{
	index=0
	while(true)
	do
		result=`ifconfig $vpcie | grep "RUNNING"`
		if [ "$result" != "" ] || [ "$index" = "10" ]; then
			ifconfig $vpcie down
			break;
		else
			index=$((index + 1))
			echo "$vpcie is no ready."
		fi
		sleep 1
	done
}

add_bridge()
{
	ifconfig br0
	ERR=`echo $?`
	if [ "$ERR" = "0" ]; then
		echo "Bridge br0 is ok no need to create."
	else
		brctl addbr $iface
		ERR=`echo $?`
		if [ "$ERR" = "0" ]; then
                	echo "Create $iface ok."
        	else
			echo "Create $iface error, exit."
			exit $ERR
		fi

		brctl stp $iface off
		ERR=`echo $?`
		if [ "$ERR" = "0" ]; then
			echo "Brctl stp $iface ok."
		else
			echo "Brctl stp error, exit."
			exit $ERR
		fi
	fi
}

set_ip_to_bridge()
{
	ip=`mdlcfg -g USR_DHCP_LAN_IP`
	if [ "$ip" = "" ]; then
		ip=192.168.0.1
	fi

	ifconfig $iface $ip up
	ERR=`echo $?`
        if [ "$ERR" = "0" ]; then
		echo "set $iface ip ok."
        else
                echo "set $iface ip error, exit."
                exit $ERR
        fi
}

activation_usb0()
{
	connmanctl SetPdp 1 ctcc IPV4V6
	connmanctl ActivatePdp 1
	connmanctl enable gadget
	connmanctl tether gadget on
}

add_iface_to_bridge()
{
	#activation_usb0

	#ifconfig $usb0 0.0.0.0 up
	#brctl addif $iface $usb0

	ifconfig $vpcie 0.0.0.0 mtu $default_mtu up
	brctl addif $iface $vpcie
}

del_bridge()
{
	ifconfig $iface down
	brctl delbr $iface
}


help()
{
	echo "Usage :"
        echo "		$0 addbr : add bridge $iface"
        echo "		$0 delbr : del bridge $iface"
	exit 
}

set_iface_mac()
{
	MAC_ADDR=`$CAT_PRO $MAC_ADDR_FILE`

	echo "macaddr: [$MAC_ADDR]"
	if [ "$MAC_ADDR" != "" ] ; then
		ifconfig $1 hw ether $MAC_ADDR
	fi
}


bridge_setup()
{
	if [ "$p1" = "addbr" ]; then
		wait_iface_load
		add_bridge
		set_iface_mac $iface
		
		if [ "$WAN_MODE" = "wired" ]; then
			/etc/tzscript/4g_wan_mode_switch.sh
			#/etc/tzscript/4g_wan_mode_switch.sh >/dev/null 2>&1 &
		else
			set_iface_mac $vpcie
			add_iface_to_bridge
		fi
		set_ip_to_bridge
	elif [ "$p1" = "delbr" ]; then
		del_bridge
	else
		help
	fi
		
}

bridge_setup


#!/bin/sh
##功能：tmp vpn config convert

#set -x

CFG_CMD=mdlcfg

##L2TP的老旧开关
vpn_old_l2tp_sw=$($CFG_CMD -g USR_L2TP_SW)

##PPTP的老旧开关
vpn_old_pptp_sw=$($CFG_CMD -g USR_PPTP_SW)

if [ "${vpn_old_l2tp_sw}" == "1" ]; then
    $($CFG_CMD -a USR_VPN_SW=1)
    $($CFG_CMD -a USR_VPN_MODE=0)
    $($CFG_CMD -a USR_L2TP_SW=0)
    $($CFG_CMD -c)
else
    if [ "${vpn_old_pptp_sw}" == "1" ]; then
        $($CFG_CMD -a USR_VPN_SW=1)
        $($CFG_CMD -a USR_VPN_MODE=1)
        $($CFG_CMD -a USR_PPTP_SW=0)
        $($CFG_CMD -c)
    fi
fi

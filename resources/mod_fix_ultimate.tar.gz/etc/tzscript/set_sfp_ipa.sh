#!/bin/sh

CFG_CMD=mdlcfg

SFP_IPA_SW=`$CFG_CMD -g SYS_SFP_IPA_SW`

# SFP_IPA功能开关.  0 全关; 1 开sfp; 2 开ipa
# enable：使能状态，1 开启，0 关闭
# tether_scheme：模式切换，1 sfp模式， 0 ipa模式

# 默认开启sfp
if [ "${SFP_IPA_SW:=1}" == "0" ]; then
    # 全关
    echo 1 > /proc/net/sfp/tether_scheme
	echo 0 > /proc/net/sfp/enable
else 
    if [ "${SFP_IPA_SW}" == "1" ]; then
        # 开启sfp
        echo 1 > /proc/net/sfp/tether_scheme
        echo 1 > /proc/net/sfp/enable
    else
        # 开启ipa
        echo 0 > /proc/net/sfp/tether_scheme
        echo 1 > /proc/net/sfp/enable
    fi
fi

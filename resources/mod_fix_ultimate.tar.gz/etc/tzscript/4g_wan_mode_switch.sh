#!/bin/sh

iface=br0
vpcie=eth0
mobile_4g_iface=seth_lte0
pppoe_iface=ppp0
default_mtu=1500

IP_LINK_SET="ip link set"
CAT_PRO="cat"
MAC_ADDR_FILE=/etc/productinfo/mac
PPPOE_CHAP=/etc/ppp/chap-secrets
PPPOE_PAP=/etc/ppp/pap-secrets
PPPOE_CONF=/etc/ppp/pppoe.conf
PPPOE_FIREWALL_MASQ=/etc/ppp/firewall-masq
PPPOE_START=/usr/sbin/pppoe-start

WAN_MODE=`mdlcfg -g USR_WAN_MODE`
WAN_IPMODE=`mdlcfg -g USR_WAN_IPMODE`
WAN_LINKMODE=`mdlcfg -g USR_WAN_LINKMODE`
WAN_NAT_SW=`mdlcfg -g USR_WAN_NAT_SW`

add_or_del_MASQUERADE()
{
	iptables -t nat -S | grep "$1 -j MASQUERADE"
	ERR=`echo $?`
	if [[ "$ERR" = "0" && "$2" = "del" ]]; then
		iptables -t nat -D POSTROUTING -o $1 -j MASQUERADE
	elif [[ "$ERR" != "0" && "$2" = "add" ]]; then
		iptables -t nat -A POSTROUTING -o $1 -j MASQUERADE
	fi
}

handle_MASQUERADE()
{
	if [ "$WAN_MODE" = "mobile" ]; then
		add_or_del_MASQUERADE  $vpcie del
		add_or_del_MASQUERADE  $pppoe_iface del
	elif [[ "$WAN_MODE" = "wired" && "$WAN_LINKMODE" = "linkIP" ]]; then
		add_or_del_MASQUERADE  $mobile_4g_iface del
		add_or_del_MASQUERADE  $pppoe_iface del
		if [ "$WAN_NAT_SW" = "1" ]; then
			add_or_del_MASQUERADE  $vpcie add
		fi
	elif [[ "$WAN_MODE" = "wired" && "$WAN_LINKMODE" = "linkPPP" ]]; then
		add_or_del_MASQUERADE  $mobile_4g_iface del
		add_or_del_MASQUERADE  $vpcie del
		if [ "$WAN_NAT_SW" = "1" ]; then
			add_or_del_MASQUERADE  $pppoe_iface add
		fi
	fi
}

set_mac_from_pro()
{
        mac=`$CAT_PRO $MAC_ADDR_FILE`
        if [ "-$mac" != "-" ];then
                ifconfig $vpcie down
                ifconfig $vpcie hw ether $mac
                ifconfig $vpcie up
        fi
}

set_mac_from_mdl()
{
        mac=`mdlcfg -g USR_WAN_MAC_CLONE_ADDR`

        if [ "-$mac" != "-" ];then
                ifconfig $vpcie down
                ifconfig $vpcie hw ether $mac
                ifconfig $vpcie up
	else
		set_mac_from_pro
	fi
}


add_vpcie_to_bridge()
{
	set_mac_from_pro
	ifconfig $vpcie 0.0.0.0 mtu $default_mtu up
	brctl addif $iface $vpcie
}

del_vpcie_from_br()
{
	brctl show |grep "$vpcie"
	ERR=`echo $?`
	if [ "$ERR" = "0" ]; then
		brctl delif $iface $vpcie
	fi
}

set_wan_mode_by_dhcp()
{
	set_mac_from_mdl
	mtu=`mdlcfg -g USR_WAN_MTU`
	ifconfig $vpcie mtu $mtu

	killall listen_eth0_state.sh
	sleep 1
	/etc/tzscript/listen_eth0_state.sh >/dev/null 2>&1 &
}

set_wan_mode_by_static_ip()
{
	ip=`mdlcfg -g USR_WAN_IPADDR_V4`
	netmask=`mdlcfg -g USR_WAN_SUBMASK_V4`
	gw=`mdlcfg -g USR_WAN_GATEWAY_V4`
	mtu=`mdlcfg -g USR_WAN_MTU`
	fridns=`mdlcfg -g USR_WAN_FIRSTDNS_V4`
	secdns=`mdlcfg -g USR_WAN_SECDNS_V4`
	
	if [[ $ip = "" || $netmask = "" || $gw = "" || $mtu = "" || $fridns = "" ]]; then
		exit
	fi
	
	set_mac_from_mdl
	ifconfig $vpcie $ip netmask $netmask mtu $mtu
	ERR=`echo $?`
	if [ "$ERR" = "0" ]; then
			echo "set $vpcie ip ok."
	else
			echo "set $vpcie ip error, exit."
			exit $ERR
	fi

	ip route add default via $gw
	
	if [ -n "$fridns" ]; then
		echo "nameserver $fridns" > /etc/resolv.conf
	fi

	if [ -n "$secdns" ]; then
		echo "nameserver $secdns" >> /etc/resolv.conf
	fi
	
	firewalltoolc -g
        firewalltoolc -a firewall
}

set_wan_mode_by_pppoe()
{
	pppoe_user=`mdlcfg -g USR_WAN_PPPOE_USERNAME`
	pppoe_passwd=`mdlcfg -g USR_WAN_PPPOE_PASSWD`

	if [[ $pppoe_user = "" || $pppoe_passwd = "" ]]; then
		exit
	fi

	set_mac_from_mdl
	mount -o remount,rw /

#-----------set username and passwd-----------------------------#
	echo "# Secrets for authentication using PAP" > $PPPOE_PAP
	echo "# client        server  secret                  IP addresses" >> $PPPOE_PAP
	echo "\"$pppoe_user\"	*	\"$pppoe_passwd\"" >> $PPPOE_PAP

	echo "\"$pppoe_user\"	*	\"$pppoe_passwd\"" >> $PPPOE_CHAP
	echo "# Secrets for authentication using CHAP" > $PPPOE_CHAP
	echo "# client        server  secret                  IP addresses" >> $PPPOE_CHAP
	echo "\"$pppoe_user\"	*	\"$pppoe_passwd\"" >> $PPPOE_CHAP

#-----------set pppoe firewall when pppoe is connected.Here just want to refresh firewall.---------------------------#
	cat $PPPOE_START |grep "/usr/bin/firewalltoolc"

	if [ $? != 0 ]; then
		sed -i '/tty -s && $ECHO \" Connected!\"/a\     /usr/bin/firewalltoolc -g && /usr/bin/firewalltoolc -a firewall' $PPPOE_START
	fi
	
#-----------start pppoe by pppoe-start eth0 pppoe_username pppoe_conf------------------------#
	mount -o remount,ro /	
	$PPPOE_START $vpcie $pppoe_user $PPPOE_CONF
}

/usr/sbin/pppoe-stop
killall listen_eth0_state.sh
killall udhcpc
del_vpcie_from_br

handle_MASQUERADE

if [[ "$WAN_MODE" = "wired" && "$WAN_IPMODE" = "static" && "$WAN_LINKMODE" = "linkIP" ]]; then
	set_wan_mode_by_static_ip
elif [[ "$WAN_MODE" = "wired" && "$WAN_IPMODE" = "dhcp" && "$WAN_LINKMODE" = "linkIP" ]]; then
	set_wan_mode_by_dhcp
elif [[ "$WAN_MODE" = "wired" && "$WAN_LINKMODE" = "linkPPP" ]]; then
	set_wan_mode_by_pppoe	
else
	add_vpcie_to_bridge
fi


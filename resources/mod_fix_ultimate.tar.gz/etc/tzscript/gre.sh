#!/bin/sh

CFG_CMD=mdlcfg

gre_switch=$($CFG_CMD -g USR_GRE_SW)
tunnel_name=$($CFG_CMD -g USR_GRE_TUNNEL_NAME)
wan_ipaddr=$(devinfo 201004)
server_ip=$($CFG_CMD -g USR_GRE_SERVER)
local_ip=$($CFG_CMD -g USR_GRE_LOCAL_IP)
peer_ip=$($CFG_CMD -g USR_GRE_PEER_IP)


ip link set $tunnel_name down
ip tunnel del $tunnel_name
ip route del $peer_ip table 0
#echo 0 > /proc/net/sfp/enable

if [ "$gre_switch" == "0" ]; then
#	echo 1 > /proc/net/sfp/enable
	exit
fi

if [ "$server_ip" == "" -o "$local_ip" == "" -o "$peer_ip" == "" -o "-$wan_ipaddr" == "-" ]; then
	exit
fi

#ip tunnel add创建隧道,mode设置隧道使用gre模式,local后面跟本机的IP地址，remote后面是与其他主机建立隧道的对方IP地址
ip tunnel add $tunnel_name mode gre remote $server_ip local $wan_ipaddr
#启动隧道$tunnel_name
ip link set $tunnel_name up
#为隧道配置ip地址,为隧道$tunnel_name设置本地IP地址$local_ip,隧道对面的主机IP（服务器）的隧道IP为$peer_ip
ip addr add $local_ip peer $peer_ip dev $tunnel_name

ip_addr=${wan_ipaddr%.*}

ip route del default via $wan_ipaddr table 0
ip route add $ip_addr.0/24 dev seth_lte0 table 0
#ip route add default via $wan_ipaddr metric 1 table 0
ip route add default via $peer_ip table 0

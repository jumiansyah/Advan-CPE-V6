#!/bin/sh

############################
#Auth: ygx
#Date: 2020.9.3
############################

TEE_PRO="busybox tee -ai"
ECHO_PRO="echo"
DATA_PATH=/mnt/data
AUTO_SET_DBG_CFG=$DATA_PATH/var/run/auto_set_dbg_cfg
IS_RESET_START=$DATA_PATH/var/run/is_reset_start
DATA_LOCAL=$DATA_PATH/local
LOG_PATH=$DATA_LOCAL/log
LOF_FILE=$LOG_PATH/mifi.log
CFG_CMD=mdlcfg

if [ -e $AUTO_SET_DBG_CFG ];then
	rm $AUTO_SET_DBG_CFG
	touch $AUTO_SET_DBG_CFG
	$ECHO_PRO "$AUTO_SET_DBG_CFG is exsit" | $TEE_PRO $LOG_FILE
	if [ -e $IS_RESET_START ];then
		rm $AUTO_SET_DBG_CFG
		touch $AUTO_SET_DBG_CFG
		$ECHO_PRO "Start thr program initialization for the first time" | $TEE_PRO $LOG_FILE
		rm $IS_RESET_START
		VERSION_TYPE=`awk -F: '/version_type/' /system/version`
		$ECHO_PRO "Entry start $AUTO_SET_DBG_CFG" |TEE_PRO $LOG_FILE
		if [ "${VERSION_TYPE#*:}" = "userdebug" ];then
			`$CFG_CMD -a SYS_TELNET_SWITCH="1"`
			`$CFG_CMD -a SYS_ADB_SWITCH="1"`
			`$CFG_CMD -a SYS_REBOOT_WHEN_MODEM_UNORMAL="0"`
			`$CFG_CMD -c`
			$ECHO_PRO "version_type is dbg" | $TEE_PRO $LOG_FILE
		fi
		if [ "${VERSION_TYPE#*:}" = "user" ];then
			`$CFG_CMD -a SYS_TELNET_SWITCH="0"`
			`$CFG_CMD -a SYS_ADB_SWITCH="0"`
			`$CFG_CMD -a SYS_REBOOT_WHEN_MODEM_UNORMAL="1"`
			`$CFG_CMD -c`
			$ECHO_PRO "version_type is usr" | $TEE_PRO $LOG_FILE
		fi
	fi
else
	$ECHO_PRO "Start thr program initialization for the first time" | $TEE_PRO $LOG_FILE
	touch $AUTO_SET_DBG_CFG
	VERSION_TYPE=`awk -F: '/version_type/' /system/version`
	$ECHO_PRO "Entry start $AUTO_SET_DBG_CFG" |TEE_PRO $LOG_FILE
	if [ "${VERSION_TYPE#*:}" = "userdebug" ];then
		`$CFG_CMD -a SYS_TELNET_SWITCH="1"`
		`$CFG_CMD -a SYS_ADB_SWITCH="1"`
		`$CFG_CMD -a SYS_REBOOT_WHEN_MODEM_UNORMAL="0"`
		`$CFG_CMD -c`
		$ECHO_PRO "version_type is dbg" | $TEE_PRO $LOG_FILE
	fi
	if [ "${VERSION_TYPE#*:}" = "user" ];then
		`$CFG_CMD -a SYS_TELNET_SWITCH="1"`
		`$CFG_CMD -a SYS_ADB_SWITCH="0"`
		`$CFG_CMD -a SYS_REBOOT_WHEN_MODEM_UNORMAL="1"`
		`$CFG_CMD -c`
		$ECHO_PRO "version_type is usr" | $TEE_PRO $LOG_FILE
	fi
fi
